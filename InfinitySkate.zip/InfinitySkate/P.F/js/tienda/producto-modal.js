// Leer categoría elegida de la URL
const urlParams = new URLSearchParams(window.location.search);
const selectedCategory = urlParams.get('cat') || 'todas';

const titleElement = document.getElementById('currentCategoryTitle');
const productCards = document.querySelectorAll('.product-card');

// Filtrar productos y secciones por categoría
if (titleElement) {
    titleElement.textContent = `Categoría: ${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)}`;

    const categorySections = document.querySelectorAll('.category-row-section');

    categorySections.forEach(section => {
        const sectionCategory = section.getAttribute('data-category-section');
        section.style.display = (selectedCategory === 'todas' || sectionCategory === selectedCategory) ? '' : 'none';
    });

    productCards.forEach(card => {
        const cardCategory = card.getAttribute('data-category');
        if (selectedCategory === 'todas' || cardCategory === selectedCategory) {
            card.classList.remove('hidden');
        } else {
            card.classList.add('hidden');
        }
    });

    const filterLinks = document.querySelectorAll('.filter-bar a');
    filterLinks.forEach(link => {
        if (link.getAttribute('data-cat') === selectedCategory) {
            link.classList.add('active');
        }
    });

    const allCategoryLink = document.querySelector('.category-dropdown-container .dropdown-menu a[href="categorias.html#todas-categorias"]');
    if (allCategoryLink && selectedCategory === 'todas') {
        allCategoryLink.classList.add('active');
    }

    // Flechas de las filas de categoría
    document.querySelectorAll('.category-row-section').forEach(section => {
        const track = section.querySelector('.category-row-track');
        const prev = section.querySelector('.category-row-arrow-prev');
        const next = section.querySelector('.category-row-arrow-next');
        if (!track || !prev || !next) return;

        const actualizarFlechas = () => {
            const maxScroll = Math.max(0, track.scrollWidth - track.clientWidth);
            prev.hidden = track.scrollLeft <= 1;
            next.hidden = track.scrollLeft >= maxScroll - 1;
        };

        const mover = direccion => {
            track.scrollBy({ left: direccion * Math.max(track.clientWidth * 0.85, 260), behavior: 'smooth' });
        };

        prev.addEventListener('click', () => mover(-1));
        next.addEventListener('click', () => mover(1));
        track.addEventListener('scroll', actualizarFlechas, { passive: true });
        window.addEventListener('resize', actualizarFlechas);
        actualizarFlechas();
    });
}

// Modal de producto
document.addEventListener('DOMContentLoaded', () => {

    
    // Tallas y colores por defecto
    const TALLAS_POR_CATEGORIA = {
        camisas: ['S', 'M', 'L', 'XL'],
        buzos: ['S', 'M', 'L', 'XL'],
        chaquetas: ['S', 'M', 'L', 'XL'],
        pantalones: ['28', '30', '32', '34', '36'],
        zapatos: ['38', '39', '40', '41', '42', '43'],
        gorras: ['Única']
    };

    const COLORES_DISPONIBLES = ['Negro', 'Blanco', 'Gris', 'Rojo', 'Azul', 'Verde'];

    // Elementos del modal
    const overlay = document.getElementById('productModalOverlay');

    
    if (!overlay) return;

    const esPaginaCarrito = !!document.getElementById('cartItemsContainer');

    // Crear modal de producto no disponible
    const modalBox = overlay.querySelector('.product-modal-box:not(.unavailable-product-box)');
    let unavailableBox = document.getElementById('unavailableProductBox');
    if (!unavailableBox) {
        unavailableBox = document.createElement('div');
        unavailableBox.className = 'product-modal-box unavailable-product-box';
        unavailableBox.id = 'unavailableProductBox';
        unavailableBox.innerHTML = `
            <button type="button" class="modal-close-btn" id="unavailableModalCloseBtn" aria-label="Cerrar">&times;</button>
            <div class="unavailable-icon">!</div>
            <h3 class="modal-title">Producto fuera de venta</h3>
            <p class="modal-desc" id="unavailableProductName"></p>
            <p class="modal-desc">Este producto se encuentra en producción y no está disponible para la venta por el momento.</p>
        `;
        overlay.appendChild(unavailableBox);
    }

    // Referencias a los campos del modal
    const modalImg = document.getElementById('modalProductImg');
    const modalTitle = document.getElementById('modalProductTitle');
    const modalPrice = document.getElementById('modalProductPrice');
    const modalDiscount = document.getElementById('modalProductDiscount');
    const modalDesc = document.getElementById('modalProductDesc');
    const modalTallaSelect = document.getElementById('modalTallaSelect');
    const modalColorSelect = document.getElementById('modalColorSelect');
    const modalQtyInput = document.getElementById('modalQtyInput');
    const modalAddBtn = document.getElementById('modalAddToCartBtn');
    const modalCloseBtn = document.getElementById('modalCloseBtn');
    const unavailableCloseBtn = document.getElementById('unavailableModalCloseBtn');
    const unavailableProductName = document.getElementById('unavailableProductName');

    // Estado del modal y carrusel
    let productoActual = null;
    let modoEdicionCarrito = false;

    const CATALOGO = window.CATALOGO_SKATE || {};
    const INTERVALO_CARRUSEL_MS = 3500;
    const imgBox = modalImg ? modalImg.closest('.modal-img-box') : null;
    const carrusel = { imagenes: [], indice: 0, timer: null, interactuado: false };
    let btnPrev = null;
    let btnNext = null;
    let dotsBox = null;

    // Obtener datos del producto
    function infoProducto(id) {
        return CATALOGO[id] || null;
    }

    // Detener carrusel automático
    function detenerCarrusel() {
        if (carrusel.timer) {
            clearInterval(carrusel.timer);
            carrusel.timer = null;
        }
    }

    // Iniciar carrusel automático
    function iniciarCarrusel() {
        detenerCarrusel();
        if (carrusel.imagenes.length > 1 && !carrusel.interactuado && overlay.classList.contains('active')) {
            carrusel.timer = setInterval(() => irAImagen(carrusel.indice + 1), INTERVALO_CARRUSEL_MS);
        }
    }

    // Mover carrusel manualmente
    function moverManual(delta) {
        carrusel.interactuado = true;
        detenerCarrusel();
        irAImagen(carrusel.indice + delta);
    }

    // Mostrar imagen del carrusel
    function irAImagen(i) {
        const n = carrusel.imagenes.length;
        if (!n) return;
        carrusel.indice = ((i % n) + n) % n;
        const img = carrusel.imagenes[carrusel.indice];

        modalImg.setAttribute('src', img.src);
        const nombre = productoActual ? productoActual.nombre : '';
        modalImg.setAttribute('alt', img.vista ? nombre + ' - ' + img.vista : nombre);

        if (dotsBox) {
            Array.from(dotsBox.children).forEach((dot, k) => dot.classList.toggle('active', k === carrusel.indice));
        }

        if (img.color && Array.from(modalColorSelect.options).some(o => o.value === img.color)) {
            modalColorSelect.value = img.color;
        }
    }

    // Crear flechas y puntos del carrusel
    function crearControlesCarrusel() {
        if (!imgBox || btnPrev) return;

        btnPrev = document.createElement('button');
        btnPrev.type = 'button';
        btnPrev.className = 'modal-carousel-arrow modal-carousel-prev';
        btnPrev.setAttribute('aria-label', 'Imagen anterior');
        btnPrev.textContent = '‹';
        btnPrev.addEventListener('click', (e) => { e.stopPropagation(); moverManual(-1); });

        btnNext = document.createElement('button');
        btnNext.type = 'button';
        btnNext.className = 'modal-carousel-arrow modal-carousel-next';
        btnNext.setAttribute('aria-label', 'Imagen siguiente');
        btnNext.textContent = '›';
        btnNext.addEventListener('click', (e) => { e.stopPropagation(); moverManual(1); });

        dotsBox = document.createElement('div');
        dotsBox.className = 'modal-carousel-dots';

        imgBox.appendChild(btnPrev);
        imgBox.appendChild(btnNext);
        imgBox.appendChild(dotsBox);

        imgBox.addEventListener('mouseenter', detenerCarrusel);
        imgBox.addEventListener('mouseleave', iniciarCarrusel);
    }

    // Configurar carrusel con imágenes
    function configurarCarrusel(imagenes, indiceInicial) {
        detenerCarrusel();
        crearControlesCarrusel();

        carrusel.imagenes = imagenes;
        carrusel.indice = 0;
        carrusel.interactuado = false;

        const hayVariantes = imagenes.length > 1;
        if (btnPrev) {
            btnPrev.hidden = !hayVariantes;
            btnNext.hidden = !hayVariantes;
            dotsBox.hidden = !hayVariantes;
            dotsBox.innerHTML = '';
            imagenes.forEach((_, k) => {
                const dot = document.createElement('button');
                dot.type = 'button';
                dot.className = 'modal-carousel-dot';
                dot.setAttribute('aria-label', 'Ver imagen ' + (k + 1));
                dot.addEventListener('click', (e) => {
                    e.stopPropagation();
                    carrusel.interactuado = true;
                    detenerCarrusel();
                    irAImagen(k);
                });
                dotsBox.appendChild(dot);
            });
        }

        irAImagen(indiceInicial || 0);
        iniciarCarrusel();
    }

    // Cambiar imagen al elegir color
    modalColorSelect.addEventListener('change', () => {
        const idx = carrusel.imagenes.findIndex(im => im.color === modalColorSelect.value);
        carrusel.interactuado = true;
        detenerCarrusel();
        if (idx >= 0) irAImagen(idx);
    });

    // Detener carrusel al usar el panel
    const panelDerechoModal = overlay.querySelector('.product-modal-right');
    if (panelDerechoModal) {
        ['pointerdown', 'focusin'].forEach(ev => panelDerechoModal.addEventListener(ev, () => {
            carrusel.interactuado = true;
            detenerCarrusel();
        }));
    }

    // Texto del botón en el carrito
    if (esPaginaCarrito && modalAddBtn) {
        modalAddBtn.textContent = 'Guardar Cambio en el Carrito';
    }

    // Deducir tallas según valor
    function inferirTallasDesdeValor(talla) {
        const t = String(talla || '').trim().toUpperCase();
        if (['S', 'M', 'L', 'XL'].includes(t)) return TALLAS_POR_CATEGORIA.camisas;
        if (['28', '30', '32', '34', '36'].includes(t)) return TALLAS_POR_CATEGORIA.pantalones;
        if (['38', '39', '40', '41', '42', '43'].includes(t)) return TALLAS_POR_CATEGORIA.zapatos;
        if (t === 'ÚNICA' || t === 'UNICA') return TALLAS_POR_CATEGORIA.gorras;
        return TALLAS_POR_CATEGORIA.camisas;
    }

    // Convertir texto de precio a número
    function parsePrecio(textoPrecio) {
        const soloNumeros = textoPrecio.replace(/[^\d]/g, '');
        return parseInt(soloNumeros, 10) || 0;
    }

    // Abrir modal desde una tarjeta
    function abrirModal(card) {
        modoEdicionCarrito = false;
        const tituloEl = card.querySelector('.product-title');
        const imgEl = card.querySelector('.product-img-box img');
        const precioEl = card.querySelector('.product-price');

        if (!tituloEl || !imgEl || !precioEl) return;

        const nombre = tituloEl.textContent.trim();
        const imgSrc = imgEl.getAttribute('src');
        const precioTexto = precioEl.textContent.trim();
        const disponible = card.getAttribute('data-disponible') !== 'false';

        if (!disponible) {
            if (modalBox) modalBox.style.display = 'none';
            unavailableBox.style.display = 'block';
            unavailableProductName.textContent = nombre;
            overlay.classList.add('active');
            return;
        }

        if (modalBox) modalBox.style.display = '';
        unavailableBox.style.display = 'none';

        
        const categoria = (
            card.getAttribute('data-category') ||
            card.getAttribute('data-categoria') ||
            ''
        ).toLowerCase();

        productoActual = {
            nombre: nombre,
            imgSrc: imgSrc,
            precio: parsePrecio(precioTexto),
            precioTexto: precioTexto,
            categoria: categoria,
            card: card
        };

        modalImg.setAttribute('src', imgSrc);
        modalImg.setAttribute('alt', nombre);
        modalTitle.textContent = nombre;
        modalPrice.textContent = precioTexto;

        
        const badgeEl = card.querySelector('.discount-badge');
        if (modalDiscount) {
            if (badgeEl) {
                modalDiscount.textContent = 'Descuento: ' + badgeEl.textContent.trim();
                modalDiscount.style.display = 'block';
            } else {
                modalDiscount.textContent = '';
                modalDiscount.style.display = 'none';
            }
        }

        const info = infoProducto(Number(card.getAttribute('data-product-id')));

        modalDesc.textContent = (info && info.descripcion)
            ? info.descripcion
            : 'Prenda de la categoría ' + categoria + ' de Skate∞. Alta calidad y estilo urbano, ideal para tu día a día.';

        const tallas = (info && info.tallas) || TALLAS_POR_CATEGORIA[categoria] || ['Única'];
        modalTallaSelect.innerHTML = tallas
            .map(talla => '<option value="' + talla + '">' + talla + '</option>')
            .join('');

        const colores = (info && info.colores) || COLORES_DISPONIBLES;
        modalColorSelect.innerHTML = colores
            .map(color => '<option value="' + color + '">' + color + '</option>')
            .join('');

        modalQtyInput.value = 1;

        overlay.classList.add('active');

        configurarCarrusel(info ? info.imagenes : [{ src: imgSrc, color: '', vista: '' }], 0);
    }

    // Abrir modal para editar item del carrito
    function abrirModalEdicionCarrito(row) {
        modoEdicionCarrito = true;

        const nombre = row.getAttribute('data-title') || '';
        const imgSrc = row.getAttribute('data-img') || '';
        const precio = Number(row.getAttribute('data-price')) || 0;
        const tallaActual = row.getAttribute('data-talla') || '';
        const colorActual = row.getAttribute('data-color') || '';
        const cantidadActual = Number(row.getAttribute('data-cantidad')) || 1;

        if (modalBox) modalBox.style.display = '';
        unavailableBox.style.display = 'none';

        productoActual = {
            nombre: nombre,
            imgSrc: imgSrc,
            precio: precio,
            precioTexto: precio.toLocaleString('es-CO') + '$',
            itemId: Number(row.getAttribute('data-item-id')),
            productId: Number(row.getAttribute('data-product-id')),
            row: row
        };

        modalImg.setAttribute('src', imgSrc);
        modalImg.setAttribute('alt', nombre);
        modalTitle.textContent = nombre;
        modalPrice.textContent = productoActual.precioTexto;

        if (modalDiscount) {
            modalDiscount.textContent = '';
            modalDiscount.style.display = 'none';
        }

        modalDesc.textContent = 'Modifica la talla, el color o la cantidad de este producto y guarda los cambios en tu carrito.';

        const info = infoProducto(productoActual.productId);

        const tallas = (info && info.tallas) || inferirTallasDesdeValor(tallaActual);
        modalTallaSelect.innerHTML = tallas
            .map(talla => '<option value="' + talla + '">' + talla + '</option>')
            .join('');
        if (tallas.includes(tallaActual)) modalTallaSelect.value = tallaActual;

        const colores = (info && info.colores) || COLORES_DISPONIBLES;
        modalColorSelect.innerHTML = colores
            .map(color => '<option value="' + color + '">' + color + '</option>')
            .join('');
        if (colores.includes(colorActual)) modalColorSelect.value = colorActual;

        modalQtyInput.value = cantidadActual;

        overlay.classList.add('active');

        if (info) {
            const idxColor = info.imagenes.findIndex(im => im.color === colorActual);
            configurarCarrusel(info.imagenes, idxColor >= 0 ? idxColor : 0);
        } else {
            configurarCarrusel([{ src: imgSrc, color: '', vista: '' }], 0);
        }
    }

    // Cerrar modal
    function cerrarModal() {
        detenerCarrusel();
        overlay.classList.remove('active');
        if (modalBox) modalBox.style.display = '';
        unavailableBox.style.display = 'none';
        productoActual = null;
        modoEdicionCarrito = false;
    }

    // Abrir modal al hacer clic en producto
    document.querySelectorAll('.product-card').forEach(card => {
        card.style.cursor = 'pointer';
        card.addEventListener('click', () => abrirModal(card));
    });

    // Abrir modal al hacer clic en item del carrito
    const cartItemsContainer = document.getElementById('cartItemsContainer');
    if (cartItemsContainer) {
        cartItemsContainer.addEventListener('click', (e) => {
            if (e.target.closest('[data-cart-action]')) return;
            const row = e.target.closest('.cart-item-row');
            if (!row) return;
            abrirModalEdicionCarrito(row);
        });
    }

    // Cerrar modal con botones y fondo
    modalCloseBtn.addEventListener('click', cerrarModal);
    unavailableCloseBtn.addEventListener('click', cerrarModal);

    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
            cerrarModal();
        }
    });

    // Agregar o guardar cambio en el carrito
    modalAddBtn.addEventListener('click', async () => {
        if (!productoActual) return;

        const cantidad = Math.max(1, parseInt(modalQtyInput.value, 10) || 1);
        const talla = modalTallaSelect.value;
        const color = modalColorSelect.value;

        // Editar item del carrito
        if (modoEdicionCarrito) {
            const itemId = productoActual.itemId;
            const productId = productoActual.productId;

            if (!itemId || !productId) {
                alert('No se pudo identificar este producto del carrito.');
                return;
            }

            modalAddBtn.disabled = true;

            try {
                const removeResponse = await fetch('../php/api/cart.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    credentials: 'same-origin',
                    body: JSON.stringify({ action: 'remove', item_id: itemId })
                });

                if (removeResponse.status === 401) {
                    alert('Debes iniciar sesión para modificar el carrito.');
                    window.location.href = 'landing.html';
                    return;
                }

                const addResponse = await fetch('../php/api/cart.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    credentials: 'same-origin',
                    body: JSON.stringify({
                        action: 'add',
                        product_id: productId,
                        talla,
                        color,
                        quantity: cantidad
                    })
                });

                const data = await addResponse.json();

                if (!addResponse.ok || !data.ok) {
                    alert(data.mensaje || 'No se pudo guardar el cambio.');
                    return;
                }

                cerrarModal();
                if (typeof window.recargarCarritoSkate === 'function') {
                    window.recargarCarritoSkate();
                } else {
                    window.location.reload();
                }
            } catch (error) {
                alert('No se pudo conectar con PHP/MySQL. Verifica XAMPP.');
            } finally {
                modalAddBtn.disabled = false;
            }
            return;
        }

        // Agregar producto nuevo al carrito
        const card = productoActual.card;
        const productId = card ? Number(card.getAttribute('data-product-id')) : 0;

        if (!productId) {
            alert('Este producto todavía no está vinculado a la base de datos.');
            return;
        }

        modalAddBtn.disabled = true;

        try {
            const response = await fetch('../php/api/cart.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                credentials: 'same-origin',
                body: JSON.stringify({
                    action: 'add',
                    product_id: productId,
                    talla,
                    color,
                    quantity: cantidad
                })
            });

            const data = await response.json();

            if (response.status === 401) {
                alert('Debes iniciar sesión para agregar productos al carrito.');
                window.location.href = 'landing.html';
                return;
            }

            if (!response.ok || !data.ok) {
                alert(data.mensaje || 'No se pudo agregar el producto.');
                return;
            }

            const nombreProducto = productoActual.nombre;
            cerrarModal();
            alert('"' + nombreProducto + '" se agregó al carrito.');
        } catch (error) {
            alert('No se pudo conectar con PHP/MySQL. Verifica XAMPP.');
        } finally {
            modalAddBtn.disabled = false;
        }
    });

});
