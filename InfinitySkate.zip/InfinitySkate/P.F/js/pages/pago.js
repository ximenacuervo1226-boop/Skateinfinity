document.addEventListener('DOMContentLoaded', () => {

    // Dar formato al dinero
    function formatMoney(value) {
        return Number(value).toLocaleString('es-CO') + '$';
    }

    const SHIPPING_COST = 10000;
    const itemsContainer = document.getElementById('paymentItemsContainer');
    const totalEl = document.getElementById('paymentTotal');
    const paymentLayout = document.getElementById('paymentLayout');
    const paymentBlockedMsg = document.getElementById('paymentBlockedMsg');
    let pedidoTotal = 0;
    let direccionGuardada = { direccion: '', ciudad: '', referencia: '' };

    // Cargar dirección guardada
    async function cargarDireccionGuardada() {
        try {
            const response = await fetch('../php/api/direccion.php', { credentials: 'same-origin' });
            const data = await response.json();
            if (data.ok && data.direccion) {
                direccionGuardada = {
                    direccion: data.direccion.direccion || '',
                    ciudad: data.direccion.ciudad || '',
                    referencia: data.direccion.referencia || ''
                };
            }
        } catch (error) {
        }
    }

    // Mostrar resumen del pedido
    async function cargarResumenPedido() {
        try {
            const response = await fetch('../php/api/cart.php', { credentials: 'same-origin' });
            const data = await response.json();

            if (response.status === 401) {
                window.location.href = 'landing.html';
                return;
            }

            const carrito = (data.ok && data.carrito) ? data.carrito : [];

            if (!carrito.length) {
                paymentLayout.hidden = true;
                paymentBlockedMsg.hidden = false;
                return;
            }

            let subtotal = 0;
            itemsContainer.innerHTML = carrito.map(item => {
                subtotal += Number(item.price) * Number(item.cantidad);
                return `
                    <div class="payment-item-row">
                        <div class="payment-item-info">
                            <span class="payment-item-name">${item.title}</span>
                            <span class="payment-item-variant">Talla: ${item.talla} · Color: ${item.color}</span>
                        </div>
                        <span class="payment-item-qty">x${item.cantidad}</span>
                        <span>${formatMoney(Number(item.price) * Number(item.cantidad))}</span>
                    </div>
                `;
            }).join('');

            pedidoTotal = subtotal + SHIPPING_COST;
            totalEl.textContent = formatMoney(pedidoTotal);
        } catch (error) {
            paymentLayout.hidden = true;
            paymentBlockedMsg.hidden = false;
            paymentBlockedMsg.querySelector('p').textContent = 'No se pudo conectar con el servidor.';
        }
    }

    cargarResumenPedido();
    cargarDireccionGuardada();

    // Elegir método de pago
    const opciones = document.querySelectorAll('.payment-option');
    const paneles = {
        panelBancolombia: document.getElementById('panelBancolombia'),
        panelNequi: document.getElementById('panelNequi'),
        panelQR: document.getElementById('panelQR')
    };

    opciones.forEach(opcion => {
        opcion.addEventListener('click', () => {
            opciones.forEach(o => o.classList.remove('active'));
            opcion.classList.add('active');

            Object.values(paneles).forEach(panel => { panel.hidden = true; });
            const panelId = opcion.dataset.panel;
            if (paneles[panelId]) paneles[panelId].hidden = false;
        });
    });

    // Mensaje de estado del pago
    const confirmBtn = document.getElementById('confirmPaymentBtn');
    const confirmCheck = document.getElementById('paymentConfirmedCheck');
    const paymentMsg = document.getElementById('paymentMsg');

    function mostrarMensaje(texto, tipo) {
        paymentMsg.textContent = texto;
        paymentMsg.className = 'payment-msg' + (tipo ? ' ' + tipo : '');
    }

    // Modal de dirección de envío
    const shippingFormModal = document.getElementById('shippingFormModal');
    const shippingForm = document.getElementById('shippingForm');
    const shippingFormClose = document.getElementById('shippingFormClose');
    const shippingDireccionInput = document.getElementById('shippingDireccion');
    const shippingCiudadInput = document.getElementById('shippingCiudad');
    const shippingReferenciaInput = document.getElementById('shippingReferencia');
    let metodoPagoPendiente = '';

    function abrirFormularioDireccion(metodoPago) {
        metodoPagoPendiente = metodoPago;
        shippingDireccionInput.value = direccionGuardada.direccion;
        shippingCiudadInput.value = direccionGuardada.ciudad;
        shippingReferenciaInput.value = direccionGuardada.referencia;
        shippingFormModal.classList.add('active');
    }

    function cerrarFormularioDireccion() {
        shippingFormModal.classList.remove('active');
    }

    shippingFormClose.addEventListener('click', cerrarFormularioDireccion);
    shippingFormModal.addEventListener('click', (e) => {
        if (e.target === shippingFormModal) cerrarFormularioDireccion();
    });

    // Enviar formulario de dirección
    shippingForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const direccion = shippingDireccionInput.value.trim();
        const ciudad = shippingCiudadInput.value.trim();
        const referencia = shippingReferenciaInput.value.trim();

        if (!direccion) {
            shippingDireccionInput.focus();
            return;
        }

        let direccionCompleta = [direccion, ciudad].filter(Boolean).join(', ');
        if (referencia) direccionCompleta += ' - Ref: ' + referencia;

        cerrarFormularioDireccion();
        await registrarPedido(direccionCompleta, metodoPagoPendiente);
    });

    // Registrar pedido en el servidor
    async function registrarPedido(direccion, metodoPago) {
        confirmBtn.disabled = true;
        mostrarMensaje('Verificando tu transferencia (simulación)...', '');

        try {
            const response = await fetch('../php/api/cart.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'same-origin',
                body: JSON.stringify({
                    action: 'checkout',
                    direccion: direccion,
                    metodo_pago: metodoPago
                })
            });

            const data = await response.json();

            if (!response.ok || !data.ok) {
                mostrarMensaje(data.mensaje || 'No se pudo registrar el pedido.', 'error');
                confirmBtn.disabled = false;
                return;
            }

            mostrarMensaje('', '');
            mostrarModalExito('¡Pago simulado con éxito! Pedido #' + data.id_pedido + ' registrado.', () => {
                window.location.href = 'principal.html';
            });
        } catch (error) {
            mostrarMensaje('No se pudo conectar con el servidor.', 'error');
            confirmBtn.disabled = false;
        }
    }

    // Confirmar pago
    confirmBtn.addEventListener('click', () => {
        if (!confirmCheck.checked) {
            mostrarMensaje('Marca la casilla "Ya realicé la transferencia" para continuar.', 'error');
            return;
        }

        const metodoSeleccionado = document.querySelector('input[name="metodoTransferencia"]:checked').value;
        const metodosPago = { bancolombia: 'Bancolombia', nequi: 'Nequi', qr: 'QR' };
        const metodoPago = metodosPago[metodoSeleccionado] || 'Bancolombia';

        abrirFormularioDireccion(metodoPago);
    });

});
