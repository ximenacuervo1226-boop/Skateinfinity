<?php
// Eliminar producto
require_once __DIR__ . '/logic/producto_eliminar_logic.php';
