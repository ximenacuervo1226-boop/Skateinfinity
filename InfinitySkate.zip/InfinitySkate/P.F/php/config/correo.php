<?php
declare(strict_types=1);

// Configuración del correo SMTP
function configCorreo(): array {
    return [
        'host'         => 'smtp.gmail.com',
        'puerto'       => 465,
        'usuario'      => 'SkateInfinityCOL@gmail.com',
        'clave'        => 'ahniqjxxsmyzbmur',
        'nombre'       => 'Skate∞',
        'verificar_ssl' => false,
    ];
}

// Verificar si el correo está configurado
function smtpConfigurado(): bool {
    $c = configCorreo();
    return $c['usuario'] !== '' && $c['clave'] !== '';
}

// Enviar correo por SMTP
function enviarCorreo(string $para, string $asunto, string $texto): void {
    $c = configCorreo();
    $ctx = stream_context_create(['ssl' => [
        'verify_peer'      => (bool)$c['verificar_ssl'],
        'verify_peer_name' => (bool)$c['verificar_ssl'],
    ]]);

    $fp = @stream_socket_client("ssl://{$c['host']}:{$c['puerto']}", $errno, $errstr, 15, STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) {
        throw new RuntimeException("No se pudo conectar al servidor de correo ({$errstr}).");
    }
    stream_set_timeout($fp, 15);

    // Funciones para hablar con el servidor
    $leer = function () use ($fp): string {
        $resp = '';
        while (($linea = fgets($fp, 515)) !== false) {
            $resp .= $linea;
            if (strlen($linea) < 4 || $linea[3] === ' ') break;
        }
        return $resp;
    };
    $cmd = function (string $linea, string $esperado) use ($fp, $leer): string {
        if ($linea !== '') fwrite($fp, $linea . "\r\n");
        $resp = $leer();
        if (strpos($resp, $esperado) !== 0) {
            throw new RuntimeException('Error SMTP: ' . trim($resp));
        }
        return $resp;
    };

    // Secuencia de envío SMTP
    try {
        $cmd('', '220');
        $cmd('EHLO localhost', '250');
        $cmd('AUTH LOGIN', '334');
        $cmd(base64_encode($c['usuario']), '334');
        $cmd(base64_encode($c['clave']), '235');
        $cmd('MAIL FROM:<' . $c['usuario'] . '>', '250');
        $cmd('RCPT TO:<' . $para . '>', '250');
        $cmd('DATA', '354');

        // Cabeceras y cuerpo del mensaje
        $cabeceras = [
            'From: =?UTF-8?B?' . base64_encode($c['nombre']) . '?= <' . $c['usuario'] . '>',
            'To: <' . $para . '>',
            'Subject: =?UTF-8?B?' . base64_encode($asunto) . '?=',
            'Date: ' . date('r'),
            'MIME-Version: 1.0',
            'Content-Type: text/plain; charset=UTF-8',
            'Content-Transfer-Encoding: base64',
        ];
        fwrite($fp, implode("\r\n", $cabeceras) . "\r\n\r\n" . chunk_split(base64_encode($texto)) . "\r\n.\r\n");
        $cmd('', '250');
        @fwrite($fp, "QUIT\r\n");
    } finally {
        fclose($fp);
    }
}
