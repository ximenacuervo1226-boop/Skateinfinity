// Claves de almacenamiento local
const SKATE_USERNAME_KEY = 'skate_username';
const SKATE_EMAIL_KEY = 'skate_user_email';
const SKATE_BIO_KEY = 'skate_user_bio';
const SKATE_AVATAR_KEY = 'skate_user_avatar';

// Mostrar botón solo para admin
function mostrarBotonAdmin(esAdmin) {
    document.querySelectorAll('[data-solo-admin]').forEach((btn) => {
        btn.hidden = !esAdmin;
    });
}

// Modal de cuenta bloqueada
function mostrarModalBloqueado() {
    if (document.getElementById('modalBloqueado')) return;
    localStorage.removeItem(SKATE_USERNAME_KEY);
    const overlay = document.createElement('div');
    overlay.id = 'modalBloqueado';
    overlay.className = 'blocked-overlay';
    overlay.innerHTML = `
        <div class="blocked-box" role="alertdialog" aria-labelledby="bloqueadoTitulo">
            <div class="blocked-icon">!</div>
            <h3 id="bloqueadoTitulo">Tu cuenta fue bloqueada</h3>
            <p>Por el momento no puedes iniciar sesión en Skate&infin;.</p>
            <p>Si crees que se trata de un error, contáctanos:</p>
            <ul class="blocked-contact">
                <li>📞 <a href="tel:+573174762163">+57 317 4762163</a></li>
                <li>✉️ <a href="mailto:SkateInfinityCOL@gmail.com">SkateInfinityCOL@gmail.com</a></li>
            </ul>
            <button type="button" class="blocked-close">Entendido</button>
        </div>`;
    document.body.appendChild(overlay);
    const cerrar = () => overlay.remove();
    overlay.querySelector('.blocked-close').addEventListener('click', cerrar);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) cerrar(); });
}

// Modal de éxito o error
let successModalTimeout = null;
function mostrarModalExito(mensaje, onClose, tipo) {
    const modal = document.getElementById('successModal');
    const msgEl = document.getElementById('successModalMsg');
    const iconEl = document.getElementById('successModalIcon');
    if (!modal || !msgEl) return;

    msgEl.textContent = mensaje;

    if (iconEl) {
        if (tipo === 'error') {
            iconEl.textContent = '✕';
            iconEl.classList.add('error');
        } else {
            iconEl.textContent = '✓';
            iconEl.classList.remove('error');
        }
    }

    modal.classList.add('active');

    if (successModalTimeout) clearTimeout(successModalTimeout);

    const cerrar = () => {
        modal.classList.remove('active');
        if (successModalTimeout) {
            clearTimeout(successModalTimeout);
            successModalTimeout = null;
        }
        if (typeof onClose === 'function') onClose();
    };

    const closeBtn = document.getElementById('successModalClose');
    if (closeBtn) closeBtn.onclick = cerrar;

    successModalTimeout = setTimeout(cerrar, 5000);
}

// Cerrar sesión
async function cerrarSesionSkate() {
    try {
        await fetch('../php/auth/logout.php', { method: 'POST', credentials: 'same-origin' });
    } catch (error) {
    }
    localStorage.removeItem(SKATE_USERNAME_KEY);
    localStorage.removeItem(SKATE_EMAIL_KEY);
    localStorage.removeItem(SKATE_BIO_KEY);
    localStorage.removeItem(SKATE_AVATAR_KEY);
    window.location.href = 'iniciarsesion.html';
}

// Botones de cerrar sesión
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.dropdown-logout-btn, .settings-logout-btn').forEach((boton) => {
        boton.addEventListener('click', cerrarSesionSkate);
    });
});

// Guardar y leer nombre de usuario
function obtenerNombreUsuario() {
    return localStorage.getItem(SKATE_USERNAME_KEY) || '';
}

function guardarNombreUsuario(nombre) {
    localStorage.setItem(SKATE_USERNAME_KEY, nombre);
}

// Ajustar menú según sesión
function aplicarEstadoSesionEnMenu(autenticado) {
    document.querySelectorAll('.account-dropdown .dropdown-menu').forEach(menu => {
        menu.querySelectorAll('[data-solo]').forEach(item => {
            item.style.display = item.dataset.solo === (autenticado ? 'usuario' : 'invitado') ? '' : 'none';
        });
        const visibles = Array.from(menu.children).filter(el => el.style.display !== 'none');
        visibles.forEach((el, i) => {
            el.style.borderBottom = (el.tagName === 'A' && i === visibles.length - 1) ? 'none' : '';
        });
    });
}

// Mostrar nombre en el header
function actualizarNombreUsuarioEnHeader() {
    const nombre = obtenerNombreUsuario();
    aplicarEstadoSesionEnMenu(nombre !== '');
    document.querySelectorAll('.username').forEach(span => {
        span.textContent = nombre !== '' ? nombre : 'Mi Cuenta';
    });
}

document.addEventListener('DOMContentLoaded', actualizarNombreUsuarioEnHeader);

// Guardar y mostrar foto de perfil
function obtenerAvatarUsuario() {
    return localStorage.getItem(SKATE_AVATAR_KEY) || '';
}

function actualizarAvatarEnHeader() {
    const avatar = obtenerAvatarUsuario();

    document.querySelectorAll('.profile-logo').forEach(el => {
        el.innerHTML = avatar ? `<img src="${avatar}" alt="Foto de perfil">` : '👤';
    });

    const avatarBox = document.getElementById('settingsAvatarBox');
    if (avatarBox) {
        avatarBox.innerHTML = avatar
            ? `<img src="${avatar}" alt="Foto de perfil"><div class="settings-avatar-overlay">Cambiar foto</div>`
            : '<span id="settingsAvatarEmoji">👤</span><div class="settings-avatar-overlay">Cambiar foto</div>';
    }
}

document.addEventListener('DOMContentLoaded', actualizarAvatarEnHeader);
