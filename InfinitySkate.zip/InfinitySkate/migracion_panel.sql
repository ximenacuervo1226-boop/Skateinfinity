-- =========================================================
--  Migración para bases YA importadas (no borra usuarios ni pedidos).
--  Ejecutar UNA sola vez en phpMyAdmin > base skateinfinity > pestaña SQL.
--  Si prefieres empezar de cero, importa SkateInfinity.sql (recrea todo).
-- =========================================================
USE skateinfinity;

-- 1) "Inactivo" pasa a llamarse "Bloqueado"
ALTER TABLE usuarios MODIFY estado ENUM('activo','inactivo','bloqueado') NOT NULL DEFAULT 'activo';
UPDATE usuarios SET estado = 'bloqueado' WHERE estado = 'inactivo';
ALTER TABLE usuarios MODIFY estado ENUM('activo','bloqueado') NOT NULL DEFAULT 'activo';

-- 2) precio_base ahora es el precio ORIGINAL (el descuento se aplica encima).
--    Antes, los 4 productos en oferta guardaban el precio ya rebajado.
UPDATE productos SET precio_base = 129900 WHERE id_producto = 5 AND descuento_porcentaje = 50 AND precio_base = 64900;
UPDATE productos SET precio_base = 79900  WHERE id_producto = 6 AND descuento_porcentaje = 65 AND precio_base = 27900;
UPDATE productos SET precio_base = 219900 WHERE id_producto = 7 AND descuento_porcentaje = 75 AND precio_base = 54900;
UPDATE productos SET precio_base = 59900  WHERE id_producto = 8 AND descuento_porcentaje = 55 AND precio_base = 26900;
