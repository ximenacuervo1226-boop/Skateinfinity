    // Elementos del carrusel
    const slides =
        document.querySelectorAll(".hero-slide");

    const dots =
        document.querySelectorAll(".carousel-dot");

    const nextButton =
        document.getElementById("carouselNext");
    const prevButton =
        document.getElementById("carouselPrev");

    let currentSlide = 0;

    // Mostrar slide indicado
    function mostrarSlide(numero) {
        slides.forEach(slide => {
            slide.classList.remove("active");
        });
        dots.forEach(dot => {
            dot.classList.remove("active");
        });
        slides[numero].classList.add("active");
        dots[numero].classList.add("active");
        currentSlide = numero;
    }

    // Ir al slide siguiente
    function siguienteSlide() {
        currentSlide++;
        if (currentSlide >= slides.length) {
            currentSlide = 0;
        }
        mostrarSlide(currentSlide);
    }

    // Ir al slide anterior
    function anteriorSlide() {
        currentSlide--;
        if (currentSlide < 0) {
            currentSlide =
                slides.length - 1;
        }
        mostrarSlide(currentSlide);
    }

    // Botones siguiente/anterior
    nextButton.addEventListener(
        "click",
        siguienteSlide
    );
    prevButton.addEventListener(
        "click",
        anteriorSlide
    );

    // Puntos del carrusel
    dots.forEach(dot => {
        dot.addEventListener("click", function () {
            const numero =
                parseInt(this.dataset.slide);
            mostrarSlide(numero);
        });
    });

    // Cambio automático cada 5 s
    setInterval(
        siguienteSlide,
        5000
    );
