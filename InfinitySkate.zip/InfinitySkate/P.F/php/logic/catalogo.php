<?php
require_once __DIR__ . '/helpers.php';

// Limpiar texto para comparar
function claveTexto(string $s): string {
    $s = iconv('UTF-8', 'ASCII//TRANSLIT', $s) ?: $s;
    return strtolower(preg_replace('/[^a-z0-9]/i', '', $s));
}

// Ordenar tallas
function ordenTalla(string $t): array {
    $ranking = ['XXS' => 1, 'XS' => 2, 'S' => 3, 'M' => 4, 'L' => 5, 'XL' => 6, 'XXL' => 7, 'XXXL' => 8];
    $u = strtoupper(trim($t));
    if (isset($ranking[$u])) return [0, $ranking[$u], ''];
    if (is_numeric($t)) return [1, (float) $t, ''];
    return [2, 0, $u];
}

// Buscar imágenes por color y vista
function imagenesProducto(string $imagenUrl, array $colores): array {
    $lista = [];
    $prefijo = '../../Imagenes/Productos/';
    if ($imagenUrl === '') return $lista;
    $lista[] = ['src' => $imagenUrl, 'color' => '', 'vista' => ''];
    if (strpos($imagenUrl, $prefijo) !== 0) return $lista;

    $slug = explode('/', substr($imagenUrl, strlen($prefijo)))[0];
    $carpeta = realpath(__DIR__ . '/../../../Imagenes/Productos') . '/' . $slug;
    $archivos = glob($carpeta . '/*.{jpg,jpeg,png,webp,gif}', GLOB_BRACE) ?: [];
    natsort($archivos);

    $porClave = [];
    foreach ($colores as $i => $c) $porClave[claveTexto($c)] = [$c, $i];

    $extra = [];
    foreach ($archivos as $ruta) {
        $archivo = basename($ruta);
        $src = $prefijo . $slug . '/' . $archivo;
        if ($src === $imagenUrl) {
            $lista[0] = array_merge($lista[0], parsearNombreImagen($archivo, $porClave)[0]);
            continue;
        }
        if (strpos($archivo, 'portada-') === 0) continue;
        [$datos, $orden] = parsearNombreImagen($archivo, $porClave);
        $extra[] = ['orden' => $orden, 'img' => array_merge(['src' => $src], $datos)];
    }
    usort($extra, fn($a, $b) => $a['orden'] <=> $b['orden']);
    foreach ($extra as $e) $lista[] = $e['img'];
    return $lista;
}

// Leer color y vista del nombre de imagen
function parsearNombreImagen(string $archivo, array $porClave): array {
    $nombre = pathinfo($archivo, PATHINFO_FILENAME);
    if (preg_match('/^(.+)-(\d+)-(.+)$/', $nombre, $m)) {
        $clave = claveTexto($m[1]);
        $color = $porClave[$clave][0] ?? '';
        $idx = $porClave[$clave][1] ?? 99;
        return [['color' => $color, 'vista' => $m[3]], $idx * 100 + (int) $m[2]];
    }
    return [['color' => '', 'vista' => ''], 9999];
}

// Categorías que se muestran en la tienda (en orden de creación)
function categoriasTienda(PDO $pdo): array {
    $filtro = columnaExiste($pdo, 'categorias', 'visible') ? 'WHERE visible = 1' : '';
    $filas = $pdo->query("SELECT nombre FROM categorias $filtro ORDER BY id_categoria")->fetchAll();
    return array_map(fn($f) => ['slug' => strtolower($f['nombre']), 'nombre' => $f['nombre']], $filas);
}

// Armar catálogo para la tienda
function catalogoTienda(PDO $pdo): array {
    // Los productos de una categoría oculta tampoco se muestran
    $soloVisibles = columnaExiste($pdo, 'categorias', 'visible') ? ' AND c.visible = 1' : '';
    $productos = $pdo->query(
        "SELECT p.id_producto, p.nombre, p.descripcion, p.precio_base, p.descuento_porcentaje,
                p.imagen_url, p.disponible, c.nombre AS categoria
         FROM productos p
         INNER JOIN categorias c ON c.id_categoria = p.id_categoria
         WHERE p.disponible = 1$soloVisibles
         ORDER BY p.id_producto"
    )->fetchAll();

    $variantes = [];
    foreach ($pdo->query("SELECT id_producto, talla, color, stock FROM variantes_productos ORDER BY id_variante")->fetchAll() as $v) {
        $variantes[(int) $v['id_producto']][] = $v;
    }

    $salida = [];
    foreach ($productos as $p) {
        $id = (int) $p['id_producto'];
        $vars = $variantes[$id] ?? [];
        $colores = [];
        $tallas = [];
        $stock = 0;
        foreach ($vars as $v) {
            if (!in_array($v['color'], $colores, true)) $colores[] = $v['color'];
            if (!in_array($v['talla'], $tallas, true)) $tallas[] = $v['talla'];
            $stock += (int) $v['stock'];
        }
        usort($tallas, fn($a, $b) => ordenTalla($a) <=> ordenTalla($b));

        $base = (float) $p['precio_base'];
        $desc = (float) $p['descuento_porcentaje'];
        $salida[] = [
            'id' => $id,
            'nombre' => $p['nombre'],
            'categoria' => strtolower($p['categoria']),
            'descripcion' => $p['descripcion'],
            'precio' => precioFinal($base, $desc),
            'precio_original' => $base,
            'descuento' => $desc,
            'disponible' => $stock > 0,
            'imagen' => $p['imagen_url'],
            'colores' => $colores,
            'tallas' => $tallas,
            'imagenes' => imagenesProducto((string) $p['imagen_url'], $colores),
        ];
    }
    return $salida;
}
