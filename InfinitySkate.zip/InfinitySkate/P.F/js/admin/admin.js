(function () {
    // Filtrar filas de tablas al escribir
    document.querySelectorAll('input[data-filtra]').forEach(function (input) {
        input.addEventListener('input', function () {
            var texto = input.value.trim().toLowerCase().replace('#', '');
            document.querySelectorAll(input.dataset.filtra + ' tr[data-search]').forEach(function (fila) {
                fila.style.display = (fila.getAttribute('data-search') || '').indexOf(texto) !== -1 ? '' : 'none';
            });
        });
    });

    // Buscar productos en vivo (con espera)
    var buscador = document.getElementById('buscarProductoInput');
    var zona = document.getElementById('tablaProductos');
    if (buscador && zona) {
        var temporizador = null;
        var pedido = 0;
        function buscar() {
            var q = buscador.value.trim();
            var url = 'productos.php' + (q ? '?q=' + encodeURIComponent(q) : '');
            var mio = ++pedido;
            fetch(url, { credentials: 'same-origin', sinCarga: true }) // sin modal: no debe bloquear el buscador
                .then(function (r) { return r.text(); })
                .then(function (html) {
                    if (mio !== pedido) return;
                    var doc = new DOMParser().parseFromString(html, 'text/html');
                    var nueva = doc.getElementById('tablaProductos');
                    if (nueva) zona.innerHTML = nueva.innerHTML;
                    history.replaceState(null, '', url);
                });
        }
        buscador.addEventListener('input', function () {
            clearTimeout(temporizador);
            temporizador = setTimeout(buscar, 300);
        });
        buscador.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') { e.preventDefault(); clearTimeout(temporizador); buscar(); }
        });
    }

    // Previsualizar imagen al elegir archivo
    var inputImg = document.getElementById('input-imagen');
    if (inputImg) {
        inputImg.addEventListener('change', function () {
            var preview = document.getElementById('img-preview');
            var texto = document.getElementById('upload-text');
            if (inputImg.files && inputImg.files[0]) {
                var lector = new FileReader();
                lector.onload = function (ev) {
                    preview.src = ev.target.result;
                    preview.style.display = 'block';
                    if (texto) texto.style.display = 'none';
                };
                lector.readAsDataURL(inputImg.files[0]);
            }
        });
    }

    // Mostrar precio final con descuento
    var precio = document.getElementById('campoPrecio');
    var desc = document.getElementById('campoDescuento');
    var salida = document.getElementById('precioPreview');
    if (precio && desc && salida) {
        function pintar() {
            var p = parseFloat(precio.value) || 0;
            var d = Math.min(90, Math.max(0, parseFloat(desc.value) || 0));
            var f = d > 0 ? Math.floor((p * (1 - d / 100)) / 100 + 1e-9) * 100 : p;
            var fmt = function (n) { return '$' + Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'); };
            salida.innerHTML = d > 0
                ? 'En la tienda se verá: <s class="muted">' + fmt(p) + '</s> <strong>' + fmt(f) + '</strong> (-' + d + '%)'
                : 'En la tienda se verá: <strong>' + fmt(p) + '</strong>';
        }
        precio.addEventListener('input', pintar);
        desc.addEventListener('input', pintar);
        pintar();
    }
})();
