<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/conexion.php';
require_once __DIR__ . '/common.php';

// Exigir sesión iniciada
$idUsuario = exigirSesion();

// Solo permitir GET
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    respuesta(['ok'=>false,'mensaje'=>'Método no permitido.'],405);
}

$idPedido = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Detalle de un pedido
if ($idPedido > 0) {
    $stmt = $pdo->prepare(
        'SELECT id_pedido, fecha_pedido, pago_total, descuento, estado, direccion_envio
         FROM pedidos
         WHERE id_pedido = ? AND id_usuario = ?
         LIMIT 1'
    );
    $stmt->execute([$idPedido, $idUsuario]);
    $pedido = $stmt->fetch();

    if (!$pedido) {
        respuesta(['ok'=>false,'mensaje'=>'Pedido no encontrado.'],404);
    }

    $pedido['pago_total'] = (float)$pedido['pago_total'];
    $pedido['descuento'] = (float)$pedido['descuento'];

    $detalle = $pdo->prepare(
        'SELECT dp.cantidad, dp.precio_unitario, vp.talla, vp.color, p.nombre AS title, p.imagen_url AS img
         FROM detalle_pedidos dp
         INNER JOIN variantes_productos vp ON vp.id_variante = dp.id_variante
         INNER JOIN productos p ON p.id_producto = vp.id_producto
         WHERE dp.id_pedido = ?
         ORDER BY dp.id_detalle ASC'
    );
    $detalle->execute([$idPedido]);
    $items = $detalle->fetchAll();
    foreach ($items as &$item) {
        $item['cantidad'] = (int)$item['cantidad'];
        $item['precio_unitario'] = (float)$item['precio_unitario'];
    }

    respuesta(['ok'=>true,'pedido'=>$pedido,'items'=>$items]);
}

// Listado de pedidos del usuario
$stmt = $pdo->prepare(
    'SELECT id_pedido, fecha_pedido, pago_total, descuento, estado
     FROM pedidos
     WHERE id_usuario = ?
     ORDER BY fecha_pedido DESC, id_pedido DESC'
);
$stmt->execute([$idUsuario]);

$pedidos = $stmt->fetchAll();

foreach ($pedidos as &$pedido) {
    $pedido['pago_total'] = (float)$pedido['pago_total'];
    $pedido['descuento'] = (float)$pedido['descuento'];
}

respuesta(['ok'=>true,'pedidos'=>$pedidos]);
