<?php
require_once __DIR__ . '/../auth/require_admin.php';
require_once __DIR__ . '/../config/conexion.php';
require_once __DIR__ . '/roles.php';

// Buscar usuario a editar
$id = (int) ($_GET['id'] ?? 0);
if (!$id) {
    header('Location: usuarios.php');
    exit;
}

$stmt = $pdo->prepare("SELECT id_usuario, nombre, usuario, correo, rol, estado FROM usuarios WHERE id_usuario = ?");
$stmt->execute([$id]);
$usuario = $stmt->fetch();

if (!$usuario) {
    header('Location: usuarios.php');
    exit;
}

// Saber si edita su propia cuenta
$esYo = $id === (int) $_SESSION['id_usuario'];
$error = null;

// Ver qué puede cambiar el rol actual en este usuario (si nada, volver a la lista)
$permisos = permisosSobreUsuario($miRol, (int) $_SESSION['id_usuario'], $usuario);
if (!$permisos['editar']) {
    header('Location: usuarios.php?msg=sin_permiso');
    exit;
}
$puede = fn(string $campo): bool => in_array($campo, $permisos['campos'], true);

// Guardar solo los campos permitidos
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nuevo = $usuario;
    if ($puede('nombre'))  $nuevo['nombre']  = mb_substr(trim($_POST['nombre'] ?? ''), 0, 100);
    if ($puede('usuario')) $nuevo['usuario'] = trim($_POST['usuario'] ?? '');
    if ($puede('correo'))  $nuevo['correo']  = strtolower(trim($_POST['correo'] ?? ''));
    if ($puede('rol')) {
        $rolPedido = $_POST['rol'] ?? '';
        $nuevo['rol'] = in_array($rolPedido, ['cliente', 'admin', 'propietario'], true) ? $rolPedido : $usuario['rol'];
    }

    if ($nuevo['nombre'] === '') {
        $error = 'El nombre no puede estar vacío.';
    } elseif (!preg_match('/^[a-zA-Z0-9]{3,30}$/', $nuevo['usuario'])) {
        $error = 'El usuario debe tener entre 3 y 30 letras o números, sin espacios ni símbolos.';
    } elseif (!filter_var($nuevo['correo'], FILTER_VALIDATE_EMAIL)) {
        $error = 'El correo no es válido.';
    } else {
        // Revisar que el usuario y el correo no los tenga otra persona
        $repetido = $pdo->prepare("SELECT id_usuario FROM usuarios WHERE (usuario = ? OR correo = ?) AND id_usuario <> ? LIMIT 1");
        $repetido->execute([$nuevo['usuario'], $nuevo['correo'], $id]);
        if ($repetido->fetch()) {
            $error = 'Ese nombre de usuario o correo ya está en uso.';
        } else {
            try {
                $pdo->prepare("UPDATE usuarios SET nombre = ?, usuario = ?, correo = ?, rol = ? WHERE id_usuario = ?")
                    ->execute([$nuevo['nombre'], $nuevo['usuario'], $nuevo['correo'], $nuevo['rol'], $id]);
                if ($esYo) {
                    $_SESSION['usuario'] = $nuevo['usuario'];
                    $_SESSION['nombre'] = $nuevo['nombre'];
                }
                header('Location: usuarios.php?msg=usuario_ok');
                exit;
            } catch (PDOException $e) {
                $error = 'No se pudo guardar. Revisa los datos e inténtalo de nuevo.';
            }
        }
    }
    $usuario = $nuevo;
}
