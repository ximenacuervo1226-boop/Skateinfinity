-- =========================================================
--  Migración: fecha y hora del último inicio de sesión de cada usuario.
--  Para bases YA importadas (no borra nada).
--  Ejecutar UNA sola vez en phpMyAdmin > base skateinfinity > pestaña SQL.
--  Si importas SkateInfinity.sql desde cero, ya incluye esta columna.
-- =========================================================
USE skateinfinity;

ALTER TABLE usuarios ADD COLUMN ultimo_login DATETIME NULL DEFAULT NULL;
