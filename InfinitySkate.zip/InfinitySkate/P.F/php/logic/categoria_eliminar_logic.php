<?php
require_once __DIR__ . '/../auth/require_admin.php';
require_once __DIR__ . '/../config/conexion.php';

// Validar categoría a eliminar
$id = (int) ($_POST['id'] ?? 0);
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !$id) {
    header('Location: categorias.php');
    exit;
}

// No se puede eliminar si todavía tiene productos
$cuenta = $pdo->prepare("SELECT COUNT(*) FROM productos WHERE id_categoria = ?");
$cuenta->execute([$id]);
if ((int) $cuenta->fetchColumn() > 0) {
    header('Location: categorias.php?msg=categoria_con_productos');
    exit;
}

try {
    $pdo->prepare("DELETE FROM categorias WHERE id_categoria = ?")->execute([$id]);
    $msg = 'categoria_eliminada';
} catch (Throwable $e) {
    $msg = 'categoria_error';
}
header('Location: categorias.php?msg=' . $msg);
exit;
