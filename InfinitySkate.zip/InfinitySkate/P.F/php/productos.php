<?php
// Cargar lógica y estructura del admin
require_once __DIR__ . '/logic/productos_logic.php';
require_once __DIR__ . '/logic/admin_layout.php';
adminInicio('Gestión de Productos', 'productos');

// Crear enlace de paginación
function urlPagina(int $pagina, string $q): string {
    $partes = [];
    if ($q !== '') $partes['q'] = $q;
    if ($pagina > 1) $partes['pagina'] = $pagina;
    return 'productos.php' . ($partes ? '?' . http_build_query($partes) : '');
}
?>
        <?php // Tabla de productos ?>
        <div class="table-container">
            <?php // Buscador y botón nuevo producto ?>
            <div class="table-header-action">
                <input type="text" id="buscarProductoInput" class="search-input" placeholder="Buscar por nombre, categoría o #ID..." value="<?= e($q) ?>" autocomplete="off">
                <div class="header-botones">
                    <a href="crear_producto.php" class="btn-nuevo-producto">+ Nuevo producto</a>
                </div>
            </div>

            <div id="tablaProductos">
                <div class="table-scroll">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th><th>Imagen</th><th>Nombre</th><th>Categoría</th>
                                <th>Precio</th><th>Stock</th><th>En tienda</th><th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php // Filas de productos ?>
                            <?php if (empty($productos)): ?>
                                <tr><td colspan="8" class="empty"><?= $q !== '' ? 'No hay productos que coincidan con tu búsqueda.' : 'No hay productos registrados.' ?></td></tr>
                            <?php else: foreach ($productos as $p):
                                $desc = (float) $p['descuento_porcentaje'];
                                $final = precioFinal((float) $p['precio_base'], $desc);
                            ?>
                                <tr>
                                    <td>#<?= (int) $p['id_producto'] ?></td>
                                    <td>
                                        <?php if (!empty($p['imagen_url'])): ?>
                                            <img src="<?= e($p['imagen_url']) ?>" alt="" class="producto-foto" onerror="this.style.display='none'">
                                        <?php else: ?><span class="muted">Sin foto</span><?php endif; ?>
                                    </td>
                                    <td><?= e($p['nombre']) ?><?php if ($desc > 0): ?><span class="tag-desc">-<?= rtrim(rtrim(number_format($desc, 2, '.', ''), '0'), '.') ?>%</span><?php endif; ?></td>
                                    <td><?= e(ucfirst($p['categoria_nombre'] ?? 'Sin categoría')) ?></td>
                                    <td>
                                        <?php if ($desc > 0): ?><span class="precio-original"><?= dinero($p['precio_base']) ?></span><?php endif; ?>
                                        <?= dinero($final) ?>
                                    </td>
                                    <td><?= (int) $p['stock_total'] ?></td>
                                    <td><span class="badge <?= $p['disponible'] ? 'badge-visible' : 'badge-oculto' ?>"><?= $p['disponible'] ? 'Visible' : 'Oculto' ?></span></td>
                                    <td>
                                        <?php // Botones editar y eliminar ?>
                                        <div class="acciones">
                                            <a href="editar_producto.php?id=<?= (int) $p['id_producto'] ?>" class="btn-mini btn-editar">Editar</a>
                                            <form method="POST" action="eliminar_producto.php" onsubmit="return confirm('¿Eliminar «<?= e(addslashes($p['nombre'])) ?>»? Esta acción no se puede deshacer.');">
                                                <input type="hidden" name="id" value="<?= (int) $p['id_producto'] ?>">
                                                <button type="submit" class="btn-mini btn-peligro">Eliminar</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php // Paginación ?>
                <?php if ($totalPaginas > 1): ?>
                <div class="paginacion">
                    <a href="<?= urlPagina(max(1, $paginaActual - 1), $q) ?>" class="pagina-link <?= $paginaActual <= 1 ? 'deshabilitado' : '' ?>">&laquo; Anterior</a>
                    <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
                        <a href="<?= urlPagina($i, $q) ?>" class="pagina-link <?= $i === $paginaActual ? 'pagina-activa' : '' ?>"><?= $i ?></a>
                    <?php endfor; ?>
                    <a href="<?= urlPagina(min($totalPaginas, $paginaActual + 1), $q) ?>" class="pagina-link <?= $paginaActual >= $totalPaginas ? 'deshabilitado' : '' ?>">Siguiente &raquo;</a>
                </div>
                <?php endif; ?>
            </div>
        </div>
<?php adminFin(); ?>
