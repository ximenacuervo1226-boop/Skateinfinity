<?php
require_once __DIR__ . '/../auth/require_admin.php';
require_once __DIR__ . '/../config/conexion.php';
require_once __DIR__ . '/helpers.php';

// Listar categorías con cuántos productos tiene cada una
$tieneOpciones = columnaExiste($pdo, 'categorias', 'requiere_talla');
$campos = $tieneOpciones
    ? 'c.requiere_talla, c.requiere_color, c.visible'
    : '1 AS requiere_talla, 1 AS requiere_color, 1 AS visible';
$categorias = $pdo->query(
    "SELECT c.id_categoria, c.nombre, c.descripcion, $campos,
            (SELECT COUNT(*) FROM productos p WHERE p.id_categoria = c.id_categoria) AS total_productos
     FROM categorias c
     ORDER BY c.id_categoria"
)->fetchAll();
