/* ============================================================
   Modal de carga global (Cargando...)
   - Se muestra mientras carga la página y mientras algo se procesa.
   - Bloquea toda la web (mouse, teclado y scroll) hasta terminar.
   - Uso manual: Cargando.mostrar(); Cargando.ocultar(); Cargando.envolver(promesa)
   ============================================================ */
(function () {
    if (window.Cargando) return;

    // Tiempos en milisegundos
    var RETARDO_PETICION = 350;   // una petición rápida no muestra el modal
    var RETARDO_NAVEGACION = 400; // un clic en un enlace lento muestra el modal
    var MINIMO_VISIBLE = 500;     // evita parpadeos cuando termina muy rápido
    var TOPE_CARGA_INICIAL = 25000;
    var TOPE_ENVIO = 60000;
    var TOPE_NAVEGACION = 15000;

    var activos = 0;          // cuántos procesos están pidiendo el modal
    var visible = false;
    var mostradoEn = 0;
    var temporizadorCierre = null;
    var overlay = null;
    var bloqueados = [];      // elementos de la web marcados como inertes

    // Ruta de la animación, calculada a partir de la ruta de este script
    var scriptActual = document.currentScript;
    var rutaAnimacion = scriptActual && scriptActual.src
        ? new URL('../../img/cargando.webp', scriptActual.src).href
        : '../img/cargando.webp';

    // Crear el modal una sola vez
    function crearOverlay() {
        if (overlay) return overlay;

        overlay = document.createElement('div');
        overlay.className = 'cargando-overlay';
        overlay.setAttribute('role', 'alert');
        overlay.setAttribute('aria-live', 'assertive');
        overlay.setAttribute('aria-label', 'Cargando');
        overlay.innerHTML =
            '<div class="cargando-caja">' +
                '<img class="cargando-anim" alt="" draggable="false">' +
                '<div class="cargando-texto">Cargando' +
                    '<span class="cargando-puntos" aria-hidden="true">' +
                        '<span class="p1">.</span><span class="p2">.</span><span class="p3">.</span>' +
                    '</span>' +
                '</div>' +
            '</div>';

        var img = overlay.querySelector('.cargando-anim');
        img.addEventListener('error', function () { img.classList.add('sin-imagen'); });
        img.src = rutaAnimacion;

        // Impedir cualquier clic o toque sobre la capa
        ['click', 'mousedown', 'touchstart', 'contextmenu'].forEach(function (tipo) {
            overlay.addEventListener(tipo, function (e) { e.preventDefault(); e.stopPropagation(); });
        });

        (document.body || document.documentElement).appendChild(overlay);
        return overlay;
    }

    // Marcar la web de atrás como no interactiva (teclado y lectores de pantalla)
    function bloquearWeb() {
        if (!document.body) return;
        Array.prototype.forEach.call(document.body.children, function (el) {
            if (el === overlay || el.inert || el.tagName === 'SCRIPT') return;
            el.inert = true;
            bloqueados.push(el);
        });
        if (document.activeElement && document.activeElement !== document.body) {
            document.activeElement.blur();
        }
    }

    function liberarWeb() {
        bloqueados.forEach(function (el) { el.inert = false; });
        bloqueados = [];
    }

    // Mostrar el modal
    function abrir() {
        clearTimeout(temporizadorCierre);
        if (visible) return;
        crearOverlay();
        visible = true;
        mostradoEn = Date.now();
        document.documentElement.classList.add('cargando-activo');
        bloquearWeb();
        // Forzar un repintado para que la transición de entrada funcione
        void overlay.offsetWidth;
        overlay.classList.add('visible');
    }

    // Ocultar el modal
    function cerrar() {
        if (!visible) return;
        visible = false;
        overlay.classList.remove('visible');
        document.documentElement.classList.remove('cargando-activo');
        liberarWeb();
    }

    // Pedir el modal (se pueden apilar varios procesos)
    function mostrar() {
        activos++;
        if (activos === 1) abrir();
    }

    // Soltar el modal (se cierra cuando ya no queda ningún proceso)
    function ocultar() {
        if (activos > 0) activos--;
        if (activos > 0) return;
        var restante = Math.max(0, MINIMO_VISIBLE - (Date.now() - mostradoEn));
        clearTimeout(temporizadorCierre);
        temporizadorCierre = setTimeout(function () {
            if (activos === 0) cerrar();
        }, restante);
    }

    // Mostrar el modal mientras dure una promesa
    function envolver(promesa) {
        mostrar();
        var fin = function () { ocultar(); };
        Promise.resolve(promesa).then(fin, fin);
        return promesa;
    }

    // Crear un proceso que se libera una sola vez (con tope de seguridad)
    function procesoUnico(tope) {
        var liberado = false;
        mostrar();
        var soltar = function () {
            if (liberado) return;
            liberado = true;
            ocultar();
        };
        if (tope) setTimeout(soltar, tope);
        return soltar;
    }

    // 1) Carga inicial de la página
    if (document.readyState !== 'complete') {
        var soltarCargaInicial = procesoUnico(TOPE_CARGA_INICIAL);
        window.addEventListener('load', soltarCargaInicial);
    }

    // Pasar el modal al body cuando exista
    document.addEventListener('DOMContentLoaded', function () {
        if (overlay && overlay.parentNode !== document.body) document.body.appendChild(overlay);
        if (visible) bloquearWeb();
    });

    // 2) Peticiones al servidor (fetch): solo se muestra si tardan
    var fetchOriginal = window.fetch;
    if (typeof fetchOriginal === 'function') {
        window.fetch = function (entrada, opciones) {
            // Las peticiones marcadas con { sinCarga: true } no muestran el modal
            if (opciones && opciones.sinCarga) return fetchOriginal.apply(this, arguments);

            var mostrado = false;
            var espera = setTimeout(function () { mostrado = true; mostrar(); }, RETARDO_PETICION);
            var fin = function () {
                clearTimeout(espera);
                if (mostrado) { mostrado = false; ocultar(); }
            };
            var promesa = fetchOriginal.apply(this, arguments);
            promesa.then(fin, fin);
            return promesa;
        };
    }

    // 3) Formularios que recargan la página (panel de administración)
    document.addEventListener('submit', function (e) {
        if (e.defaultPrevented) return; // validación fallida o confirmación cancelada
        var form = e.target;
        if (!form || (form.target && form.target !== '_self')) return;
        procesoUnico(TOPE_ENVIO);
    });

    // Formularios enviados desde código (ej. this.form.submit())
    var enviarOriginal = HTMLFormElement.prototype.submit;
    HTMLFormElement.prototype.submit = function () {
        if (!this.target || this.target === '_self') procesoUnico(TOPE_ENVIO);
        return enviarOriginal.apply(this, arguments);
    };

    // 4) Navegación entre páginas lenta
    document.addEventListener('click', function (e) {
        if (e.defaultPrevented || e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
        var enlace = e.target.closest ? e.target.closest('a[href]') : null;
        if (!enlace || enlace.hasAttribute('download')) return;
        if (enlace.target && enlace.target !== '_self') return;

        var destino;
        try { destino = new URL(enlace.href, location.href); } catch (err) { return; }
        if (destino.origin !== location.origin || !/^https?:$/.test(destino.protocol)) return;
        if (destino.pathname === location.pathname && destino.search === location.search) return;

        var soltar = null;
        var espera = setTimeout(function () { soltar = procesoUnico(TOPE_NAVEGACION); }, RETARDO_NAVEGACION);
        window.addEventListener('pageshow', function () {
            clearTimeout(espera);
            if (soltar) soltar();
        }, { once: true });
    });

    // 5) Bloquear el teclado mientras el modal está visible
    document.addEventListener('keydown', function (e) {
        if (!visible) return;
        if (e.ctrlKey || e.metaKey || /^F\d+$/.test(e.key)) return; // recargar, herramientas, etc.
        e.preventDefault();
        e.stopPropagation();
    }, true);

    // Volver con el botón "atrás" (caché del navegador): quitar el modal
    window.addEventListener('pageshow', function (e) {
        if (!e.persisted) return;
        activos = 0;
        clearTimeout(temporizadorCierre);
        cerrar();
    });

    // Mostrar ya el modal si la página está cargando (antes de pintar el contenido)
    if (activos > 0) abrir();

    window.Cargando = { mostrar: mostrar, ocultar: ocultar, envolver: envolver };
})();
