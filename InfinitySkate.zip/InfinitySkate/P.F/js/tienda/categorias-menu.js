// Agrega a los menús las categorías nuevas creadas desde el panel de administración
(function () {
    const CATEGORIAS = Array.isArray(window.CATALOGO_CATEGORIAS) ? window.CATALOGO_CATEGORIAS : [];
    if (!CATEGORIAS.length) return;

    const mayus = (t) => t.charAt(0).toUpperCase() + t.slice(1);
    const enlaceCategoria = (slug) => 'categorias.html?cat=' + encodeURIComponent(slug);

    // Leer la categoría de un enlace del menú (href con ?cat=)
    function categoriaDeHref(a) {
        try {
            return new URL(a.getAttribute('href'), window.location.href).searchParams.get('cat');
        } catch (e) {
            return null;
        }
    }

    // Crear un enlace de categoría
    function crearEnlace(texto, href, clase) {
        const a = document.createElement('a');
        a.textContent = texto;
        a.setAttribute('href', href);
        if (clase) a.className = clase;
        return a;
    }

    // Menús con enlaces a categorias.html?cat=... (menú del header y lista de categorías)
    document.querySelectorAll('.category-dropdown-container .dropdown-menu, .store-main > .dropdown-menu').forEach((menu) => {
        const existentes = Array.from(menu.querySelectorAll('a')).map(categoriaDeHref);
        const todas = menu.querySelector('a[href="categorias.html#todas-categorias"]');

        CATEGORIAS.forEach((c) => {
            if (existentes.indexOf(c.slug) >= 0) return;
            const enlace = crearEnlace(mayus(c.slug), enlaceCategoria(c.slug));
            menu.insertBefore(enlace, todas);
        });
    });

    // Filtro de categorías de las promociones
    const filtroPromos = document.getElementById('discountsFilterBar');
    if (filtroPromos) {
        const existentes = Array.from(filtroPromos.querySelectorAll('a[data-cat]')).map((a) => a.dataset.cat);

        CATEGORIAS.forEach((c) => {
            if (existentes.indexOf(c.slug) >= 0) return;
            const separador = document.createElement('span');
            separador.className = 'separator';
            separador.textContent = '◦';
            const enlace = crearEnlace(mayus(c.slug), '#');
            enlace.dataset.cat = c.slug;
            filtroPromos.appendChild(separador);
            filtroPromos.appendChild(enlace);
        });
    }

    // Categorías de la página de inicio (landing)
    const gridLanding = document.querySelector('.landing-category-grid');
    if (gridLanding) {
        const existentes = Array.from(gridLanding.querySelectorAll('a')).map(categoriaDeHref);

        CATEGORIAS.forEach((c) => {
            if (existentes.indexOf(c.slug) >= 0) return;
            gridLanding.appendChild(crearEnlace(mayus(c.slug), enlaceCategoria(c.slug), 'landing-category'));
        });
    }
})();
