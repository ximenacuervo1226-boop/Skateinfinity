<?php

require_once __DIR__ . '/../auth/require_admin.php';

// Escapar texto para HTML
function e($v): string {
    return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
}

// Dar formato a fecha y hora (12 horas): 21/10/2026 03:45 PM
function fechaHora($valor): string {
    if (!$valor) return '—';
    $t = strtotime((string) $valor);
    return $t ? date('d/m/Y h:i A', $t) : '—';
}

// Dar formato al dinero
function dinero($n): string {
    return '$' . number_format((float) $n, 0, ',', '.');
}

// Mensajes de aviso del admin
function adminAviso(?string $codigo): string {
    $mensajes = [
        'creado'          => ['ok', 'Producto creado. Ahora agrega sus tallas, colores y stock.'],
        'guardado'        => ['ok', 'Cambios guardados. Ya se ven en la tienda.'],
        'eliminado'       => ['ok', 'Producto eliminado.'],
        'oculto'          => ['warn', 'El producto tiene pedidos en su historial, así que no se puede borrar del todo. Se ocultó de la tienda.'],
        'variante_ok'     => ['ok', 'Variante guardada.'],
        'variante_repetida' => ['error', 'Ya existe una variante con esa talla y color.'],
        'variante_borrada'  => ['ok', 'Variante eliminada.'],
        'variante_en_pedidos' => ['error', 'Esa variante tiene pedidos asociados; déjala en stock 0 en lugar de eliminarla.'],
        'usuario_ok'      => ['ok', 'Usuario actualizado.'],
        'bloqueado'       => ['ok', 'Usuario bloqueado. Ya no podrá iniciar sesión.'],
        'desbloqueado'    => ['ok', 'Usuario desbloqueado.'],
        'no_self'         => ['error', 'No puedes bloquearte a ti mismo.'],
        'pedido_ok'       => ['ok', 'Estado del pedido actualizado.'],
        'sin_permiso'     => ['error', 'No tienes permiso para hacer eso con ese usuario.'],
        'categoria_creada' => ['ok', 'Categoría creada. Ya puedes usarla al crear productos.'],
        'categoria_guardada' => ['ok', 'Categoría actualizada.'],
        'categoria_eliminada' => ['ok', 'Categoría eliminada.'],
        'categoria_con_productos' => ['error', 'Esa categoría tiene productos, así que no se puede eliminar. Mueve o elimina sus productos primero, o simplemente ocúltala.'],
        'categoria_error' => ['error', 'No se pudo completar la acción. Revisa que la base de datos tenga la migración migracion_roles_categorias.sql.'],
    ];
    if (!$codigo || !isset($mensajes[$codigo])) return '';
    [$tipo, $texto] = $mensajes[$codigo];
    return '<div class="alert alert-' . $tipo . '">' . e($texto) . '</div>';
}

// Abrir página del admin
function adminInicio(string $titulo, string $activo): void {
    // Rol de quien está usando el panel (lo define require_admin.php)
    global $miRol;
    // Íconos y enlaces del menú
    $iconos = [
        'inicio'    => '<path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
        'productos' => '<path d="M21 8l-9-5-9 5v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>',
        'categorias' => '<path d="M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z"/>',
        'pedidos'   => '<path d="M6 2h12v20l-3-2-3 2-3-2-3 2z"/><path d="M9 7h6M9 11h6"/>',
        'usuarios'  => '<circle cx="9" cy="8" r="3.5"/><path d="M2 21c0-4 3-6 7-6s7 2 7 6"/><path d="M17 4.5a3.5 3.5 0 0 1 0 7M22 21c0-3-1.5-5-4-5.7"/>',
    ];
    $enlaces = [
        'inicio'    => ['admin.php', 'Inicio'],
        'productos' => ['productos.php', 'Productos'],
        'categorias' => ['categorias.php', 'Categorías'],
        'pedidos'   => ['pedidos_admin.php', 'Pedidos'],
        'usuarios'  => ['usuarios.php', 'Usuarios'],
    ];
    ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Skate∞ - <?= e($titulo) ?></title>
    <link rel="icon" type="image/png" href="../../Imagenes/favicon.png">
    <link rel="shortcut icon" href="../../Imagenes/favicon.ico">
    <link rel="stylesheet" href="../css/admin_styles.css">
    <link rel="stylesheet" href="../css/shared/cargando.css">
    <script src="../js/shared/cargando.js"></script>
</head>
<body>
    <?php // Menú lateral ?>
    <aside class="sidebar">
        <a href="admin.php" class="brand">Skate<span>∞</span></a>
        <div class="menu-title">Administración</div>
        <ul class="nav-links">
            <?php foreach ($enlaces as $clave => [$url, $texto]): ?>
                <li>
                    <a href="<?= $url ?>" class="<?= $clave === $activo ? 'active' : '' ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><?= $iconos[$clave] ?></svg>
                        <?= $texto ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </aside>

    <main class="main-content">
        <?php // Encabezado superior ?>
        <header class="top-bar">
            <h1 class="page-title"><?= e($titulo) ?></h1>
            <div class="user-info">
                <span class="user-role"><?= $miRol === 'propietario' ? 'Propietario' : 'Administrador' ?></span>
                <a href="../html/principal.html" class="btn-logout" title="Volver a la tienda">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/></svg>
                    Salir
                </a>
            </div>
        </header>
        <?= adminAviso($_GET['msg'] ?? null) ?>
<?php
}

// Cerrar página del admin
function adminFin(): void {
    ?>
    </main>
    <script src="../js/admin/admin.js" defer></script>
</body>
</html>
<?php
}
