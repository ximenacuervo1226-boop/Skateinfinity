// Mensajes de validación en español
document.querySelectorAll('input[required], textarea[required], select[required]').forEach((input) => {
    input.addEventListener('invalid', () => {
        if (input.validity.valueMissing) {
            input.setCustomValidity('Este campo es obligatorio.');
        } else if (input.validity.typeMismatch) {
            input.setCustomValidity('Ingresa un correo electrónico válido.');
        } else if (input.validity.patternMismatch) {
            input.setCustomValidity(input.title || 'El valor ingresado no cumple con el formato requerido.');
        }
    });

    input.addEventListener('input', () => {
        input.setCustomValidity('');
    });
});

// Mostrar/ocultar contraseña
function toggleVisibility(inputId, btn) {
            const input = document.getElementById(inputId);
            if (input.type === "password") {
                input.type = "text";
                btn.textContent = "🐵";
                btn.title = "Ocultar contraseña";
            } else {
                input.type = "password";
                btn.textContent = "🙈";
                btn.title = "Mostrar contraseña";
            }
        }

        // Sincronizar sesión con el servidor
        async function actualizarSesionDesdeServidor() {
    try {
        const response = await fetch('../php/auth/session.php', { credentials: 'same-origin' });
        const data = await response.json();

        if (data.autenticado && data.usuario) {
            const nombre = data.usuario.usuario || data.usuario.nombre || '';
            localStorage.setItem(SKATE_USERNAME_KEY, nombre);
            document.querySelectorAll('.username').forEach(span => {
                span.textContent = nombre || 'Mi Cuenta';
            });

            if (data.usuario.foto_perfil) {
                localStorage.setItem(SKATE_AVATAR_KEY, data.usuario.foto_perfil);
            } else {
                localStorage.removeItem(SKATE_AVATAR_KEY);
            }
            actualizarAvatarEnHeader();
            aplicarEstadoSesionEnMenu(true);
            mostrarBotonAdmin(data.usuario.rol === 'admin' || data.usuario.rol === 'propietario');
        } else if (data.autenticado === false) {
            mostrarBotonAdmin(false);
            if (data.bloqueado) mostrarModalBloqueado();
            localStorage.removeItem(SKATE_USERNAME_KEY);
            localStorage.removeItem(SKATE_AVATAR_KEY);
            document.querySelectorAll('.username').forEach(span => {
                span.textContent = 'Mi Cuenta';
            });
            actualizarAvatarEnHeader();
            aplicarEstadoSesionEnMenu(false);
        }
    } catch (error) {
    }
}

document.addEventListener('DOMContentLoaded', actualizarSesionDesdeServidor);
