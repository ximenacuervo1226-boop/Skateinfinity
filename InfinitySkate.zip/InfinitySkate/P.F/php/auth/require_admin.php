<?php
declare(strict_types=1);

// Iniciar sesión si no está activa
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../config/conexion.php';
require_once __DIR__ . '/../logic/roles.php';

// Verificar que sea admin o propietario activo
$adminValido = false;
$miRol = null;
if (!empty($_SESSION['id_usuario'])) {
    $chk = $pdo->prepare('SELECT rol, estado FROM usuarios WHERE id_usuario = ?');
    $chk->execute([(int) $_SESSION['id_usuario']]);
    $filaAdmin = $chk->fetch();
    $adminValido = $filaAdmin && in_array($filaAdmin['rol'], ROLES_PANEL, true) && $filaAdmin['estado'] !== 'bloqueado';
    if ($adminValido) $miRol = $filaAdmin['rol'];
}

// Redirigir si no es admin
if (!$adminValido) {
    header('Location: ../html/iniciarsesion.html');
    exit;
}
