<?php
require_once __DIR__ . '/../auth/require_admin.php';
require_once __DIR__ . '/../config/conexion.php';

// Totales y últimos pedidos
try {
    $totalVentas = (float) ($pdo->query("SELECT COALESCE(SUM(pago_total),0) FROM pedidos WHERE LOWER(estado) <> 'cancelado'")->fetchColumn());
    $totalPedidos = (int) ($pdo->query("SELECT COUNT(*) FROM pedidos")->fetchColumn());
    $totalProductos = (int) ($pdo->query("SELECT COUNT(*) FROM productos")->fetchColumn());
    $totalClientes = (int) ($pdo->query("SELECT COUNT(*) FROM usuarios WHERE rol = 'cliente'")->fetchColumn());

    $ultimosPedidos = $pdo->query(
        "SELECT p.id_pedido, p.fecha_pedido, p.pago_total, p.estado, u.nombre AS cliente_nombre
         FROM pedidos p
         LEFT JOIN usuarios u ON p.id_usuario = u.id_usuario
         ORDER BY p.id_pedido DESC LIMIT 5"
    )->fetchAll();
// Valores vacíos si falla
} catch (Exception $e) {
    $totalVentas = 0;
    $totalPedidos = 0;
    $totalProductos = 0;
    $totalClientes = 0;
    $ultimosPedidos = [];
}
