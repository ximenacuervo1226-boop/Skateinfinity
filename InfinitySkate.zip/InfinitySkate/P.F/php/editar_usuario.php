<?php
// Cargar lógica y estructura del admin
require_once __DIR__ . '/logic/usuario_editar_logic.php';
require_once __DIR__ . '/logic/admin_layout.php';
adminInicio('Editar Usuario', 'usuarios');
?>
        <?php // Mensaje de error ?>
        <?php if ($error): ?><div class="error-box"><?= e($error) ?></div><?php endif; ?>

        <?php // Formulario de edición de usuario ?>
        <form method="POST" class="form-card" style="max-width:560px;">
            <?php // Los campos que el rol actual no puede cambiar salen bloqueados ?>
            <div class="form-group">
                <label>Nombre</label>
                <input type="text" name="nombre" value="<?= e($usuario['nombre']) ?>" maxlength="100" <?= $puede('nombre') ? 'required' : 'disabled' ?>>
            </div>
            <div class="form-group">
                <label>Correo</label>
                <input type="email" name="correo" value="<?= e($usuario['correo']) ?>" maxlength="150" <?= $puede('correo') ? 'required' : 'disabled' ?>>
                <?php if (!$puede('correo')): ?><p class="hint">Solo el propietario puede cambiar el correo.</p><?php endif; ?>
            </div>
            <div class="form-group">
                <label>Nombre de usuario (@)</label>
                <input type="text" name="usuario" value="<?= e($usuario['usuario']) ?>" maxlength="30" <?= $puede('usuario') ? 'required' : 'disabled' ?>>
                <p class="hint">Solo letras y números, sin espacios.</p>
            </div>
            <?php // Rol del usuario: solo el propietario puede cambiarlo ?>
            <div class="form-group">
                <label>Rol</label>
                <select name="rol" <?= $puede('rol') ? '' : 'disabled' ?>>
                    <option value="cliente" <?= $usuario['rol'] === 'cliente' ? 'selected' : '' ?>>Cliente</option>
                    <option value="admin" <?= $usuario['rol'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                    <option value="propietario" <?= $usuario['rol'] === 'propietario' ? 'selected' : '' ?>>Propietario</option>
                </select>
                <?php if ($esYo): ?>
                    <p class="hint">No puedes cambiar tu propio rol.</p>
                <?php elseif (!$puede('rol')): ?>
                    <p class="hint">Solo el propietario puede cambiar el rol.</p>
                <?php else: ?>
                    <p class="hint">Un propietario no puede ser modificado por otros propietarios.</p>
                <?php endif; ?>
            </div>
            <?php // Botones guardar y cancelar ?>
            <div style="margin-top:20px;">
                <button type="submit" class="btn-primary">Guardar cambios</button>
                <a href="usuarios.php" class="btn-link">Cancelar</a>
            </div>
        </form>
<?php adminFin(); ?>
