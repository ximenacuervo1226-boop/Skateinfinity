// Registrar usuario nuevo
async function validarFormulario(event) {
    event.preventDefault();

    const form = event.currentTarget;
    const email = document.getElementById('email').value.trim().toLowerCase();
    const confirmEmail = document.getElementById('confirmEmail').value.trim().toLowerCase();
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    if (email !== confirmEmail) {
        alert('Los correos electrónicos no coinciden.');
        return false;
    }

    if (password !== confirmPassword) {
        alert('Las contraseñas no coinciden.');
        return false;
    }

    const nombre = form.querySelector('input[name="nombre"]')?.value.trim() || '';
    const usuario = document.getElementById('usuario')?.value.trim() || '';
    const telefono = form.querySelector('input[name="telefono"]')?.value.trim() || '';
    const fechaNacimiento = form.querySelector('input[name="fecha_nacimiento"]')?.value || '';

    try {
        const response = await fetch('../php/auth/register.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin',
            body: JSON.stringify({
                nombre,
                usuario,
                telefono,
                fecha_nacimiento: fechaNacimiento,
                correo: email,
                password
            })
        });

        const data = await response.json();

        if (!response.ok || !data.ok) {
            alert(data.mensaje || 'No se pudo completar el registro.');
            return false;
        }

        localStorage.setItem(SKATE_USERNAME_KEY, data.usuario);
        alert('Registro exitoso. Ahora puedes iniciar sesión.');
        window.location.href = 'iniciarsesion.html';
    } catch (error) {
        alert('No se pudo conectar con el servidor PHP. Asegúrate de tener Apache y MySQL encendidos en XAMPP.');
    }

    return false;
}

// Eventos del formulario de registro
const registroForm = document.getElementById('email') ? document.getElementById('email').form : null;
if (registroForm) {
    registroForm.addEventListener('submit', validarFormulario);

    const nombreCompleto = registroForm.querySelector('input[name="nombre"]');
    const telefono = registroForm.querySelector('input[name="telefono"]');
    const fechaNacimiento = registroForm.querySelector('input[name="fecha_nacimiento"]');

    if (nombreCompleto) {
        nombreCompleto.addEventListener('input', () => {
            nombreCompleto.value = nombreCompleto.value.toLowerCase();
        });
    }

    if (telefono) {
        telefono.addEventListener('input', () => {
            telefono.value = telefono.value.replace(/[^0-9]/g, '').slice(0, 10);
        });
    }

    if (fechaNacimiento) {
        fechaNacimiento.addEventListener('focus', () => {
            fechaNacimiento.type = 'date';
        });

        fechaNacimiento.addEventListener('blur', () => {
            if (!fechaNacimiento.value) fechaNacimiento.type = 'text';
        });
    }

    registroForm.querySelectorAll('.toggle-password').forEach((button) => {
        button.addEventListener('click', () => {
            const input = button.parentElement.querySelector('input');
            if (input) toggleVisibility(input.id, button);
        });
    });

    const regresarButton = registroForm.querySelector('.btn-register');
    if (regresarButton) {
        regresarButton.addEventListener('click', () => {
            window.location.href = 'iniciarsesion.html';
        });
    }
}

// Iniciar sesión
async function validarLogin(event) {
    event.preventDefault();

    const userInput = document.getElementById('userInput').value.trim();
    const password = document.getElementById('password').value;

    const emailRegex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;
    const usernameRegex = /^[a-zA-Z0-9]+$/;

    const esCorreoValido = emailRegex.test(userInput);
    const esUsuarioValido = usernameRegex.test(userInput);

    if (!esCorreoValido && !esUsuarioValido) {
        alert('Ingresa un correo electrónico terminado en @gmail.com o un usuario que solo contenga letras y números sin caracteres especiales.');
        return false;
    }

    try {
        const response = await fetch('../php/auth/login.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin',
            body: JSON.stringify({
                usuario_correo: userInput,
                password
            })
        });

        const data = await response.json();

        if (data.bloqueado) {
            mostrarModalBloqueado();
            return false;
        }

        if (!response.ok || !data.ok) {
            alert(data.mensaje || 'No se pudo iniciar sesión.');
            return false;
        }

        const usuario = data.usuario.usuario || data.usuario.nombre;
        localStorage.setItem(SKATE_USERNAME_KEY, usuario);
        localStorage.setItem(SKATE_EMAIL_KEY, data.usuario.correo || '');
        localStorage.removeItem('skate_cart');
        window.location.href = 'principal.html';
    } catch (error) {
        alert('No se pudo conectar con el servidor PHP. Asegúrate de tener Apache y MySQL encendidos en XAMPP.');
    }

    return false;
}

// Eventos del formulario de login
const loginForm = document.getElementById('userInput') ? document.getElementById('userInput').form : null;
if (loginForm) {
    loginForm.addEventListener('submit', validarLogin);

    loginForm.querySelectorAll('.toggle-password').forEach((button) => {
        button.addEventListener('click', () => {
            const input = button.parentElement.querySelector('input');
            if (input) toggleVisibility(input.id, button);
        });
    });

    const registrarseButton = loginForm.querySelector('.btn-register');
    if (registrarseButton) {
        registrarseButton.addEventListener('click', () => {
            window.location.href = 'registrarse.html';
        });
    }
}
