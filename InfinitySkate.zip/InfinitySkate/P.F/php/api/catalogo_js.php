<?php

// Responder como JavaScript sin caché
header('Content-Type: application/javascript; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

// Cargar catálogo de productos
$lista = [];
$categorias = [];
try {
    require_once __DIR__ . '/../config/conexion.php';
    require_once __DIR__ . '/../logic/catalogo.php';
    $lista = catalogoTienda($pdo);
    $categorias = categoriasTienda($pdo);
} catch (Throwable $e) {
    $lista = [];
    $categorias = [];
}

// Armar mapa de productos por id
$mapa = [];
foreach ($lista as $p) {
    $mapa[$p['id']] = [
        'nombre' => $p['nombre'],
        'categoria' => $p['categoria'],
        'precio' => $p['precio'],
        'descripcion' => $p['descripcion'],
        'colores' => $p['colores'],
        'tallas' => $p['tallas'],
        'imagenes' => $p['imagenes'],
    ];
}
// Enviar catálogo al navegador
$flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;
echo 'window.CATALOGO_SKATE = ' . json_encode((object) $mapa, $flags) . ";\n";
echo 'window.CATALOGO_LISTA = ' . json_encode($lista, $flags) . ";\n";
echo 'window.CATALOGO_CATEGORIAS = ' . json_encode($categorias, $flags) . ";\n";
