<?php

// Crear slug desde texto
function slugify(string $texto): string {
    $texto = iconv('UTF-8', 'ASCII//TRANSLIT', $texto) ?: $texto;
    $texto = strtolower($texto);
    $texto = preg_replace('/[^a-z0-9]+/', '-', $texto);
    return trim($texto, '-') ?: 'producto';
}

// Guardar imagen de portada
function guardarImagenProducto(array $archivo, string $nombreProducto): string {
    $permitidas = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
    $ext = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $permitidas, true)) {
        $ext = 'jpg';
    }
    $slug = slugify($nombreProducto);
    $base = realpath(__DIR__ . '/../../../Imagenes/Productos');
    $carpeta = $base . '/' . $slug;
    if (!is_dir($carpeta)) {
        mkdir($carpeta, 0777, true);
    }
    foreach (glob($carpeta . '/portada-*') ?: [] as $vieja) {
        @unlink($vieja);
    }

    $nombreArchivo = 'portada-' . time() . '.' . $ext;
    move_uploaded_file($archivo['tmp_name'], $carpeta . '/' . $nombreArchivo);

    return '../../Imagenes/Productos/' . $slug . '/' . $nombreArchivo;
}

// Calcular precio con descuento
function precioFinal(float $base, float $descuento): float {
    if ($descuento <= 0) return $base;
    return floor(($base * (1 - $descuento / 100)) / 100 + 1e-9) * 100;
}

// Saber si una columna existe (por si todavía falta ejecutar la migración)
function columnaExiste(PDO $pdo, string $tabla, string $columna): bool {
    static $cache = [];
    $clave = $tabla . '.' . $columna;
    if (!isset($cache[$clave])) {
        $stmt = $pdo->prepare(
            "SELECT COUNT(*) FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?"
        );
        $stmt->execute([$tabla, $columna]);
        $cache[$clave] = (int) $stmt->fetchColumn() > 0;
    }
    return $cache[$clave];
}

// Listar categorías con sus opciones (talla, color y visibilidad)
function categoriasConOpciones(PDO $pdo): array {
    if (!columnaExiste($pdo, 'categorias', 'requiere_talla')) {
        // Base sin migrar: todas las categorías llevan talla y color
        $filas = $pdo->query("SELECT id_categoria, nombre FROM categorias ORDER BY nombre")->fetchAll();
        foreach ($filas as &$f) {
            $f['requiere_talla'] = 1;
            $f['requiere_color'] = 1;
            $f['visible'] = 1;
        }
        return $filas;
    }
    return $pdo->query("SELECT id_categoria, nombre, requiere_talla, requiere_color, visible FROM categorias ORDER BY nombre")->fetchAll();
}

// Buscar si una categoría lleva talla y color (por defecto sí)
function opcionesCategoria(array $categorias, int $idCategoria): array {
    foreach ($categorias as $c) {
        if ((int) $c['id_categoria'] === $idCategoria) {
            return ['requiere_talla' => (bool) $c['requiere_talla'], 'requiere_color' => (bool) $c['requiere_color']];
        }
    }
    return ['requiere_talla' => true, 'requiere_color' => true];
}
