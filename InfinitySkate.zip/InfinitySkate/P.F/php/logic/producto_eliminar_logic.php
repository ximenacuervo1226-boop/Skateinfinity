<?php
require_once __DIR__ . '/../auth/require_admin.php';
require_once __DIR__ . '/../config/conexion.php';

// Validar producto a eliminar
$id = (int) ($_POST['id'] ?? 0);
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !$id) {
    header('Location: productos.php');
    exit;
}

// Eliminar producto y sus variantes
$msg = 'eliminado';
try {
    $pdo->beginTransaction();

    $pdo->prepare(
        "DELETE ic FROM items_carrito ic
         JOIN variantes_productos v ON ic.id_variante = v.id_variante
         WHERE v.id_producto = ?"
    )->execute([$id]);
    $pdo->prepare("DELETE FROM variantes_productos WHERE id_producto = ?")->execute([$id]);
    $pdo->prepare("DELETE FROM productos WHERE id_producto = ?")->execute([$id]);
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();

    // Ocultar si tiene pedidos
    $pdo->prepare("UPDATE productos SET disponible = 0 WHERE id_producto = ?")->execute([$id]);
    $msg = 'oculto';
}

header('Location: productos.php?msg=' . $msg);
exit;
