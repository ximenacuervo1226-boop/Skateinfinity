// Crear burbujas de fondo
function crearBurbujasFondo() {
    const contenedores = [
        ...document.querySelectorAll('.store-main'),
        ...document.querySelectorAll('.main-container')
    ];

    contenedores.forEach(contenedor => {
        if (contenedor.querySelector(':scope > #particle-container')) return;

        const particleContainer = document.createElement('div');
        particleContainer.id = 'particle-container';
        particleContainer.setAttribute('aria-hidden', 'true');

        const particleCount = 100;

        for (let i = 0; i < particleCount; i++) {
            const particle = document.createElement('div');
            particle.classList.add('particle');

            const size = Math.random() * 12 + 8;

            particle.style.width = `${size}px`;
            particle.style.height = `${size}px`;
            particle.style.left = `${Math.random() * 100}%`;
            particle.style.animationDuration = `${Math.random() * 10 + 10}s`;
            particle.style.animationDelay = `${Math.random() * 15}s`;

            particleContainer.appendChild(particle);
        }

        contenedor.insertBefore(particleContainer, contenedor.firstChild);
    });
}

document.addEventListener('DOMContentLoaded', crearBurbujasFondo);
