<?php
require_once __DIR__ . '/../auth/require_admin.php';
require_once __DIR__ . '/../config/conexion.php';

// Cambiar estado del pedido
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_pedido'], $_POST['nuevo_estado'])) {
    $estadosValidos = ['Revisando Pago', 'Pendiente', 'Completado', 'Cancelado'];
    if (in_array($_POST['nuevo_estado'], $estadosValidos, true)) {
        $stmt = $pdo->prepare("UPDATE pedidos SET estado = ? WHERE id_pedido = ?");
        $stmt->execute([$_POST['nuevo_estado'], (int) $_POST['id_pedido']]);
    }
    header('Location: pedidos_admin.php?msg=pedido_ok');
    exit;
}

// Listar pedidos
$stmt = $pdo->query(
    "SELECT p.id_pedido, p.fecha_pedido, p.pago_total, p.estado, u.nombre AS cliente_nombre, u.correo AS cliente_correo
     FROM pedidos p
     LEFT JOIN usuarios u ON p.id_usuario = u.id_usuario
     ORDER BY p.id_pedido DESC"
);
$pedidos = $stmt->fetchAll();
