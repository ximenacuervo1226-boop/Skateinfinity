// Filtro de categorías en descuentos
const discountsFilterBar = document.getElementById('discountsFilterBar');
    const discountsGrid = document.getElementById('discountsGrid');

    const noDiscountsMsg = document.getElementById('noDiscountsMsg');

    if (discountsFilterBar && discountsGrid) {
        const discountCards = Array.from(discountsGrid.querySelectorAll('.product-card'));
        const filterLinks = discountsFilterBar.querySelectorAll('a[data-cat]');

        // Ordenar con descuento primero
        function ordenarDescuentosPrimero(lista) {

            
            return lista.slice().sort((a, b) => {
                const aTiene = a.querySelector('.discount-badge') ? 0 : 1;
                const bTiene = b.querySelector('.discount-badge') ? 0 : 1;
                return aTiene - bTiene;
            });
        }

        // Mostrar categoría de descuentos elegida
        function mostrarCategoriaDescuentos(categoria) {
            const visibles = categoria === 'recomendados'
                ? discountCards
                : discountCards.filter(card => card.dataset.categoria === categoria);

            const ordenados = ordenarDescuentosPrimero(visibles);

            discountCards.forEach(card => { card.style.display = 'none'; });
            ordenados.forEach(card => {
                card.style.display = '';
                discountsGrid.appendChild(card);
            });

            if (noDiscountsMsg) {
                noDiscountsMsg.style.display = ordenados.length === 0 ? 'block' : 'none';
            }
            discountsGrid.style.display = ordenados.length === 0 ? 'none' : '';

            filterLinks.forEach(link => {
                link.classList.toggle('active', link.dataset.cat === categoria);
            });
        }

        // Clics en filtros de categoría
        filterLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                mostrarCategoriaDescuentos(link.dataset.cat);
            });
        });

        mostrarCategoriaDescuentos('recomendados');
    }
// Elementos del buscador
const buscador = document.querySelector(".search-input"); 

const productos = document.querySelectorAll(".product-card"); 

const mensaje = document.getElementById("sinResultado"); 

const recomendadosTitulo = document.getElementById("recommendedTitle");
const descuentosTitulo = document.getElementById("discountsTitle");
const descuentosFilterBar = document.getElementById("discountsFilterBar");

// Guardar orden original de las grillas
const ordenOriginalPorGrilla = new Map();
document.querySelectorAll(".product-grid").forEach(grilla => {
    ordenOriginalPorGrilla.set(grilla, Array.from(grilla.children));
});

// Quitar tildes y mayúsculas al texto
function normalizar(texto) {
    return texto
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .trim();
}

// Saber si un producto tiene descuento
function tieneDescuento(producto) {
    return producto.querySelector(".discount-badge") !== null;
}

const grillaResultadosBusqueda = document.getElementById("recommendedGrid");
const bannerOfertas = document.querySelector(".offers-banner-link");

// Buscar productos al escribir
buscador.addEventListener("input", function () { 

    const texto = normalizar(buscador.value);

    if (bannerOfertas) {
        bannerOfertas.style.display = texto === "" ? "" : "none";
    }

    
    
    const esBusquedaDePromociones = texto.includes("promocion") || texto.includes("promo");

    let encontrados = 0;

    
    const encontradosLista = [];

    productos.forEach(producto => {

        const nombreEl = producto.querySelector(".nombre");
        const nombre = nombreEl ? normalizar(nombreEl.textContent) : "";

        const categoria = normalizar(producto.dataset.categoria || "");

        
        
        const esExtra = producto.classList.contains("extra-product");

        let coincide;

        if (texto === "") {

            coincide = !esExtra;
        } else if (esBusquedaDePromociones) {
            
            coincide = tieneDescuento(producto);
        } else {
            
            coincide = nombre.includes(texto) || categoria.includes(texto);
        }

        producto.style.display = coincide ? "" : "none";

        if (coincide) {
            encontrados++;

            if (texto !== "") {
                encontradosLista.push(producto);
            }
        }
    });

    // Ordenar resultados (descuento primero)
    if (texto === "") {
        
        ordenOriginalPorGrilla.forEach((hijosOriginales, grilla) => {
            hijosOriginales.forEach(hijo => grilla.appendChild(hijo));
        });
    } else {

        
        
        const conDescuento = encontradosLista.filter(tieneDescuento);
        const sinDescuento = encontradosLista.filter(p => !tieneDescuento(p));
        const ordenFinal = conDescuento.concat(sinDescuento);

        const contenedorDestino = grillaResultadosBusqueda || (ordenFinal[0] && ordenFinal[0].parentElement);
        if (contenedorDestino) {
            ordenFinal.forEach(producto => contenedorDestino.appendChild(producto));
        }
    }

    
    // Ocultar títulos y mensaje sin resultados
    const estaBuscando = texto !== "";
    if (recomendadosTitulo) recomendadosTitulo.style.display = estaBuscando ? "none" : "";
    if (descuentosTitulo) descuentosTitulo.style.display = estaBuscando ? "none" : "";
    if (descuentosFilterBar) descuentosFilterBar.style.display = estaBuscando ? "none" : "";

    if (mensaje) {
        if (encontrados === 0) {

            mensaje.style.display = "block";

        } else {

            mensaje.style.display = "none";
        }
    }

});
