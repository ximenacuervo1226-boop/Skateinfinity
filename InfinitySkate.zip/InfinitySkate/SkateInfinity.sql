-- =========================================================
--  SkateInfinity - Base de datos MySQL - VERSION 4
--  Version consolidada: reemplaza Skate.sql y
--  Skate_actualizar_productos.sql (ya unidos en un solo archivo).
--  Importar UNA sola vez en phpMyAdmin (pestana SQL o Importar).
-- =========================================================
CREATE DATABASE IF NOT EXISTS skateinfinity CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE skateinfinity;

-- En vez de borrar toda la base (que en Windows/XAMPP a veces falla con el
-- error #1010 "Directory not empty"), simplemente borramos las tablas una por
-- una si ya existían, respetando las llaves foráneas.
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS pagos;
DROP TABLE IF EXISTS detalle_pedidos;
DROP TABLE IF EXISTS pedidos;
DROP TABLE IF EXISTS items_carrito;
DROP TABLE IF EXISTS carrito;
DROP TABLE IF EXISTS direcciones;
DROP TABLE IF EXISTS variantes_productos;
DROP TABLE IF EXISTS productos;
DROP TABLE IF EXISTS categorias;
DROP TABLE IF EXISTS usuarios;
SET FOREIGN_KEY_CHECKS = 1;


-- ---------------------------------------------------------
-- USUARIOS
-- ---------------------------------------------------------
CREATE TABLE usuarios (
  id_usuario INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  usuario VARCHAR(30) NOT NULL UNIQUE,
  correo VARCHAR(150) NOT NULL UNIQUE,
  telefono VARCHAR(20) NOT NULL,
  fecha_nacimiento DATE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  rol ENUM('cliente','admin','propietario') NOT NULL DEFAULT 'cliente',
  bio VARCHAR(500) NOT NULL DEFAULT '',
  foto_perfil MEDIUMTEXT NULL,
  estado ENUM('activo','bloqueado') NOT NULL DEFAULT 'activo',
  fecha_registro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ultimo_login DATETIME NULL DEFAULT NULL
) ENGINE=InnoDB;


-- ---------------------------------------------------------
-- CATEGORIAS
-- ---------------------------------------------------------
CREATE TABLE categorias (
  id_categoria INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(50) NOT NULL UNIQUE,
  descripcion VARCHAR(255) NOT NULL,
  requiere_talla TINYINT(1) NOT NULL DEFAULT 1,
  requiere_color TINYINT(1) NOT NULL DEFAULT 1,
  visible TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

INSERT INTO categorias (id_categoria,nombre,descripcion) VALUES (1,'camisas','Camisetas y camisas de estilo urbano.');
INSERT INTO categorias (id_categoria,nombre,descripcion) VALUES (2,'buzos','Buzos y prendas superiores de estilo urbano.');
INSERT INTO categorias (id_categoria,nombre,descripcion) VALUES (3,'pantalones','Pantalones de corte urbano y streetwear.');
INSERT INTO categorias (id_categoria,nombre,descripcion) VALUES (4,'chaquetas','Chaquetas para complementar el estilo urbano.');
INSERT INTO categorias (id_categoria,nombre,descripcion) VALUES (5,'zapatos','Calzado de estilo skate y urbano.');
INSERT INTO categorias (id_categoria,nombre,descripcion) VALUES (6,'gorras','Gorras y gorros para complementar tu outfit.');


-- ---------------------------------------------------------
-- PRODUCTOS
-- ---------------------------------------------------------
CREATE TABLE productos (
  id_producto INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_categoria INT UNSIGNED NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  descripcion VARCHAR(255) NOT NULL,
  precio_base DECIMAL(10,2) NOT NULL,
  descuento_porcentaje DECIMAL(5,2) NOT NULL DEFAULT 0,
  imagen_url VARCHAR(1000) NOT NULL,
  disponible TINYINT(1) NOT NULL DEFAULT 1,
  fecha_creacion DATE NOT NULL,
  CONSTRAINT fk_productos_categoria FOREIGN KEY (id_categoria) REFERENCES categorias(id_categoria)
) ENGINE=InnoDB;

INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (1,1,'Camiseta Gráfica','Camiseta oversize de algodón con estampado gótico envejecido en el frente y efecto lavado vintage. Cuello redondo y manga corta.',79900,0,'../../Imagenes/Productos/camiseta-vintage-redencion/crema-1-frontal.jpeg',1,'2026-09-04');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (2,3,'Pantalón Tribal','Pantalón wide leg en denim negro lavado con bordados tribales en contraste a los costados, detalles desgastados y corte holgado. Estilo skater de los 2000.',119900,0,'../../Imagenes/Productos/pantalon-tribal/negro-1-frontal.jpeg',1,'2026-09-04');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (3,4,'Chaqueta Llamas','Chaqueta bomber negra con llamas azules aplicadas en la parte inferior, cuello camisero, cierre frontal y puños elásticos. Corte oversize ideal para skate y calle.',179900,0,'../../Imagenes/Productos/chaqueta-llamas/negro-1-frontal.jpeg',1,'2026-09-04');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (4,6,'Gorra Urbana','Gorra de algodón desgastado en negro con salpicaduras y trazos rojos de estilo grunge. Visera curva y cierre trasero ajustable.',59900,0,'../../Imagenes/Productos/gorra-urbana/negro-1-frontal.jpeg',1,'2026-09-04');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (5,2,'Buzo Longsleeve','Camiseta oversize de efecto doble capa con mangas largas de telaraña y cruces, estampado de dragón en el frente y tela lavada estilo vintage.',129900,50,'../../Imagenes/Productos/camiseta-doble-manga-dragon/negro-1-frontal.jpeg',1,'2026-09-04');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (6,1,'Camiseta Jersey 89','Crop jersey de malla con cuello en V, número 89 al frente y estrellas en las mangas. Corte corto y holgado de estilo deportivo urbano.',79900,65,'../../Imagenes/Productos/camiseta-jersey-89/morado-1-frontal.jpeg',1,'2026-09-04');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (7,5,'Zapatillas Skate','Zapatillas skate de perfil bajo en ante negro con gráfico rojo estilo metal, suela vulcanizada, plantilla acolchada y lengüeta reforzada.',219900,75,'../../Imagenes/Productos/zapatillas-skate/negro-1-tres-cuartos.jpeg',1,'2026-09-04');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (8,6,'Gorro Beanie Cruz','Gorro beanie de punto elástico con cruz gótica en pedrería brillante. Se ajusta a la cabeza y combina con cualquier outfit oscuro.',59900,55,'../../Imagenes/Productos/gorro-beanie-cruz/azul-marino-1-frontal.jpeg',1,'2026-09-04');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (9,1,'Top Manga Gótico','Top de manga corta con hombros descubiertos y estampado de ilustración manga en el frente. Lleva cordón halter decorativo con dije de cruz. Tela suave y ajuste entallado.',69900,0,'../../Imagenes/Productos/top-manga-gotico/blanco-1-frontal.jpeg',1,'2026-09-18');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (10,1,'Top Halter Caos','Top halter con estampado gráfico "Embrace the Chaos", detalle de encaje en el escote y tiras para amarrar al cuello. Tela elástica de ajuste ceñido.',64900,0,'../../Imagenes/Productos/top-halter-caos/vinotinto-1-frontal.jpeg',1,'2026-09-18');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (11,1,'Camiseta Vintage Redención','Camiseta oversize de algodón con estampado gótico envejecido en el frente y efecto lavado vintage. Cuello redondo y manga corta.',74900,0,'../../Imagenes/Productos/camiseta-vintage-redencion/crema-1-frontal.jpeg',1,'2026-09-18');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (12,1,'Camiseta Doble Manga Dragón','Camiseta oversize de efecto doble capa con mangas largas de telaraña y cruces, estampado de dragón en el frente y tela lavada estilo vintage.',99900,0,'../../Imagenes/Productos/camiseta-doble-manga-dragon/negro-1-frontal.jpeg',1,'2026-09-18');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (13,2,'Buzo Zip Espinas','Buzo con capucha y cierre completo, con bordado de alambre de púas y letras góticas en el frente, mangas y espalda. Felpa gruesa de acabado lavado en gris grafito.',159900,0,'../../Imagenes/Productos/buzo-zip-espinas/gris-1-frontal.jpeg',1,'2026-09-18');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (14,2,'Buzo Araña Oversize','Buzo cuello redondo oversize con gran araña estampada en el frente y detalles de púas en las mangas. Disponible en blanco, negro y negro tonal.',139900,0,'../../Imagenes/Productos/buzo-arana-oversize/blanco-1-frontal.jpeg',1,'2026-09-18');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (15,2,'Polo Rugby Rayas','Polo tipo rugby de manga larga con rayas horizontales en negro y gris, cuello y puños en color crema y parche bordado en el pecho.',119900,0,'../../Imagenes/Productos/polo-rugby-rayas/negro-1-frontal.jpeg',1,'2026-09-18');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (16,4,'Chaqueta Puffer Silver','Chaqueta acolchada de cuello alto con bloques en negro, gris y blanco, escudo bordado en la espalda y parches en las mangas. Interior abrigado y cierre frontal.',249900,0,'../../Imagenes/Productos/chaqueta-puffer-silver/negro-1-frontal.jpeg',1,'2026-09-18');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (17,4,'Chaqueta Track Retro','Chaqueta deportiva de cuello alto con cierre completo, paneles en contraste y tres rayas en las mangas. Estilo retro de los 90 en tres colores.',149900,0,'../../Imagenes/Productos/chaqueta-track-retro/rojo-1-frontal.jpeg',1,'2026-09-18');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (18,3,'Pantalón Corduroy Café','Pantalón wide leg de pana en tono café con degradado desgastado hacia los tobillos. Tiro alto y pierna ancha.',129900,0,'../../Imagenes/Productos/pantalon-corduroy-cafe/cafe-1-frontal.jpeg',1,'2026-09-18');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (19,3,'Jean Wide Leg Azul','Jean de pierna ancha en denim azul medio con lavado clásico, tiro alto y bolsillos traseros. Corte holgado.',124900,0,'../../Imagenes/Productos/jean-wide-leg-azul/azul-1-frontal.jpeg',1,'2026-09-18');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (20,3,'Jean Cruz Gótica','Jean de tiro bajo y bota ancha con bordado de cruces en los bolsillos traseros y lavado desgastado. Disponible en azul oscuro y negro.',139900,0,'../../Imagenes/Productos/jean-cruz-gotica/azul-oscuro-1-frontal.jpeg',1,'2026-09-18');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (21,3,'Jort Telaraña','Jort largo hasta la rodilla en denim negro lavado con salpicaduras de pintura, estampado de telaraña y cadena decorativa en la cintura. Corte holgado.',99900,0,'../../Imagenes/Productos/jort-telarana/negro-1-frontal.jpeg',1,'2026-09-18');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (22,5,'Botas Plataforma Cadenas','Botas de plataforma en cuero sintético negro con cordones, hebillas y cadenas decorativas. Suela gruesa con buen agarre y cierre lateral.',189900,0,'../../Imagenes/Productos/botas-plataforma-cadenas/negro-1-tres-cuartos.jpeg',1,'2026-09-18');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (23,5,'Zapatillas Retro Alta','Zapatillas de caña media con panel de malla, detalles en contraste y cámara de aire en la suela. Estilo retro de baloncesto en crema y negro.',329900,0,'../../Imagenes/Productos/zapatillas-retro-alta/crema-1-tres-cuartos.jpeg',1,'2026-09-18');
INSERT INTO productos (id_producto,id_categoria,nombre,descripcion,precio_base,descuento_porcentaje,imagen_url,disponible,fecha_creacion) VALUES (24,6,'Gorra Fitted Cruces','Gorra fitted de visera plana con logo LA bordado entre cruces y hilos desflecados. Copa estructurada disponible en azul, rojo y negro.',89900,0,'../../Imagenes/Productos/gorra-fitted-cruces/azul-1-frontal.jpeg',1,'2026-09-18');


-- ---------------------------------------------------------
-- VARIANTES DE PRODUCTOS (talla, color, stock, sku)
-- ---------------------------------------------------------
CREATE TABLE variantes_productos (
  id_variante INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_producto INT UNSIGNED NOT NULL,
  talla VARCHAR(10) NOT NULL,
  color VARCHAR(30) NOT NULL,
  stock INT UNSIGNED NOT NULL DEFAULT 0,
  sku VARCHAR(50) NOT NULL UNIQUE,
  UNIQUE KEY uq_variante (id_producto,talla,color),
  CONSTRAINT fk_variantes_producto FOREIGN KEY (id_producto) REFERENCES productos(id_producto)
) ENGINE=InnoDB;

INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (1,1,'S','Crema',10,'SK8-01-0001');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (2,1,'M','Crema',10,'SK8-01-0002');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (3,1,'L','Crema',10,'SK8-01-0003');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (4,1,'XL','Crema',10,'SK8-01-0004');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (25,2,'28','Negro',10,'SK8-02-0025');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (26,2,'30','Negro',10,'SK8-02-0026');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (27,2,'32','Negro',10,'SK8-02-0027');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (28,2,'34','Negro',10,'SK8-02-0028');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (29,2,'36','Negro',10,'SK8-02-0029');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (30,3,'S','Negro',10,'SK8-03-0030');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (31,3,'M','Negro',10,'SK8-03-0031');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (32,3,'L','Negro',10,'SK8-03-0032');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (33,3,'XL','Negro',10,'SK8-03-0033');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (34,4,'Única','Negro',10,'SK8-04-0034');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (35,5,'S','Negro',10,'SK8-05-0035');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (36,5,'S','Blanco',10,'SK8-05-0036');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (37,5,'S','Gris',10,'SK8-05-0037');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (38,5,'S','Rojo',10,'SK8-05-0038');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (39,5,'S','Azul',10,'SK8-05-0039');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (40,5,'S','Verde',10,'SK8-05-0040');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (41,5,'M','Negro',10,'SK8-05-0041');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (42,5,'M','Blanco',10,'SK8-05-0042');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (43,5,'M','Gris',10,'SK8-05-0043');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (44,5,'M','Rojo',10,'SK8-05-0044');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (45,5,'M','Azul',10,'SK8-05-0045');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (46,5,'M','Verde',10,'SK8-05-0046');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (47,5,'L','Negro',10,'SK8-05-0047');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (48,5,'L','Blanco',10,'SK8-05-0048');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (49,5,'L','Gris',10,'SK8-05-0049');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (50,5,'L','Rojo',10,'SK8-05-0050');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (51,5,'L','Azul',10,'SK8-05-0051');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (52,5,'L','Verde',10,'SK8-05-0052');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (53,5,'XL','Negro',10,'SK8-05-0053');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (54,5,'XL','Blanco',10,'SK8-05-0054');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (55,5,'XL','Gris',10,'SK8-05-0055');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (56,5,'XL','Rojo',10,'SK8-05-0056');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (57,5,'XL','Azul',10,'SK8-05-0057');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (58,5,'XL','Verde',10,'SK8-05-0058');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (59,6,'S','Morado',10,'SK8-06-0059');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (60,6,'S','Coral',10,'SK8-06-0060');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (61,6,'S','Rosa',10,'SK8-06-0061');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (62,6,'S','Gris',10,'SK8-06-0062');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (63,6,'S','Blanco',10,'SK8-06-0063');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (64,6,'M','Morado',10,'SK8-06-0064');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (65,6,'M','Coral',10,'SK8-06-0065');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (66,6,'M','Rosa',10,'SK8-06-0066');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (67,6,'M','Gris',10,'SK8-06-0067');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (68,6,'M','Blanco',10,'SK8-06-0068');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (69,6,'L','Morado',10,'SK8-06-0069');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (70,6,'L','Coral',10,'SK8-06-0070');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (71,6,'L','Rosa',10,'SK8-06-0071');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (72,6,'L','Gris',10,'SK8-06-0072');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (73,6,'L','Blanco',10,'SK8-06-0073');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (74,6,'XL','Morado',10,'SK8-06-0074');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (75,6,'XL','Coral',10,'SK8-06-0075');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (76,6,'XL','Rosa',10,'SK8-06-0076');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (77,6,'XL','Gris',10,'SK8-06-0077');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (78,6,'XL','Blanco',10,'SK8-06-0078');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (79,7,'38','Negro',10,'SK8-07-0079');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (80,7,'39','Negro',10,'SK8-07-0080');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (81,7,'40','Negro',10,'SK8-07-0081');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (82,7,'41','Negro',10,'SK8-07-0082');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (83,7,'42','Negro',10,'SK8-07-0083');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (84,7,'43','Negro',10,'SK8-07-0084');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (85,8,'Única','Azul Marino',10,'SK8-08-0085');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (86,8,'Única','Gris',10,'SK8-08-0086');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (87,8,'Única','Morado',10,'SK8-08-0087');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (88,8,'Única','Vinotinto',10,'SK8-08-0088');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (89,8,'Única','Negro',10,'SK8-08-0089');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (90,9,'S','Blanco',10,'SK8-09-0090');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (91,9,'S','Vinotinto',10,'SK8-09-0091');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (92,9,'S','Negro',10,'SK8-09-0092');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (93,9,'S','Gris',10,'SK8-09-0093');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (94,9,'M','Blanco',10,'SK8-09-0094');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (95,9,'M','Vinotinto',10,'SK8-09-0095');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (96,9,'M','Negro',10,'SK8-09-0096');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (97,9,'M','Gris',10,'SK8-09-0097');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (98,9,'L','Blanco',10,'SK8-09-0098');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (99,9,'L','Vinotinto',10,'SK8-09-0099');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (100,9,'L','Negro',10,'SK8-09-0100');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (101,9,'L','Gris',10,'SK8-09-0101');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (102,9,'XL','Blanco',10,'SK8-09-0102');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (103,9,'XL','Vinotinto',10,'SK8-09-0103');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (104,9,'XL','Negro',10,'SK8-09-0104');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (105,9,'XL','Gris',10,'SK8-09-0105');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (106,10,'S','Vinotinto',10,'SK8-10-0106');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (107,10,'S','Gris',10,'SK8-10-0107');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (108,10,'S','Azul Marino',10,'SK8-10-0108');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (109,10,'S','Negro',10,'SK8-10-0109');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (110,10,'S','Morado',10,'SK8-10-0110');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (111,10,'M','Vinotinto',10,'SK8-10-0111');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (112,10,'M','Gris',10,'SK8-10-0112');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (113,10,'M','Azul Marino',10,'SK8-10-0113');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (114,10,'M','Negro',10,'SK8-10-0114');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (115,10,'M','Morado',10,'SK8-10-0115');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (116,10,'L','Vinotinto',10,'SK8-10-0116');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (117,10,'L','Gris',10,'SK8-10-0117');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (118,10,'L','Azul Marino',10,'SK8-10-0118');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (119,10,'L','Negro',10,'SK8-10-0119');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (120,10,'L','Morado',10,'SK8-10-0120');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (121,10,'XL','Vinotinto',10,'SK8-10-0121');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (122,10,'XL','Gris',10,'SK8-10-0122');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (123,10,'XL','Azul Marino',10,'SK8-10-0123');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (124,10,'XL','Negro',10,'SK8-10-0124');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (125,10,'XL','Morado',10,'SK8-10-0125');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (126,11,'S','Crema',10,'SK8-11-0126');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (127,11,'M','Crema',10,'SK8-11-0127');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (128,11,'L','Crema',10,'SK8-11-0128');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (129,11,'XL','Crema',10,'SK8-11-0129');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (130,12,'S','Negro',10,'SK8-12-0130');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (131,12,'M','Negro',10,'SK8-12-0131');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (132,12,'L','Negro',10,'SK8-12-0132');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (133,12,'XL','Negro',10,'SK8-12-0133');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (134,13,'S','Gris',10,'SK8-13-0134');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (135,13,'M','Gris',10,'SK8-13-0135');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (136,13,'L','Gris',10,'SK8-13-0136');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (137,13,'XL','Gris',10,'SK8-13-0137');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (138,14,'S','Blanco',10,'SK8-14-0138');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (139,14,'S','Negro',10,'SK8-14-0139');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (140,14,'S','Negro Tonal',10,'SK8-14-0140');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (141,14,'M','Blanco',10,'SK8-14-0141');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (142,14,'M','Negro',10,'SK8-14-0142');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (143,14,'M','Negro Tonal',10,'SK8-14-0143');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (144,14,'L','Blanco',10,'SK8-14-0144');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (145,14,'L','Negro',10,'SK8-14-0145');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (146,14,'L','Negro Tonal',10,'SK8-14-0146');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (147,14,'XL','Blanco',10,'SK8-14-0147');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (148,14,'XL','Negro',10,'SK8-14-0148');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (149,14,'XL','Negro Tonal',10,'SK8-14-0149');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (150,15,'S','Negro',10,'SK8-15-0150');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (151,15,'M','Negro',10,'SK8-15-0151');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (152,15,'L','Negro',10,'SK8-15-0152');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (153,15,'XL','Negro',10,'SK8-15-0153');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (154,16,'S','Negro',10,'SK8-16-0154');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (155,16,'M','Negro',10,'SK8-16-0155');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (156,16,'L','Negro',10,'SK8-16-0156');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (157,16,'XL','Negro',10,'SK8-16-0157');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (158,17,'S','Rojo',10,'SK8-17-0158');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (159,17,'S','Morado',10,'SK8-17-0159');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (160,17,'S','Azul',10,'SK8-17-0160');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (161,17,'M','Rojo',10,'SK8-17-0161');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (162,17,'M','Morado',10,'SK8-17-0162');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (163,17,'M','Azul',10,'SK8-17-0163');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (164,17,'L','Rojo',10,'SK8-17-0164');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (165,17,'L','Morado',10,'SK8-17-0165');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (166,17,'L','Azul',10,'SK8-17-0166');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (167,17,'XL','Rojo',10,'SK8-17-0167');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (168,17,'XL','Morado',10,'SK8-17-0168');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (169,17,'XL','Azul',10,'SK8-17-0169');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (170,18,'28','Café',10,'SK8-18-0170');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (171,18,'30','Café',10,'SK8-18-0171');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (172,18,'32','Café',10,'SK8-18-0172');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (173,18,'34','Café',10,'SK8-18-0173');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (174,18,'36','Café',10,'SK8-18-0174');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (175,19,'28','Azul',10,'SK8-19-0175');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (176,19,'30','Azul',10,'SK8-19-0176');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (177,19,'32','Azul',10,'SK8-19-0177');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (178,19,'34','Azul',10,'SK8-19-0178');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (179,19,'36','Azul',10,'SK8-19-0179');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (180,20,'28','Azul Oscuro',10,'SK8-20-0180');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (181,20,'28','Negro',10,'SK8-20-0181');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (182,20,'30','Azul Oscuro',10,'SK8-20-0182');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (183,20,'30','Negro',10,'SK8-20-0183');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (184,20,'32','Azul Oscuro',10,'SK8-20-0184');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (185,20,'32','Negro',10,'SK8-20-0185');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (186,20,'34','Azul Oscuro',10,'SK8-20-0186');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (187,20,'34','Negro',10,'SK8-20-0187');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (188,20,'36','Azul Oscuro',10,'SK8-20-0188');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (189,20,'36','Negro',10,'SK8-20-0189');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (190,21,'28','Negro',10,'SK8-21-0190');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (191,21,'30','Negro',10,'SK8-21-0191');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (192,21,'32','Negro',10,'SK8-21-0192');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (193,21,'34','Negro',10,'SK8-21-0193');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (194,21,'36','Negro',10,'SK8-21-0194');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (195,22,'38','Negro',10,'SK8-22-0195');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (196,22,'39','Negro',10,'SK8-22-0196');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (197,22,'40','Negro',10,'SK8-22-0197');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (198,22,'41','Negro',10,'SK8-22-0198');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (199,22,'42','Negro',10,'SK8-22-0199');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (200,22,'43','Negro',10,'SK8-22-0200');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (201,23,'38','Crema',10,'SK8-23-0201');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (202,23,'38','Negro',10,'SK8-23-0202');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (203,23,'39','Crema',10,'SK8-23-0203');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (204,23,'39','Negro',10,'SK8-23-0204');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (205,23,'40','Crema',10,'SK8-23-0205');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (206,23,'40','Negro',10,'SK8-23-0206');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (207,23,'41','Crema',10,'SK8-23-0207');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (208,23,'41','Negro',10,'SK8-23-0208');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (209,23,'42','Crema',10,'SK8-23-0209');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (210,23,'42','Negro',10,'SK8-23-0210');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (211,23,'43','Crema',10,'SK8-23-0211');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (212,23,'43','Negro',10,'SK8-23-0212');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (213,24,'Única','Azul',10,'SK8-24-0213');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (214,24,'Única','Rojo',10,'SK8-24-0214');
INSERT INTO variantes_productos (id_variante,id_producto,talla,color,stock,sku) VALUES (215,24,'Única','Negro',10,'SK8-24-0215');


-- ---------------------------------------------------------
-- DIRECCIONES DE ENVÍO (una dirección guardada por usuario)
-- ---------------------------------------------------------
CREATE TABLE direcciones (
  id_direccion INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_usuario INT UNSIGNED NOT NULL UNIQUE,
  direccion VARCHAR(255) NOT NULL,
  ciudad VARCHAR(100) NOT NULL,
  referencia VARCHAR(500) NOT NULL DEFAULT '',
  fecha_actualizacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_direccion_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- CARRITO
-- ---------------------------------------------------------
CREATE TABLE carrito (
  id_carrito INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_usuario INT UNSIGNED NOT NULL UNIQUE,
  fecha_actualizacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_carrito_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB;


-- ---------------------------------------------------------
-- ITEMS DEL CARRITO
-- ---------------------------------------------------------
CREATE TABLE items_carrito (
  id_item_carrito INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_carrito INT UNSIGNED NOT NULL,
  id_variante INT UNSIGNED NOT NULL,
  cantidad INT UNSIGNED NOT NULL,
  UNIQUE KEY uq_item (id_carrito,id_variante),
  CONSTRAINT fk_item_carrito FOREIGN KEY (id_carrito) REFERENCES carrito(id_carrito) ON DELETE CASCADE,
  CONSTRAINT fk_item_variante FOREIGN KEY (id_variante) REFERENCES variantes_productos(id_variante)
) ENGINE=InnoDB;


-- ---------------------------------------------------------
-- PEDIDOS
-- ---------------------------------------------------------
CREATE TABLE pedidos (
  id_pedido INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_usuario INT UNSIGNED NOT NULL,
  fecha_pedido DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  pago_total DECIMAL(10,2) NOT NULL,
  descuento DECIMAL(10,2) NOT NULL DEFAULT 0,
  estado VARCHAR(30) NOT NULL DEFAULT 'Revisando Pago',
  direccion_envio VARCHAR(255) NOT NULL,
  CONSTRAINT fk_pedido_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
) ENGINE=InnoDB;


-- ---------------------------------------------------------
-- DETALLE DE PEDIDOS
-- ---------------------------------------------------------
CREATE TABLE detalle_pedidos (
  id_detalle INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_pedido INT UNSIGNED NOT NULL,
  id_variante INT UNSIGNED NOT NULL,
  cantidad INT UNSIGNED NOT NULL,
  precio_unitario DECIMAL(10,2) NOT NULL,
  CONSTRAINT fk_detalle_pedido FOREIGN KEY (id_pedido) REFERENCES pedidos(id_pedido) ON DELETE CASCADE,
  CONSTRAINT fk_detalle_variante FOREIGN KEY (id_variante) REFERENCES variantes_productos(id_variante)
) ENGINE=InnoDB;


-- ---------------------------------------------------------
-- PAGOS
-- ---------------------------------------------------------
CREATE TABLE pagos (
  id_pago INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_pedido INT UNSIGNED NOT NULL,
  monto DECIMAL(10,2) NOT NULL,
  metodo_pago ENUM('Nequi','Bancolombia','QR') NOT NULL DEFAULT 'Bancolombia',
  estado VARCHAR(30) NOT NULL DEFAULT 'Pendiente',
  fecha_pago DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pago_pedido FOREIGN KEY (id_pedido) REFERENCES pedidos(id_pedido) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Fin de Skate_v4.sql
