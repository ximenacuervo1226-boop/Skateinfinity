<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/conexion.php';
require_once __DIR__ . '/../api/common.php';
require_once __DIR__ . '/../config/correo.php';

// Solo permitir POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') respuesta(['ok'=>false,'mensaje'=>'Método no permitido.'],405);

// Leer acción y correo
$d = datosEntrada();
$accion = (string)($d['accion'] ?? '');
$correo = strtolower(trim((string)($d['correo'] ?? '')));

if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) respuesta(['ok'=>false,'mensaje'=>'El correo no es válido.'],422);

// Crear tabla de códigos si no existe
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS recuperar_password (
        id_recuperacion INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        id_usuario INT UNSIGNED NOT NULL,
        codigo_hash VARCHAR(255) NOT NULL,
        fecha_expira DATETIME NOT NULL,
        intentos TINYINT UNSIGNED NOT NULL DEFAULT 0,
        fecha_creacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_recuperar_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
    ) ENGINE=InnoDB");

    // Buscar usuario por correo
    $stmt = $pdo->prepare('SELECT id_usuario, nombre, usuario, rol FROM usuarios WHERE correo = ? LIMIT 1');
    $stmt->execute([$correo]);
    $u = $stmt->fetch();

    // Paso 1: generar y enviar código
    if ($accion === 'solicitar') {
        if (!smtpConfigurado()) {
            respuesta(['ok'=>false,'mensaje'=>'El envío de correos aún no está configurado (php/config/correo.php).'],500);
        }

        if ($u) {
            $reciente = $pdo->prepare('SELECT 1 FROM recuperar_password WHERE id_usuario = ? AND fecha_creacion > DATE_SUB(NOW(), INTERVAL 60 SECOND) LIMIT 1');
            $reciente->execute([$u['id_usuario']]);

            if (!$reciente->fetchColumn()) {
                $codigo = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);

                $pdo->prepare('DELETE FROM recuperar_password WHERE id_usuario = ?')->execute([$u['id_usuario']]);
                $pdo->prepare('INSERT INTO recuperar_password (id_usuario, codigo_hash, fecha_expira) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 15 MINUTE))')
                    ->execute([$u['id_usuario'], password_hash($codigo, PASSWORD_DEFAULT)]);

                $texto = "Hola {$u['nombre']},\r\n\r\n"
                    . "Recibimos una solicitud para restablecer la contraseña de tu cuenta en Skate∞.\r\n\r\n"
                    . "Datos de tu cuenta:\r\n"
                    . "Usuario: {$u['usuario']}\r\n"
                    . "Correo: {$correo}\r\n\r\n"
                    . "Tu código de verificación es: {$codigo}\r\n"
                    . "Vence en 15 minutos.\r\n\r\n"
                    . "Si no fuiste tú, ignora este mensaje: tu contraseña no cambiará.";

                try {
                    enviarCorreo($correo, 'Código para recuperar tu contraseña - Skate∞', $texto);
                } catch (Throwable $e) {
                    $pdo->prepare('DELETE FROM recuperar_password WHERE id_usuario = ?')->execute([$u['id_usuario']]);
                    error_log('Recuperar contraseña: ' . $e->getMessage());
                    respuesta(['ok'=>false,'mensaje'=>'No se pudo enviar el correo. Revisa la configuración en php/config/correo.php.'],500);
                }
            }
        }

        respuesta(['ok'=>true,'mensaje'=>'Si el correo está registrado, te enviamos un código.']);
    }

    // Pasos 2 y 3: validar código
    if ($accion === 'verificar' || $accion === 'restablecer') {
        $codigo = preg_replace('/\D+/', '', (string)($d['codigo'] ?? ''));
        if (strlen($codigo) !== 6) respuesta(['ok'=>false,'mensaje'=>'El código debe tener 6 números.'],422);

        // Validar nueva contraseña
        if ($accion === 'restablecer') {
            $password = (string)($d['password'] ?? '');
            if (!preg_match('/(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W_]).{8,}/', $password)) {
                respuesta(['ok'=>false,'mensaje'=>'La nueva contraseña no cumple los requisitos de seguridad.'],422);
            }
        }

        // Buscar código vigente
        $rec = false;
        if ($u) {
            $q = $pdo->prepare('SELECT id_recuperacion, codigo_hash, intentos FROM recuperar_password WHERE id_usuario = ? AND fecha_expira > NOW() ORDER BY id_recuperacion DESC LIMIT 1');
            $q->execute([$u['id_usuario']]);
            $rec = $q->fetch();
        }
        if (!$rec) respuesta(['ok'=>false,'mensaje'=>'El código no es válido o ya venció. Solicita uno nuevo.'],400);

        // Limitar intentos
        if ((int)$rec['intentos'] >= 5) {
            $pdo->prepare('DELETE FROM recuperar_password WHERE id_usuario = ?')->execute([$u['id_usuario']]);
            respuesta(['ok'=>false,'mensaje'=>'Demasiados intentos. Solicita un código nuevo.'],429);
        }

        // Comparar código
        if (!password_verify($codigo, $rec['codigo_hash'])) {
            $pdo->prepare('UPDATE recuperar_password SET intentos = intentos + 1 WHERE id_recuperacion = ?')->execute([$rec['id_recuperacion']]);
            respuesta(['ok'=>false,'mensaje'=>'El código es erróneo.'],401);
        }

        if ($accion === 'verificar') {
            respuesta(['ok'=>true,'mensaje'=>'Código correcto.']);
        }

        // Paso 3: guardar contraseña e iniciar sesión
        $pdo->beginTransaction();
        $pdo->prepare('UPDATE usuarios SET password_hash = ? WHERE id_usuario = ?')->execute([password_hash($password, PASSWORD_DEFAULT), $u['id_usuario']]);
        $pdo->prepare('DELETE FROM recuperar_password WHERE id_usuario = ?')->execute([$u['id_usuario']]);
        $pdo->commit();

        session_regenerate_id(true);
        $_SESSION['id_usuario'] = (int)$u['id_usuario'];
        $_SESSION['usuario'] = $u['usuario'];
        $_SESSION['nombre'] = $u['nombre'];
        $_SESSION['rol'] = $u['rol'];

        try {
            $pdo->prepare('UPDATE usuarios SET ultimo_login = NOW() WHERE id_usuario = ?')->execute([(int)$u['id_usuario']]);
        } catch (Throwable $e) {}

        $cart = $pdo->prepare('SELECT id_carrito FROM carrito WHERE id_usuario = ? LIMIT 1');
        $cart->execute([(int)$u['id_usuario']]);
        if (!$cart->fetch()) {
            $pdo->prepare('INSERT INTO carrito (id_usuario, fecha_actualizacion) VALUES (?, NOW())')->execute([(int)$u['id_usuario']]);
        }

        respuesta(['ok'=>true,'mensaje'=>'Contraseña actualizada. Sesión iniciada.','usuario'=>$u['usuario']]);
    }

    // Acción no válida y errores
    respuesta(['ok'=>false,'mensaje'=>'Acción no válida.'],400);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('Recuperar contraseña: ' . $e->getMessage());
    respuesta(['ok'=>false,'mensaje'=>'Error en el servidor. Intenta de nuevo.'],500);
}
