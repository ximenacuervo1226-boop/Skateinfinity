if (document.getElementById('cartItemsContainer')) {
    // Constantes y estado del carrito
    const SHIPPING_COST = 10000;
    const VALID_PROMO_CODE = 'SkateInfinity2026';
    const PROMO_DISCOUNT_RATE = 0.25;
    let appliedPromoCode = null;
    let cart = [];

    // Dar formato al dinero
    function formatMoney(value) {
        return Number(value).toLocaleString('es-CO') + '$';
    }

    // Mostrar mensaje del código promo
    function setCartMessage(text, type='') {
        const msg = document.getElementById('promoCodeMsg');
        if (msg) {
            msg.textContent = text;
            msg.className = 'promo-code-msg' + (type ? ' ' + type : '');
        }
    }

    // Cargar carrito desde el servidor
    async function cargarCarrito() {
        try {
            const response = await fetch('../php/api/cart.php', {credentials: 'same-origin'});
            const data = await response.json();

            if (response.status === 401) {
                alert('Debes iniciar sesión para usar el carrito.');
                window.location.href = 'landing.html';
                return;
            }

            if (!response.ok || !data.ok) {
                setCartMessage(data.mensaje || 'No se pudo cargar el carrito.', 'error');
                return;
            }

            cart = data.carrito || [];
            renderCart();
        } catch (error) {
            setCartMessage('No se pudo conectar con PHP/MySQL.', 'error');
        }
    }

    window.recargarCarritoSkate = cargarCarrito;

    // Dibujar productos y totales del carrito
    function renderCart() {
        const container = document.getElementById('cartItemsContainer');
        const emptyMsg = document.getElementById('emptyCartMsg');
        const discountRow = document.getElementById('summaryDiscountRow');

        container.innerHTML = '';

        if (cart.length === 0) {
            emptyMsg.style.display = 'block';
            document.getElementById('summarySubtotal').textContent = '0$';
            document.getElementById('summaryTotal').textContent = '0$';
            discountRow.style.display = 'none';
            return;
        }

        emptyMsg.style.display = 'none';
        let subtotalAccumulator = 0;

        cart.forEach((item) => {
            const itemSubtotal = Number(item.price) * Number(item.cantidad);
            subtotalAccumulator += itemSubtotal;

            const tr = document.createElement('tr');
            tr.className = 'cart-item-row';
            tr.setAttribute('data-item-id', item.id_item_carrito);
            tr.setAttribute('data-product-id', item.id_producto);
            tr.setAttribute('data-title', item.title);
            tr.setAttribute('data-img', item.img);
            tr.setAttribute('data-price', item.price);
            tr.setAttribute('data-talla', item.talla);
            tr.setAttribute('data-color', item.color);
            tr.setAttribute('data-cantidad', item.cantidad);
            tr.innerHTML = `
                <td>
                    <div class="cart-item-info">
                        <img src="${item.img}" alt="${item.title}" class="cart-item-img">
                        <div>
                            <span class="cart-item-title">${item.title}</span>
                            <div class="cart-item-variant">Talla: ${item.talla} · Color: ${item.color}</div>
                        </div>
                    </div>
                </td>
                <td>${formatMoney(item.price)}</td>
                <td>
                    <div class="qty-controls">
                        <button class="qty-btn" data-cart-action="decrease" data-item-id="${item.id_item_carrito}">-</button>
                        <span>${item.cantidad}</span>
                        <button class="qty-btn" data-cart-action="increase" data-item-id="${item.id_item_carrito}">+</button>
                    </div>
                </td>
                <td>${formatMoney(itemSubtotal)}</td>
                <td>
                    <button class="btn-remove" data-cart-action="remove" data-item-id="${item.id_item_carrito}" title="Eliminar producto">✕</button>
                </td>
            `;
            container.appendChild(tr);
        });

        const discountAmount = appliedPromoCode === VALID_PROMO_CODE
            ? Math.round(subtotalAccumulator * PROMO_DISCOUNT_RATE)
            : 0;

        if (discountAmount > 0) {
            discountRow.style.display = 'flex';
            document.getElementById('summaryDiscount').textContent = `-${formatMoney(discountAmount)}`;
        } else {
            discountRow.style.display = 'none';
        }

        document.getElementById('summarySubtotal').textContent = formatMoney(subtotalAccumulator);
        document.getElementById('summaryTotal').textContent = formatMoney(subtotalAccumulator - discountAmount + SHIPPING_COST);
    }

    // Modificar cantidad o eliminar producto
    async function modificarCarrito(action, itemId, change=0) {
        try {
            const response = await fetch('../php/api/cart.php', {
                method: 'POST',
                headers: {'Content-Type':'application/json'},
                credentials: 'same-origin',
                body: JSON.stringify({action, item_id: itemId, change})
            });
            const data = await response.json();

            if (!response.ok || !data.ok) {
                setCartMessage(data.mensaje || 'No se pudo actualizar el carrito.', 'error');
                return;
            }

            cart = data.carrito || [];
            renderCart();
        } catch (error) {
            setCartMessage('No se pudo conectar con el servidor.', 'error');
        }
    }

    // Botones de cantidad y eliminar
    document.getElementById('cartItemsContainer').addEventListener('click', (e) => {
        const button = e.target.closest('[data-cart-action]');
        if (!button) return;

        const itemId = Number(button.dataset.itemId);
        const action = button.dataset.cartAction;

        if (action === 'decrease') modificarCarrito('update', itemId, -1);
        if (action === 'increase') modificarCarrito('update', itemId, 1);
        if (action === 'remove') modificarCarrito('remove', itemId);
    });

    // Aplicar código promocional
    const applyPromoBtn = document.getElementById('applyPromoBtn');
    const promoCodeInput = document.getElementById('promoCodeInput');

    function aplicarCodigoEspecial() {
        const codigoEscrito = promoCodeInput.value.trim();

        if (codigoEscrito === '') {
            appliedPromoCode = null;
            setCartMessage('');
        } else if (codigoEscrito === VALID_PROMO_CODE) {
            appliedPromoCode = codigoEscrito;
            setCartMessage('Código aplicado: 25% de descuento sobre el subtotal.', 'success');
        } else {
            appliedPromoCode = null;
            setCartMessage('Código no válido.', 'error');
        }

        renderCart();
    }

    if (applyPromoBtn && promoCodeInput) {
        applyPromoBtn.addEventListener('click', aplicarCodigoEspecial);
        promoCodeInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                aplicarCodigoEspecial();
            }
        });
    }

    // Cargar carrito al abrir la página
    document.addEventListener('DOMContentLoaded', cargarCarrito);
}
