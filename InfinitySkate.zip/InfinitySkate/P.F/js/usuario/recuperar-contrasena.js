// Mostrar ayuda del campo al enfocar
document.querySelectorAll('.field-hint').forEach((hint) => {
    const grupo = hint.closest('.input-group');
    const input = grupo ? grupo.querySelector('input') : null;
    if (input) {
        input.addEventListener('focus', () => hint.classList.add('visible'));
        input.addEventListener('blur', () => hint.classList.remove('visible'));
    }
});

// Abrir y cerrar modal de recuperación
const forgotPasswordLink = document.getElementById('forgotPasswordLink');
const forgotPasswordModal = document.getElementById('forgotPasswordModal');
const forgotPasswordClose = document.getElementById('forgotPasswordClose');
const forgotPasswordForm = document.getElementById('forgotPasswordForm');
const forgotPasswordSuccess = document.getElementById('forgotPasswordSuccess');

if (forgotPasswordLink && forgotPasswordModal) {
    forgotPasswordLink.addEventListener('click', (e) => {
        e.preventDefault();
        forgotPasswordModal.classList.add('active');
    });

    forgotPasswordModal.addEventListener('click', (e) => {
        if (e.target === forgotPasswordModal) forgotPasswordModal.classList.remove('active');
    });

    if (forgotPasswordClose) {
        forgotPasswordClose.addEventListener('click', () => {
            forgotPasswordModal.classList.remove('active');
        });
    }

    // Elementos de los 3 pasos
    const forgotForms = {
        1: document.getElementById('forgotPasswordForm'),
        2: document.getElementById('forgotCodeForm'),
        3: document.getElementById('forgotResetForm')
    };
    const forgotTextos = {
        1: document.getElementById('forgotText1'),
        2: document.getElementById('forgotText2'),
        3: document.getElementById('forgotText3')
    };
    const forgotPasswordError = document.getElementById('forgotPasswordError');
    const forgotToggle = document.getElementById('forgotToggle');
    let forgotCorreo = '';
    let forgotCodigo = '';

    // Mostrar error de recuperación
    function mostrarErrorRecuperacion(mensaje) {
        if (!forgotPasswordError) return;
        forgotPasswordError.textContent = mensaje;
        forgotPasswordError.hidden = !mensaje;
    }

    // Cambiar de paso
    function mostrarPasoRecuperacion(paso) {
        [1, 2, 3].forEach((n) => {
            if (forgotForms[n]) forgotForms[n].style.display = n === paso ? '' : 'none';
            if (forgotTextos[n]) forgotTextos[n].style.display = n === paso ? '' : 'none';
        });
        mostrarErrorRecuperacion('');
    }

    forgotPasswordLink.addEventListener('click', () => mostrarPasoRecuperacion(1));

    // Enviar solicitud de recuperación
    async function llamarRecuperacion(datos) {
        const response = await fetch('../php/auth/recuperar.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin',
            body: JSON.stringify(datos)
        });
        let data = {};
        try { data = await response.json(); } catch (error) {  }
        return { ok: response.ok && data.ok === true, mensaje: data.mensaje || 'No se pudo completar la solicitud.', datos: data };
    }

    // Manejar envío de cada paso
    function manejarPasoRecuperacion(form, procesar) {
        if (!form) return;
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            mostrarErrorRecuperacion('');
            const boton = form.querySelector('button[type="submit"]');
            boton.disabled = true;
            try {
                await procesar();
            } catch (error) {
                mostrarErrorRecuperacion('No se pudo conectar con el servidor.');
            } finally {
                boton.disabled = false;
            }
        });
    }

    // Paso 1: pedir código por correo
    manejarPasoRecuperacion(forgotForms[1], async () => {
        forgotCorreo = document.getElementById('forgotEmail').value.trim().toLowerCase();
        const r = await llamarRecuperacion({ accion: 'solicitar', correo: forgotCorreo });
        if (!r.ok) return mostrarErrorRecuperacion(r.mensaje);
        mostrarPasoRecuperacion(2);
    });

    // Paso 2: verificar código
    manejarPasoRecuperacion(forgotForms[2], async () => {
        forgotCodigo = document.getElementById('forgotCode').value.trim();
        const r = await llamarRecuperacion({ accion: 'verificar', correo: forgotCorreo, codigo: forgotCodigo });
        if (!r.ok) return mostrarErrorRecuperacion(r.mensaje);
        mostrarPasoRecuperacion(3);
    });

    // Mostrar/ocultar nueva contraseña
    if (forgotToggle) {
        forgotToggle.addEventListener('click', () => toggleVisibility('forgotNewPassword', forgotToggle));
    }

    // Paso 3: guardar nueva contraseña
    manejarPasoRecuperacion(forgotForms[3], async () => {
        const r = await llamarRecuperacion({
            accion: 'restablecer',
            correo: forgotCorreo,
            codigo: forgotCodigo,
            password: document.getElementById('forgotNewPassword').value
        });
        if (!r.ok) return mostrarErrorRecuperacion(r.mensaje);
        if (forgotPasswordModal.dataset.stay === 'true') {
            forgotPasswordModal.classList.remove('active');
            forgotForms[3].reset();
            const msgAjustes = document.getElementById('settingsPasswordSaveMsg');
            if (msgAjustes) msgAjustes.textContent = 'Contraseña actualizada correctamente.';
            return;
        }
        localStorage.setItem(SKATE_USERNAME_KEY, r.datos.usuario || '');
        window.location.href = 'principal.html';
    });
}
