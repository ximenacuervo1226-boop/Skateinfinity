<?php
require_once __DIR__ . '/../auth/require_admin.php';
require_once __DIR__ . '/../config/conexion.php';
require_once __DIR__ . '/helpers.php';

// Buscar producto a editar
$id = (int) ($_GET['id'] ?? 0);
if (!$id) {
    header('Location: productos.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM productos WHERE id_producto = ?");
$stmt->execute([$id]);
$producto = $stmt->fetch();

if (!$producto) {
    header('Location: productos.php');
    exit;
}

$error = null;

// Volver con mensaje
function volver(int $id, string $msg): void {
    header('Location: editar_producto.php?id=' . $id . '&msg=' . $msg);
    exit;
}

// Procesar formularios
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? 'actualizar_producto';

    // Actualizar datos del producto
    if ($accion === 'actualizar_producto') {
        $nombre = mb_substr(trim($_POST['nombre'] ?? ''), 0, 100);
        $idCategoria = (int) ($_POST['id_categoria'] ?? 0);
        $descripcion = mb_substr(trim($_POST['descripcion'] ?? ''), 0, 255);
        $precio = (float) ($_POST['precio'] ?? 0);
        $descuento = min(90, max(0, (float) ($_POST['descuento'] ?? 0)));
        $disponible = isset($_POST['disponible']) ? 1 : 0;
        $imagenUrl = $producto['imagen_url'];

        if ($nombre === '' || $idCategoria <= 0 || $precio <= 0) {
            $error = 'Completa nombre, categoría y un precio mayor que 0.';
        } else {
            try {
                if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK && @getimagesize($_FILES['imagen']['tmp_name'])) {
                    $imagenUrl = guardarImagenProducto($_FILES['imagen'], $nombre);
                }
                $update = $pdo->prepare(
                    "UPDATE productos SET id_categoria=?, nombre=?, descripcion=?, precio_base=?, descuento_porcentaje=?, imagen_url=?, disponible=? WHERE id_producto=?"
                );
                $update->execute([$idCategoria, $nombre, $descripcion, $precio, $descuento, $imagenUrl, $disponible, $id]);
                volver($id, 'guardado');
            } catch (PDOException $e) {
                $error = 'No se pudieron guardar los cambios.';
            }
        }

        $producto = array_merge($producto, [
            'nombre' => $nombre, 'id_categoria' => $idCategoria, 'descripcion' => $descripcion,
            'precio_base' => $precio, 'descuento_porcentaje' => $descuento, 'disponible' => $disponible,
        ]);
    }

    // Agregar variante (talla y color)
    if ($accion === 'agregar_variante') {
        // Si la categoría no lleva talla o color, se usa un valor único
        $opciones = opcionesCategoria(categoriasConOpciones($pdo), (int) $producto['id_categoria']);
        $talla = $opciones['requiere_talla'] ? mb_substr(trim($_POST['talla'] ?? ''), 0, 10) : 'Única';
        $color = $opciones['requiere_color'] ? mb_substr(trim($_POST['color'] ?? ''), 0, 30) : 'Único';
        $stock = max(0, (int) ($_POST['stock'] ?? 0));
        if ($talla !== '' && $color !== '') {
            $sku = 'SK8-' . str_pad((string) $id, 2, '0', STR_PAD_LEFT) . '-' . strtoupper(substr(md5(uniqid('', true)), 0, 6));
            try {
                $pdo->prepare("INSERT INTO variantes_productos (id_producto, talla, color, stock, sku) VALUES (?, ?, ?, ?, ?)")
                    ->execute([$id, $talla, $color, $stock, $sku]);
            } catch (PDOException $e) {
                volver($id, 'variante_repetida');
            }
        }
        volver($id, 'variante_ok');
    }

    // Actualizar stock de variante
    if ($accion === 'actualizar_variante') {
        $idVariante = (int) ($_POST['id_variante'] ?? 0);
        $stock = max(0, (int) ($_POST['stock'] ?? 0));
        $pdo->prepare("UPDATE variantes_productos SET stock=? WHERE id_variante=? AND id_producto=?")
            ->execute([$stock, $idVariante, $id]);
        volver($id, 'variante_ok');
    }

    // Eliminar variante
    if ($accion === 'eliminar_variante') {
        $idVariante = (int) ($_POST['id_variante'] ?? 0);
        try {
            $pdo->prepare(
                "DELETE ic FROM items_carrito ic JOIN variantes_productos v ON ic.id_variante = v.id_variante
                 WHERE v.id_variante = ? AND v.id_producto = ?"
            )->execute([$idVariante, $id]);
            $pdo->prepare("DELETE FROM variantes_productos WHERE id_variante=? AND id_producto=?")->execute([$idVariante, $id]);
        } catch (PDOException $e) {
            volver($id, 'variante_en_pedidos');
        }
        volver($id, 'variante_borrada');
    }
}

// Cargar categorías y variantes
$categorias = categoriasConOpciones($pdo);
$opcionesCategoria = opcionesCategoria($categorias, (int) $producto['id_categoria']);

$variantesStmt = $pdo->prepare("SELECT * FROM variantes_productos WHERE id_producto = ? ORDER BY color, id_variante");
$variantesStmt->execute([$id]);
$variantes = $variantesStmt->fetchAll();
