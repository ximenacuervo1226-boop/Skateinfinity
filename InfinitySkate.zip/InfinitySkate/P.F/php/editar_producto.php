<?php
// Cargar lógica y estructura del admin
require_once __DIR__ . '/logic/producto_editar_logic.php';
require_once __DIR__ . '/logic/admin_layout.php';
adminInicio('Editar Producto', 'productos');
$tieneImagen = !empty($producto['imagen_url']);
?>
        <?php // Mensaje de error ?>
        <?php if ($error): ?><div class="error-box"><?= e($error) ?></div><?php endif; ?>

        <?php // Formulario de datos del producto ?>
        <form method="POST" enctype="multipart/form-data" class="form-card">
            <input type="hidden" name="accion" value="actualizar_producto">
            <div class="form-grid">
                <div>
                    <div class="form-group">
                        <label>Nombre del producto</label>
                        <input type="text" name="nombre" maxlength="100" value="<?= e($producto['nombre']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Categoría</label>
                        <select name="id_categoria" required>
                            <?php foreach ($categorias as $c): ?>
                                <option value="<?= (int) $c['id_categoria'] ?>" <?= (int) $c['id_categoria'] === (int) $producto['id_categoria'] ? 'selected' : '' ?>><?= e(ucfirst($c['nombre'])) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Descripción (máx. 255 caracteres)</label>
                        <textarea name="descripcion" rows="3" maxlength="255"><?= e($producto['descripcion']) ?></textarea>
                    </div>
                    <div class="form-row-2">
                        <div class="form-group">
                            <label>Precio ($)</label>
                            <input type="number" step="100" min="0" name="precio" id="campoPrecio" value="<?= e((float) $producto['precio_base']) ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Descuento (%)</label>
                            <input type="number" step="1" min="0" max="90" name="descuento" id="campoDescuento" value="<?= e((float) $producto['descuento_porcentaje']) ?>">
                        </div>
                    </div>
                    <div class="precio-preview" id="precioPreview"></div>
                    <div class="form-group" style="margin-top:16px;">
                        <label class="check-line"><input type="checkbox" name="disponible" <?= $producto['disponible'] ? 'checked' : '' ?>> Mostrar este producto en la tienda</label>
                    </div>
                </div>

                <?php // Imagen del producto ?>
                <div class="form-group">
                    <label>Imagen del producto</label>
                    <label for="input-imagen" class="image-upload-box">
                        <span id="upload-text" <?= $tieneImagen ? 'style="display:none;"' : '' ?>>📁 Haz clic para elegir una foto</span>
                        <img id="img-preview" class="image-preview" src="<?= $tieneImagen ? e($producto['imagen_url']) : '#' ?>" alt="Vista previa" style="display:<?= $tieneImagen ? 'block' : 'none' ?>;">
                        <input type="file" id="input-imagen" name="imagen" accept="image/*">
                    </label>
                    <p class="hint">Haz clic sobre la imagen para cambiarla.</p>
                </div>
            </div>

            <?php // Botones guardar y volver ?>
            <div style="margin-top:8px;">
                <button type="submit" class="btn-primary">Guardar cambios</button>
                <a href="productos.php" class="btn-link">Volver</a>
            </div>
        </form>

        <?php // Tallas, colores y stock ?>
        <div class="form-card">
            <h2 class="section-title">Tallas, colores y stock</h2>

            <?php // Lista de variantes existentes ?>
            <?php if (empty($variantes)): ?>
                <p class="muted">Este producto todavía no tiene variantes. Agrega la primera abajo; sin stock no se puede comprar.</p>
            <?php else: foreach ($variantes as $v): ?>
                <form method="POST" class="variant-row">
                    <input type="hidden" name="id_variante" value="<?= (int) $v['id_variante'] ?>">
                    <span class="v-talla"><?= e($v['talla']) ?></span>
                    <span class="v-color"><?= e($v['color']) ?></span>
                    <span class="muted">Stock</span>
                    <input type="number" name="stock" value="<?= (int) $v['stock'] ?>" min="0">
                    <button type="submit" name="accion" value="actualizar_variante" class="btn-mini btn-ok">Guardar</button>
                    <button type="submit" name="accion" value="eliminar_variante" class="btn-mini btn-peligro" onclick="return confirm('¿Eliminar esta variante?');">Eliminar</button>
                </form>
            <?php endforeach; endif; ?>

            <?php // Formulario para agregar variante ?>
            <form method="POST" class="variant-row variant-add" style="border-bottom:none; margin-top:14px;">
                <input type="hidden" name="accion" value="agregar_variante">
                <?php // Talla y color solo se piden si la categoría los usa ?>
                <?php if ($opcionesCategoria['requiere_talla']): ?>
                    <input type="text" name="talla" placeholder="Talla (S, M, 32...)" list="tallasSugeridas" maxlength="10" required>
                <?php endif; ?>
                <?php if ($opcionesCategoria['requiere_color']): ?>
                    <input type="text" name="color" placeholder="Color" maxlength="30" required>
                <?php endif; ?>
                <input type="number" name="stock" placeholder="Stock" min="0" value="0">
                <button type="submit" class="btn-primary">+ Agregar variante</button>
                <datalist id="tallasSugeridas">
                    <option>S</option><option>M</option><option>L</option><option>XL</option>
                    <option>28</option><option>30</option><option>32</option><option>34</option><option>36</option>
                    <option>38</option><option>39</option><option>40</option><option>41</option><option>42</option><option>43</option>
                    <option>Única</option>
                </datalist>
            </form>
        </div>
<?php adminFin(); ?>
