<?php
require_once __DIR__ . '/../auth/require_admin.php';
require_once __DIR__ . '/../config/conexion.php';
require_once __DIR__ . '/roles.php';
require_once __DIR__ . '/helpers.php';

$miId = (int) $_SESSION['id_usuario'];

// Bloquear o desbloquear usuario
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion'], $_POST['id'])) {
    $idObjetivo = (int) $_POST['id'];
    $accion = $_POST['accion'];

    // Buscar al usuario objetivo y revisar si el rol actual puede bloquearlo
    $buscar = $pdo->prepare("SELECT id_usuario, rol FROM usuarios WHERE id_usuario = ?");
    $buscar->execute([$idObjetivo]);
    $objetivo = $buscar->fetch();
    if (!$objetivo || !permisosSobreUsuario($miRol, $miId, $objetivo)['bloquear']) {
        header('Location: usuarios.php?msg=' . ($idObjetivo === $miId ? 'no_self' : 'sin_permiso'));
        exit;
    }

    if ($accion === 'bloquear') {
        if ($idObjetivo === $miId) {
            header('Location: usuarios.php?msg=no_self');
            exit;
        }
        $pdo->prepare("UPDATE usuarios SET estado = 'bloqueado' WHERE id_usuario = ?")->execute([$idObjetivo]);
        header('Location: usuarios.php?msg=bloqueado');
        exit;
    }
    if ($accion === 'desbloquear') {
        $pdo->prepare("UPDATE usuarios SET estado = 'activo' WHERE id_usuario = ?")->execute([$idObjetivo]);
        header('Location: usuarios.php?msg=desbloqueado');
        exit;
    }
}

// Listar usuarios
$campoLogin = columnaExiste($pdo, 'usuarios', 'ultimo_login') ? 'ultimo_login' : 'NULL AS ultimo_login';
$usuarios = $pdo->query("SELECT id_usuario, nombre, usuario, correo, rol, estado, fecha_registro, $campoLogin FROM usuarios ORDER BY id_usuario DESC")->fetchAll();
