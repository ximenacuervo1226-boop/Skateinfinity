<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/conexion.php';
require_once __DIR__ . '/../api/common.php';

// Sin sesión: no autenticado
if (empty($_SESSION['id_usuario'])) {
    respuesta(['ok'=>true,'autenticado'=>false]);
}

// Consultar estado y rol del usuario
$fotoStmt = $pdo->prepare('SELECT foto_perfil, estado, rol FROM usuarios WHERE id_usuario = ?');
$fotoStmt->execute([$_SESSION['id_usuario']]);
$fila = $fotoStmt->fetch();

// Cerrar sesión si está bloqueado
if (!$fila || $fila['estado'] === 'bloqueado') {
    $bloqueado = $fila && $fila['estado'] === 'bloqueado';
    $_SESSION = [];
    session_destroy();
    respuesta(['ok'=>true,'autenticado'=>false,'bloqueado'=>$bloqueado]);
}
$fotoPerfil = (string)($fila['foto_perfil'] ?: '');
$_SESSION['rol'] = $fila['rol'];

// Responder con datos de la sesión
respuesta(['ok'=>true,'autenticado'=>true,'usuario'=>[
    'id'=>$_SESSION['id_usuario'],
    'nombre'=>$_SESSION['nombre'] ?? '',
    'usuario'=>$_SESSION['usuario'] ?? '',
    'rol'=>$fila['rol'],
    'foto_perfil'=>$fotoPerfil
]]);
