<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/conexion.php';
require_once __DIR__ . '/../api/common.php';

// Exigir sesión iniciada
$id = exigirSesion();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respuesta(['ok'=>false,'mensaje'=>'Método no permitido.'],405);
}

// Leer contraseñas enviadas
$d = datosEntrada();
$current = (string)($d['current_password'] ?? '');
$new = (string)($d['new_password'] ?? '');

if ($current === '' || $new === '') {
    respuesta(['ok'=>false,'mensaje'=>'Completa todos los campos.'],422);
}

// Validar seguridad de la nueva contraseña
if (!preg_match('/(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W_]).{8,}/', $new)) {
    respuesta(['ok'=>false,'mensaje'=>'La nueva contraseña no cumple los requisitos de seguridad.'],422);
}

// Verificar contraseña actual
$stmt = $pdo->prepare('SELECT password_hash FROM usuarios WHERE id_usuario = ? LIMIT 1');
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user || !password_verify($current, $user['password_hash'])) {
    respuesta(['ok'=>false,'mensaje'=>'La contraseña actual es incorrecta.'],401);
}

// Guardar nueva contraseña
$hash = password_hash($new, PASSWORD_DEFAULT);
$update = $pdo->prepare('UPDATE usuarios SET password_hash = ? WHERE id_usuario = ?');
$update->execute([$hash, $id]);

respuesta(['ok'=>true,'mensaje'=>'Contraseña actualizada correctamente.']);
