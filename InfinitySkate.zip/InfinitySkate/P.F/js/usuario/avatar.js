// Cambiar foto de perfil
document.addEventListener('DOMContentLoaded', () => {
    const settingsAvatarBox = document.getElementById('settingsAvatarBox');
    const settingsAvatarInput = document.getElementById('settingsAvatarInput');

    if (!settingsAvatarBox || !settingsAvatarInput) return;

    settingsAvatarBox.addEventListener('click', () => settingsAvatarInput.click());

    settingsAvatarInput.addEventListener('change', () => {
        const archivo = settingsAvatarInput.files[0];
        if (!archivo) return;

        // Validar que sea imagen
        if (!archivo.type.startsWith('image/')) {
            alert('Selecciona un archivo de imagen válido.');
            return;
        }

        // Recortar a cuadrado 200px
        const lector = new FileReader();
        lector.onload = (e) => {
            const imagen = new Image();
            imagen.onload = () => {
                const tamano = 200;
                const canvas = document.createElement('canvas');
                canvas.width = tamano;
                canvas.height = tamano;
                const ctx = canvas.getContext('2d');

                const escala = Math.max(tamano / imagen.width, tamano / imagen.height);
                const anchoRecorte = tamano / escala;
                const altoRecorte = tamano / escala;
                const origenX = (imagen.width - anchoRecorte) / 2;
                const origenY = (imagen.height - altoRecorte) / 2;

                ctx.drawImage(imagen, origenX, origenY, anchoRecorte, altoRecorte, 0, 0, tamano, tamano);

                // Guardar foto en servidor y header
                (async () => {
                    try {
                        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);

                        const response = await fetch('../php/auth/profile.php', {
                            method: 'POST',
                            headers: {'Content-Type': 'application/json'},
                            credentials: 'same-origin',
                            body: JSON.stringify({ foto_perfil: dataUrl })
                        });

                        const data = await response.json();

                        if (!response.ok || !data.ok) {
                            alert(data.mensaje || 'No se pudo guardar la foto de perfil.');
                            return;
                        }

                        localStorage.setItem(SKATE_AVATAR_KEY, dataUrl);
                        actualizarAvatarEnHeader();
                    } catch (error) {
                        alert('No se pudo conectar con PHP/MySQL. Verifica XAMPP.');
                    }
                })();
            };
            imagen.src = e.target.result;
        };
        lector.readAsDataURL(archivo);
    });
});
