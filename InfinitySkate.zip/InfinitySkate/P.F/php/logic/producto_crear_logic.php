<?php
require_once __DIR__ . '/../auth/require_admin.php';
require_once __DIR__ . '/../config/conexion.php';
require_once __DIR__ . '/helpers.php';

// Datos iniciales del formulario
$error = null;
$datos = ['nombre' => '', 'id_categoria' => 0, 'descripcion' => '', 'precio' => '', 'descuento' => 0];

// Crear producto al enviar
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $datos['nombre'] = mb_substr(trim($_POST['nombre'] ?? ''), 0, 100);
    $datos['id_categoria'] = (int) ($_POST['id_categoria'] ?? 0);
    $datos['descripcion'] = mb_substr(trim($_POST['descripcion'] ?? ''), 0, 255);
    $datos['precio'] = (float) ($_POST['precio'] ?? 0);
    $datos['descuento'] = min(90, max(0, (float) ($_POST['descuento'] ?? 0)));

    if ($datos['nombre'] === '' || $datos['id_categoria'] <= 0 || $datos['precio'] <= 0) {
        $error = 'Completa nombre, categoría y un precio mayor que 0.';
    } else {
        try {
            $stmt = $pdo->prepare(
                "INSERT INTO productos (id_categoria, nombre, descripcion, precio_base, descuento_porcentaje, imagen_url, disponible, fecha_creacion)
                 VALUES (?, ?, ?, ?, ?, '', 1, CURDATE())"
            );
            $stmt->execute([$datos['id_categoria'], $datos['nombre'], $datos['descripcion'], $datos['precio'], $datos['descuento']]);
            $idProducto = (int) $pdo->lastInsertId();

            // Guardar imagen si se subió
            if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK && @getimagesize($_FILES['imagen']['tmp_name'])) {
                $imagenUrl = guardarImagenProducto($_FILES['imagen'], $datos['nombre']);
                $pdo->prepare("UPDATE productos SET imagen_url = ? WHERE id_producto = ?")->execute([$imagenUrl, $idProducto]);
            }

            header('Location: editar_producto.php?id=' . $idProducto . '&msg=creado');
            exit;
        } catch (Throwable $e) {
            $error = 'No se pudo guardar el producto. Revisa los datos e inténtalo de nuevo.';
        }
    }
}

// Cargar categorías
$categorias = $pdo->query("SELECT id_categoria, nombre FROM categorias ORDER BY nombre")->fetchAll();
