<?php
require_once __DIR__ . '/../auth/require_admin.php';
require_once __DIR__ . '/../config/conexion.php';
require_once __DIR__ . '/helpers.php';

// Datos iniciales del formulario (todo activado por defecto)
$error = null;
$datos = ['nombre' => '', 'descripcion' => '', 'requiere_talla' => 1, 'requiere_color' => 1, 'visible' => 1];

// Crear categoría al enviar
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // El nombre se guarda en minúsculas y sin espacios repetidos, como las demás categorías
    $datos['nombre'] = mb_strtolower(mb_substr(trim(preg_replace('/\s+/', ' ', (string) ($_POST['nombre'] ?? ''))), 0, 50));
    $datos['descripcion'] = mb_substr(trim($_POST['descripcion'] ?? ''), 0, 255);
    $datos['requiere_talla'] = isset($_POST['requiere_talla']) ? 1 : 0;
    $datos['requiere_color'] = isset($_POST['requiere_color']) ? 1 : 0;
    $datos['visible'] = isset($_POST['visible']) ? 1 : 0;

    if (!preg_match('/^[\p{L}\p{N}][\p{L}\p{N} ]{1,49}$/u', $datos['nombre'])) {
        $error = 'El nombre debe tener entre 2 y 50 letras o números, sin símbolos.';
    } else {
        // Revisar que no exista ya una categoría con ese nombre
        $existe = $pdo->prepare("SELECT id_categoria FROM categorias WHERE nombre = ? LIMIT 1");
        $existe->execute([$datos['nombre']]);

        if ($existe->fetch()) {
            $error = 'Ya existe una categoría con ese nombre.';
        } else {
            try {
                $pdo->prepare(
                    "INSERT INTO categorias (nombre, descripcion, requiere_talla, requiere_color, visible) VALUES (?, ?, ?, ?, ?)"
                )->execute([$datos['nombre'], $datos['descripcion'], $datos['requiere_talla'], $datos['requiere_color'], $datos['visible']]);

                header('Location: categorias.php?msg=categoria_creada');
                exit;
            } catch (Throwable $e) {
                $error = 'No se pudo guardar la categoría. Revisa que la base de datos tenga la migración migracion_roles_categorias.sql.';
            }
        }
    }
}
