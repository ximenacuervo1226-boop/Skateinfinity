<?php
// Cargar lógica y estructura del admin
require_once __DIR__ . '/logic/categoria_editar_logic.php';
require_once __DIR__ . '/logic/admin_layout.php';
adminInicio('Editar Categoría', 'categorias');
?>
        <?php // Mensaje de error ?>
        <?php if ($error): ?><div class="error-box"><?= e($error) ?></div><?php endif; ?>

        <?php // Formulario de edición de categoría ?>
        <form method="POST" class="form-card" style="max-width:620px;">
            <input type="hidden" name="id" value="<?= (int) $categoria['id_categoria'] ?>">
            <div class="form-group">
                <label>Nombre de la categoría</label>
                <input type="text" name="nombre" maxlength="50" value="<?= e($datos['nombre']) ?>" required>
                <p class="hint">Así se verá en el menú de categorías de la tienda.</p>
            </div>
            <div class="form-group">
                <label>Descripción (opcional, máx. 255 caracteres)</label>
                <textarea name="descripcion" rows="3" maxlength="255"><?= e($datos['descripcion']) ?></textarea>
            </div>
            <div class="form-group">
                <label>Variantes de sus productos</label>
                <label class="check-line"><input type="checkbox" name="requiere_talla" <?= $datos['requiere_talla'] ? 'checked' : '' ?>> Los productos llevan talla (S, M, 32...)</label>
                <label class="check-line"><input type="checkbox" name="requiere_color" <?= $datos['requiere_color'] ? 'checked' : '' ?>> Los productos llevan color</label>
            </div>
            <div class="form-group">
                <label class="check-line"><input type="checkbox" name="visible" <?= $datos['visible'] ? 'checked' : '' ?>> Mostrar esta categoría en la tienda</label>
                <p class="hint">Si la ocultas, ni la categoría ni sus productos salen en la web.</p>
            </div>
            <?php // Botones guardar y cancelar ?>
            <div style="margin-top:14px;">
                <button type="submit" class="btn-primary">Guardar cambios</button>
                <a href="categorias.php" class="btn-link">Cancelar</a>
            </div>
        </form>
<?php adminFin(); ?>
