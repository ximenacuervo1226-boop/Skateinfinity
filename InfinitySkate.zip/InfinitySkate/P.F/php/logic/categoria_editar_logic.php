<?php
require_once __DIR__ . '/../auth/require_admin.php';
require_once __DIR__ . '/../config/conexion.php';
require_once __DIR__ . '/helpers.php';

// Buscar la categoría a editar
$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
if (!$id) {
    header('Location: categorias.php');
    exit;
}
if (!columnaExiste($pdo, 'categorias', 'visible')) {
    header('Location: categorias.php?msg=categoria_error');
    exit;
}
$stmt = $pdo->prepare("SELECT * FROM categorias WHERE id_categoria = ?");
$stmt->execute([$id]);
$categoria = $stmt->fetch();
if (!$categoria) {
    header('Location: categorias.php');
    exit;
}

$error = null;
$datos = [
    'nombre' => $categoria['nombre'], 'descripcion' => $categoria['descripcion'],
    'requiere_talla' => (int) $categoria['requiere_talla'], 'requiere_color' => (int) $categoria['requiere_color'],
    'visible' => (int) $categoria['visible'],
];

// Guardar cambios al enviar
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $datos['nombre'] = mb_strtolower(mb_substr(trim(preg_replace('/\s+/', ' ', (string) ($_POST['nombre'] ?? ''))), 0, 50));
    $datos['descripcion'] = mb_substr(trim($_POST['descripcion'] ?? ''), 0, 255);
    $datos['requiere_talla'] = isset($_POST['requiere_talla']) ? 1 : 0;
    $datos['requiere_color'] = isset($_POST['requiere_color']) ? 1 : 0;
    $datos['visible'] = isset($_POST['visible']) ? 1 : 0;

    if (!preg_match('/^[\p{L}\p{N}][\p{L}\p{N} ]{1,49}$/u', $datos['nombre'])) {
        $error = 'El nombre debe tener entre 2 y 50 letras o números, sin símbolos.';
    } else {
        // Que no choque con otra categoría
        $existe = $pdo->prepare("SELECT id_categoria FROM categorias WHERE nombre = ? AND id_categoria <> ? LIMIT 1");
        $existe->execute([$datos['nombre'], $id]);
        if ($existe->fetch()) {
            $error = 'Ya existe otra categoría con ese nombre.';
        } else {
            try {
                $pdo->prepare(
                    "UPDATE categorias SET nombre=?, descripcion=?, requiere_talla=?, requiere_color=?, visible=? WHERE id_categoria=?"
                )->execute([$datos['nombre'], $datos['descripcion'], $datos['requiere_talla'], $datos['requiere_color'], $datos['visible'], $id]);
                header('Location: categorias.php?msg=categoria_guardada');
                exit;
            } catch (Throwable $e) {
                $error = 'No se pudo guardar la categoría.';
            }
        }
    }
}
