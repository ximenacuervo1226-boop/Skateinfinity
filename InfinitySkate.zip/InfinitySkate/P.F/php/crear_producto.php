<?php
// Cargar lógica y estructura del admin
require_once __DIR__ . '/logic/producto_crear_logic.php';
require_once __DIR__ . '/logic/admin_layout.php';
adminInicio('Agregar Producto', 'productos');
?>
        <?php // Mensaje de error ?>
        <?php if ($error): ?><div class="error-box"><?= e($error) ?></div><?php endif; ?>

        <?php // Formulario de nuevo producto ?>
        <form method="POST" enctype="multipart/form-data" class="form-card">
            <div class="form-grid">
                <?php // Datos del producto ?>
                <div>
                    <div class="form-group">
                        <label>Nombre del producto</label>
                        <input type="text" name="nombre" maxlength="100" value="<?= e($datos['nombre']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Categoría</label>
                        <select name="id_categoria" required>
                            <option value="">Selecciona una categoría</option>
                            <?php foreach ($categorias as $c): ?>
                                <option value="<?= (int) $c['id_categoria'] ?>" <?= (int) $c['id_categoria'] === (int) $datos['id_categoria'] ? 'selected' : '' ?>><?= e(ucfirst($c['nombre'])) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Descripción (máx. 255 caracteres)</label>
                        <textarea name="descripcion" rows="3" maxlength="255"><?= e($datos['descripcion']) ?></textarea>
                    </div>
                    <div class="form-row-2">
                        <div class="form-group">
                            <label>Precio ($)</label>
                            <input type="number" step="100" min="0" name="precio" id="campoPrecio" value="<?= e($datos['precio']) ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Descuento (%)</label>
                            <input type="number" step="1" min="0" max="90" name="descuento" id="campoDescuento" value="<?= e($datos['descuento']) ?>">
                        </div>
                    </div>
                    <div class="precio-preview" id="precioPreview"></div>
                </div>

                <?php // Imagen del producto ?>
                <div class="form-group">
                    <label>Imagen del producto</label>
                    <label for="input-imagen" class="image-upload-box">
                        <span id="upload-text">📁 Haz clic para elegir una foto</span>
                        <img id="img-preview" class="image-preview" src="#" alt="Vista previa" style="display:none;">
                        <input type="file" id="input-imagen" name="imagen" accept="image/*">
                    </label>
                </div>
            </div>

            <p class="hint">Después de guardar podrás agregar las tallas, colores y stock. El producto sale en la tienda apenas tenga stock.</p>

            <?php // Botones guardar y cancelar ?>
            <div style="margin-top:14px;">
                <button type="submit" class="btn-primary">Guardar producto</button>
                <a href="productos.php" class="btn-link">Cancelar</a>
            </div>
        </form>
<?php adminFin(); ?>
