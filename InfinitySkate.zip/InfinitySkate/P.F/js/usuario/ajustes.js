if (document.getElementById('settingsSaveBtn')) {
    // Menú lateral y paneles de ajustes
    const sidebarItems = document.querySelectorAll('.settings-sidebar-item');
    const panels = {
        perfil: document.getElementById('panelPerfil'),
        direcciones: document.getElementById('panelDirecciones'),
        pedidos: document.getElementById('panelPedidos'),
        seguridad: document.getElementById('panelSeguridad')
    };

    // Dar formato a fecha y hora de la base de datos: 21/10/2026 03:45 PM
    function formatearFechaHora(valor) {
        const m = /^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2}))?/.exec(String(valor || ''));
        if (!m) return valor || '';
        const h24 = parseInt(m[4] || '0', 10);
        const h12 = h24 % 12 === 0 ? 12 : h24 % 12;
        return `${m[3]}/${m[2]}/${m[1]} ${String(h12).padStart(2, '0')}:${m[5] || '00'} ${h24 >= 12 ? 'PM' : 'AM'}`;
    }

    // Mostrar panel elegido
    function mostrarPanel(tab) {
        Object.values(panels).forEach(panel => {
            if (panel) panel.style.display = 'none';
        });
        if (panels[tab]) panels[tab].style.display = '';
    }

    mostrarPanel('perfil');

    // Cambiar de pestaña en ajustes
    sidebarItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            sidebarItems.forEach(i => i.classList.remove('active'));
            item.classList.add('active');

            const tab = item.dataset.tab;
            mostrarPanel(tab);

            if (tab === 'direcciones') cargarDireccion();
            if (tab === 'pedidos') cargarHistorialPedidos();
        });
    });

    // Cargar datos del perfil
    async function cargarPerfil() {
        try {
            const response = await fetch('../php/auth/profile.php', {credentials: 'same-origin'});
            const data = await response.json();

            if (!response.ok || !data.ok) {
                if (response.status === 401) {
                    alert('Debes iniciar sesión para acceder a tu perfil.');
                    window.location.href = 'landing.html';
                }
                return;
            }

            document.getElementById('settingsUsername').value = data.usuario.usuario || '';
            document.getElementById('settingsEmail').value = data.usuario.correo || '';
            document.getElementById('settingsBio').value = data.usuario.bio || '';

            localStorage.setItem(SKATE_USERNAME_KEY, data.usuario.usuario || '');
            localStorage.setItem(SKATE_EMAIL_KEY, data.usuario.correo || '');
            localStorage.setItem(SKATE_BIO_KEY, data.usuario.bio || '');
            actualizarNombreUsuarioEnHeader();

            if (data.usuario.foto_perfil) {
                localStorage.setItem(SKATE_AVATAR_KEY, data.usuario.foto_perfil);
            } else {
                localStorage.removeItem(SKATE_AVATAR_KEY);
            }
            actualizarAvatarEnHeader();
        } catch (error) {
            document.getElementById('settingsUsername').value = localStorage.getItem(SKATE_USERNAME_KEY) || '';
            document.getElementById('settingsEmail').value = localStorage.getItem(SKATE_EMAIL_KEY) || '';
            document.getElementById('settingsBio').value = localStorage.getItem(SKATE_BIO_KEY) || '';
        }
    }

    // Cargar perfil al abrir la página
    document.addEventListener('DOMContentLoaded', cargarPerfil);

    // Guardar cambios del perfil
    const settingsSaveBtn = document.getElementById('settingsSaveBtn');
    const settingsSaveMsg = document.getElementById('settingsSaveMsg');

    settingsSaveBtn.addEventListener('click', async () => {
        const nuevoUsuario = document.getElementById('settingsUsername').value.trim();
        const nuevoEmail = document.getElementById('settingsEmail').value.trim().toLowerCase();
        const nuevaBio = document.getElementById('settingsBio').value.trim();

        try {
            const response = await fetch('../php/auth/profile.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                credentials: 'same-origin',
                body: JSON.stringify({
                    usuario: nuevoUsuario,
                    correo: nuevoEmail,
                    bio: nuevaBio
                })
            });

            const data = await response.json();

            if (!response.ok || !data.ok) {
                mostrarModalExito(data.mensaje || 'No se pudieron guardar los cambios.', null, 'error');
                return;
            }

            localStorage.setItem(SKATE_USERNAME_KEY, nuevoUsuario);
            localStorage.setItem(SKATE_EMAIL_KEY, nuevoEmail);
            localStorage.setItem(SKATE_BIO_KEY, nuevaBio);
            actualizarNombreUsuarioEnHeader();

            settingsSaveMsg.textContent = '';
            mostrarModalExito('Cambios guardados.');
        } catch (error) {
            mostrarModalExito('No se pudo conectar con el servidor.', null, 'error');
        }
    });

    // Cargar dirección guardada
    async function cargarDireccion() {
        try {
            const response = await fetch('../php/api/direccion.php', { credentials: 'same-origin' });
            const data = await response.json();
            const dir = (data.ok && data.direccion) ? data.direccion : { direccion: '', ciudad: '', referencia: '' };
            document.getElementById('settingsDireccion').value = dir.direccion || '';
            document.getElementById('settingsCiudad').value = dir.ciudad || '';
            document.getElementById('settingsReferencia').value = dir.referencia || '';
        } catch (error) {
        }
    }

    // Guardar dirección
    const addressSaveBtn = document.getElementById('settingsAddressSaveBtn');
    if (addressSaveBtn) {
        addressSaveBtn.addEventListener('click', async () => {
            const msg = document.getElementById('settingsAddressSaveMsg');
            try {
                const response = await fetch('../php/api/direccion.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'same-origin',
                    body: JSON.stringify({
                        direccion: document.getElementById('settingsDireccion').value.trim(),
                        ciudad: document.getElementById('settingsCiudad').value.trim(),
                        referencia: document.getElementById('settingsReferencia').value.trim()
                    })
                });
                const data = await response.json();
                if (data.ok) {
                    msg.textContent = '';
                    mostrarModalExito(data.mensaje || 'Dirección guardada.');
                } else {
                    mostrarModalExito(data.mensaje || 'No se pudo guardar la dirección.', null, 'error');
                }
            } catch (error) {
                mostrarModalExito('No se pudo conectar con el servidor.', null, 'error');
            }
        });
    }

    // Cargar historial de pedidos
    async function cargarHistorialPedidos() {
        const container = document.getElementById('orderHistoryContainer');
        if (!container) return;

        container.innerHTML = '<p class="settings-empty-msg">Cargando historial...</p>';

        try {
            const response = await fetch('../php/api/pedidos.php', {credentials: 'same-origin'});
            const data = await response.json();

            if (response.status === 401) {
                container.innerHTML = '<p class="settings-empty-msg">Debes iniciar sesión para ver tu historial.</p>';
                return;
            }

            if (!response.ok || !data.ok) {
                container.innerHTML = '<p class="settings-empty-msg">No se pudo cargar el historial de pedidos.</p>';
                return;
            }

            const pedidos = data.pedidos || [];

            if (!pedidos.length) {
                container.innerHTML = '<p class="settings-empty-msg">Todavía no tienes pedidos registrados.</p>';
                return;
            }

            container.innerHTML = pedidos.map(pedido => `
                <div class="order-history-card" data-id-pedido="${pedido.id_pedido}" role="button" tabindex="0">
                    <div>
                        <strong>Pedido #${pedido.id_pedido}</strong>
                        <span>${formatearFechaHora(pedido.fecha_pedido)}</span>
                    </div>
                    <div>
                        <strong>${Number(pedido.pago_total).toLocaleString('es-CO')}$</strong>
                        <span class="order-status">${pedido.estado}</span>
                    </div>
                </div>
            `).join('');

            container.querySelectorAll('.order-history-card').forEach(card => {
                const abrir = () => verDetallePedido(card.dataset.idPedido);
                card.addEventListener('click', abrir);
                card.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); abrir(); }
                });
            });
        } catch (error) {
            container.innerHTML = '<p class="settings-empty-msg">No se pudo conectar con el servidor.</p>';
        }
    }

    // Modal de detalle del pedido
    const orderDetailModal = document.getElementById('orderDetailModal');
    const orderDetailClose = document.getElementById('orderDetailClose');

    function cerrarDetallePedido() {
        if (orderDetailModal) orderDetailModal.classList.remove('active');
    }

    if (orderDetailClose) orderDetailClose.addEventListener('click', cerrarDetallePedido);
    if (orderDetailModal) {
        orderDetailModal.addEventListener('click', (e) => {
            if (e.target === orderDetailModal) cerrarDetallePedido();
        });
    }

    // Ver detalle de un pedido
    async function verDetallePedido(idPedido) {
        if (!orderDetailModal) return;

        const summaryEl = document.getElementById('orderDetailSummary');
        const listEl = document.getElementById('orderDetailList');
        summaryEl.innerHTML = '<p>Cargando...</p>';
        listEl.innerHTML = '';
        orderDetailModal.classList.add('active');

        try {
            const response = await fetch('../php/api/pedidos.php?id=' + encodeURIComponent(idPedido), { credentials: 'same-origin' });
            const data = await response.json();

            if (!response.ok || !data.ok) {
                summaryEl.innerHTML = `<p>${data.mensaje || 'No se pudo cargar el detalle del pedido.'}</p>`;
                return;
            }

            const pedido = data.pedido;
            const items = data.items || [];

            summaryEl.innerHTML = `
                <p><strong>Pedido #${pedido.id_pedido}</strong></p>
                <p>Fecha: ${formatearFechaHora(pedido.fecha_pedido)}</p>
                <p>Estado: <span class="order-status">${pedido.estado}</span></p>
                <p>Dirección de envío: ${pedido.direccion_envio}</p>
                ${pedido.descuento > 0 ? `<p>Descuento: -${Number(pedido.descuento).toLocaleString('es-CO')}$</p>` : ''}
                <p>Total pagado: <strong>${Number(pedido.pago_total).toLocaleString('es-CO')}$</strong></p>
            `;

            listEl.innerHTML = items.map(item => `
                <div class="order-detail-item">
                    <img src="${item.img}" alt="${item.title}" class="order-detail-item-img">
                    <div class="order-detail-item-info">
                        <strong>${item.title}</strong>
                        <span>Talla: ${item.talla} · Color: ${item.color}</span>
                        <span>Cantidad: ${item.cantidad}</span>
                    </div>
                    <span class="order-detail-item-price">${Number(item.precio_unitario * item.cantidad).toLocaleString('es-CO')}$</span>
                </div>
            `).join('') || '<p class="settings-empty-msg">Sin artículos para mostrar.</p>';
        } catch (error) {
            summaryEl.innerHTML = '<p>No se pudo conectar con el servidor.</p>';
        }
    }

    // Cambiar contraseña
    const passwordSaveBtn = document.getElementById('settingsPasswordSaveBtn');
    if (passwordSaveBtn) {
        passwordSaveBtn.addEventListener('click', async () => {
            const actual = document.getElementById('currentPassword').value;
            const nueva = document.getElementById('newPassword').value;
            const confirmacion = document.getElementById('confirmNewPassword').value;
            const msg = document.getElementById('settingsPasswordSaveMsg');

            if (!actual || !nueva || !confirmacion) {
                mostrarModalExito('Completa todos los campos.', null, 'error');
                return;
            }

            if (nueva !== confirmacion) {
                mostrarModalExito('Las nuevas contraseñas no coinciden.', null, 'error');
                return;
            }

            try {
                const response = await fetch('../php/auth/password.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    credentials: 'same-origin',
                    body: JSON.stringify({
                        current_password: actual,
                        new_password: nueva
                    })
                });

                const data = await response.json();

                if (response.ok && data.ok) {
                    document.getElementById('currentPassword').value = '';
                    document.getElementById('newPassword').value = '';
                    document.getElementById('confirmNewPassword').value = '';
                    msg.textContent = '';
                    mostrarModalExito(data.mensaje || 'Contraseña actualizada.');
                } else {
                    mostrarModalExito(data.mensaje || 'No se pudo cambiar la contraseña.', null, 'error');
                }
            } catch (error) {
                mostrarModalExito('No se pudo conectar con el servidor.', null, 'error');
            }
        });
    }
}
