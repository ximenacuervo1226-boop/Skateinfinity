<?php
require_once __DIR__ . '/../auth/require_admin.php';
require_once __DIR__ . '/../config/conexion.php';
require_once __DIR__ . '/helpers.php';

// Búsqueda y paginación
$porPagina = 8;
$q = trim((string) ($_GET['q'] ?? ''));

$where = '';
$params = [];
if ($q !== '') {
    $limpio = ltrim($q, '#');
    $like = '%' . addcslashes($q, '%_\\') . '%';
    $where = 'WHERE (p.nombre LIKE :q1 OR c.nombre LIKE :q2 OR p.descripcion LIKE :q3 OR p.id_producto = :q4)';
    $params = [':q1' => $like, ':q2' => $like, ':q3' => $like, ':q4' => ctype_digit($limpio) ? (int) $limpio : 0];
}

// Contar productos
$count = $pdo->prepare("SELECT COUNT(*) FROM productos p LEFT JOIN categorias c ON p.id_categoria = c.id_categoria $where");
foreach ($params as $k => $v) $count->bindValue($k, $v);
$count->execute();
$totalProductosDb = (int) $count->fetchColumn();

$totalPaginas = max(1, (int) ceil($totalProductosDb / $porPagina));
$paginaActual = min($totalPaginas, max(1, (int) ($_GET['pagina'] ?? 1)));
$offset = ($paginaActual - 1) * $porPagina;

// Listar productos de la página
$stmt = $pdo->prepare(
    "SELECT p.id_producto, p.nombre, p.precio_base, p.descuento_porcentaje, p.imagen_url, p.disponible,
            c.nombre AS categoria_nombre,
            (SELECT COALESCE(SUM(v.stock), 0) FROM variantes_productos v WHERE v.id_producto = p.id_producto) AS stock_total
     FROM productos p
     LEFT JOIN categorias c ON p.id_categoria = c.id_categoria
     $where
     ORDER BY p.id_producto DESC
     LIMIT :limite OFFSET :offset"
);
foreach ($params as $k => $v) $stmt->bindValue($k, $v);
$stmt->bindValue(':limite', $porPagina, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$productos = $stmt->fetchAll();
