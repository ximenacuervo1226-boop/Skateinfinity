<?php
declare(strict_types=1);

// Datos de la base de datos
$host = '127.0.0.1';
$db   = 'skateinfinity';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

// Puertos a probar
$puertosAProbar = ['3307', '3306'];

// Opciones de PDO
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

// Conectar a MySQL
$pdo = null;
foreach ($puertosAProbar as $port) {
    try {
        $dsn = "mysql:host={$host};port={$port};dbname={$db};charset={$charset}";
        $pdo = new PDO($dsn, $user, $pass, $options);
        break;
    } catch (PDOException $e) {
        $pdo = null;
    }
}

// Error si no hay conexión
if ($pdo === null) {
    http_response_code(500);
    die('No se pudo conectar con MySQL. Verifica que MySQL esté iniciado en XAMPP y que la base de datos skateinfinity exista.');
}
