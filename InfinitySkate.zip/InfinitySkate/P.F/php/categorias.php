<?php
// Cargar lógica y estructura del admin (admin y propietario pueden entrar)
require_once __DIR__ . '/logic/categorias_logic.php';
require_once __DIR__ . '/logic/admin_layout.php';
adminInicio('Gestión de Categorías', 'categorias');
?>
        <?php // Tabla de categorías ?>
        <div class="table-container">
            <?php // Buscador y botón nueva categoría ?>
            <div class="table-header-action">
                <input type="text" class="search-input" placeholder="Buscar por nombre o #ID..." data-filtra="#categoriasTableBody" autocomplete="off">
                <div class="header-botones">
                    <a href="crear_categoria.php" class="btn-nuevo-producto">+ Nueva categoría</a>
                </div>
            </div>
            <div class="table-scroll">
                <table>
                    <thead>
                        <tr><th>ID</th><th>Nombre</th><th>Descripción</th><th>Productos</th><th>Talla</th><th>Color</th><th>En tienda</th><th>Acciones</th></tr>
                    </thead>
                    <tbody id="categoriasTableBody">
                        <?php // Filas de categorías ?>
                        <?php if (empty($categorias)): ?>
                            <tr><td colspan="8" class="empty">No hay categorías registradas.</td></tr>
                        <?php else: foreach ($categorias as $c): ?>
                            <tr data-search="<?= e(strtolower($c['id_categoria'] . ' ' . $c['nombre'] . ' ' . $c['descripcion'])) ?>">
                                <td>#<?= (int) $c['id_categoria'] ?></td>
                                <td><?= e(ucfirst($c['nombre'])) ?></td>
                                <td class="muted"><?= e($c['descripcion']) ?></td>
                                <td><?= (int) $c['total_productos'] ?></td>
                                <td><?= $c['requiere_talla'] ? 'Sí' : 'No' ?></td>
                                <td><?= $c['requiere_color'] ? 'Sí' : 'No' ?></td>
                                <td><span class="badge <?= $c['visible'] ? 'badge-visible' : 'badge-oculto' ?>"><?= $c['visible'] ? 'Visible' : 'Oculta' ?></span></td>
                                <td>
                                    <?php // Botones editar y eliminar ?>
                                    <div class="acciones">
                                        <a href="editar_categoria.php?id=<?= (int) $c['id_categoria'] ?>" class="btn-mini btn-editar">Editar</a>
                                        <form method="POST" action="eliminar_categoria.php" onsubmit="return confirm('¿Eliminar la categoría «<?= e(addslashes(ucfirst($c['nombre']))) ?>»? Esta acción no se puede deshacer.');">
                                            <input type="hidden" name="id" value="<?= (int) $c['id_categoria'] ?>">
                                            <button type="submit" class="btn-mini btn-peligro">Eliminar</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php adminFin(); ?>
