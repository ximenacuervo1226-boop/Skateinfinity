// Menú desplegable de categorías
const dropdown = document.getElementById('categoryDropdown');
const btn = document.getElementById('dropdownBtn');

if (dropdown && btn) {
    btn.addEventListener('click', (e) => {
        e.stopPropagation();
        dropdown.classList.toggle('active');
    });
}

// Menú desplegable de cuenta
const accountDropdown = document.getElementById('accountDropdown');
const accountBtn = document.getElementById('accountDropdownBtn');

if (accountDropdown && accountBtn) {
    accountBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        accountDropdown.classList.toggle('active');
    });
}

// Cerrar menús al hacer clic fuera
document.addEventListener('click', (e) => {
    if (dropdown && !dropdown.contains(e.target)) {
        dropdown.classList.remove('active');
    }
    if (accountDropdown && !accountDropdown.contains(e.target)) {
        accountDropdown.classList.remove('active');
    }
});
