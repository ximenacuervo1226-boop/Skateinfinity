<?php
// Cargar datos y estructura del panel
require_once __DIR__ . '/logic/dashboard_logic.php';
require_once __DIR__ . '/logic/admin_layout.php';
adminInicio('Panel de Control', 'inicio');
?>
        <?php // Tarjetas de estadísticas ?>
        <div class="stats-grid">
            <div class="stat-card"><h3>Ventas totales</h3><p class="stat-number"><?= dinero($totalVentas) ?></p></div>
            <div class="stat-card"><h3>Pedidos</h3><p class="stat-number"><?= $totalPedidos ?></p></div>
            <div class="stat-card"><h3>Productos</h3><p class="stat-number"><?= $totalProductos ?></p></div>
            <div class="stat-card"><h3>Clientes</h3><p class="stat-number"><?= $totalClientes ?></p></div>
        </div>

        <?php // Tabla de últimos pedidos ?>
        <div class="table-container">
            <h2 class="section-title">Últimos pedidos</h2>
            <div class="table-scroll">
                <table>
                    <thead>
                        <tr><th>ID</th><th>Cliente</th><th>Fecha</th><th>Total</th><th>Estado</th></tr>
                    </thead>
                    <tbody>
                        <?php if (empty($ultimosPedidos)): ?>
                            <tr><td colspan="5" class="empty">No hay pedidos registrados.</td></tr>
                        <?php else: foreach ($ultimosPedidos as $pedido): ?>
                            <tr>
                                <td>#<?= (int) $pedido['id_pedido'] ?></td>
                                <td><?= e($pedido['cliente_nombre'] ?? 'Cliente') ?></td>
                                <td><?= fechaHora($pedido['fecha_pedido']) ?></td>
                                <td><?= dinero($pedido['pago_total']) ?></td>
                                <td><span class="status <?= e(str_replace(' ', '-', strtolower($pedido['estado']))) ?>"><?= e(ucwords(strtolower($pedido['estado']))) ?></span></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php adminFin(); ?>
