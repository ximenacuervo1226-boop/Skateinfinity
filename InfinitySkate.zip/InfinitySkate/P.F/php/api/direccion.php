<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/conexion.php';
require_once __DIR__ . '/common.php';

// Exigir sesión iniciada
$idUsuario = exigirSesion();

// Consultar dirección guardada
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $pdo->prepare('SELECT direccion, ciudad, referencia FROM direcciones WHERE id_usuario = ? LIMIT 1');
    $stmt->execute([$idUsuario]);
    $dir = $stmt->fetch();
    respuesta(['ok' => true, 'direccion' => $dir ?: ['direccion' => '', 'ciudad' => '', 'referencia' => '']]);
}

// Solo permitir POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respuesta(['ok' => false, 'mensaje' => 'Método no permitido.'], 405);
}

// Validar datos de dirección
$d = datosEntrada();
$direccion = trim((string)($d['direccion'] ?? ''));
$ciudad = trim((string)($d['ciudad'] ?? ''));
$referencia = trim((string)($d['referencia'] ?? ''));

if ($direccion === '' || $ciudad === '') {
    respuesta(['ok' => false, 'mensaje' => 'La dirección y la ciudad son obligatorias.'], 422);
}

// Guardar o actualizar dirección
$stmt = $pdo->prepare(
    'INSERT INTO direcciones (id_usuario, direccion, ciudad, referencia)
     VALUES (?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE direccion = VALUES(direccion), ciudad = VALUES(ciudad), referencia = VALUES(referencia)'
);
$stmt->execute([$idUsuario, $direccion, $ciudad, $referencia]);

respuesta([
    'ok' => true,
    'mensaje' => 'Dirección guardada.',
    'direccion' => ['direccion' => $direccion, 'ciudad' => $ciudad, 'referencia' => $referencia]
]);
