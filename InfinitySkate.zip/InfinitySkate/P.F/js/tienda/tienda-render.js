(function () {
    // Datos del catálogo y utilidades
    const LISTA = Array.isArray(window.CATALOGO_LISTA) ? window.CATALOGO_LISTA : [];
    const ORDEN_CATEGORIAS = ['camisas', 'buzos', 'chaquetas', 'pantalones', 'zapatos', 'gorras'];

    const esc = (t) => String(t == null ? '' : t).replace(/[&<>"']/g, (c) => (
        { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    ));
    const dinero = (n) => Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.') + '$';
    const mayus = (t) => t.charAt(0).toUpperCase() + t.slice(1);
    const tieneDescuento = (p) => p.descuento > 0;
    const porDescuento = (a, b) => (b.descuento - a.descuento) || (a.id - b.id);

    // Mezclar lista al azar
    function barajar(arr) {
        const a = arr.slice();
        for (let i = a.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [a[i], a[j]] = [a[j], a[i]];
        }
        return a;
    }

    // Crear tarjeta de producto
    function tarjeta(p, opciones) {
        const o = opciones || {};
        const badge = tieneDescuento(p) ? '<span class="discount-badge">-' + Math.round(p.descuento) + '%</span>' : '';
        const original = tieneDescuento(p) ? '<span class="original-price">' + dinero(p.precio_original) + '</span>' : '';
        const atributoCat = o.atributoCategoria || 'data-categoria';
        const clases = 'product-card' + (o.extra ? ' extra-product' : '');
        const titulo = 'product-title' + (o.titulo ? ' ' + o.titulo : '');
        const img = p.imagen
            ? '<img alt="' + esc(p.nombre) + '" src="' + esc(p.imagen) + '"/>'
            : '<img alt="' + esc(p.nombre) + '" src="imagen-no-disponible.jpg"/>';
        return '<div class="' + clases + '" ' + atributoCat + '="' + esc(p.categoria) + '"' +
            ' data-disponible="' + (p.disponible ? 'true' : 'false') + '" data-product-id="' + p.id + '">' +
            badge + '<div class="product-img-box">' + img + '</div>' +
            '<h3 class="' + titulo + '">' + esc(p.nombre) + '</h3>' + original +
            '<span class="product-price">' + dinero(p.precio) + '</span></div>';
    }

    // Pintar recomendados, promos y extras
    const recomendados = document.getElementById('recommendedGrid');
    const promos = document.getElementById('discountsGrid');
    const extras = document.getElementById('extraProductsGrid');

    if (recomendados && promos && extras) {
        const sinDescuento = LISTA.filter((p) => !tieneDescuento(p));

        const candidatos = sinDescuento.filter((p) => p.disponible);
        const elegidos = barajar(candidatos.length ? candidatos : sinDescuento).slice(0, 4);
        const idsElegidos = new Set(elegidos.map((p) => p.id));

        recomendados.innerHTML = elegidos.map((p) => tarjeta(p, { titulo: 'nombre' })).join('');
        promos.innerHTML = LISTA.filter(tieneDescuento).sort(porDescuento)
            .map((p) => tarjeta(p, { titulo: 'nombre' })).join('');
        extras.innerHTML = sinDescuento.filter((p) => !idsElegidos.has(p.id))
            .map((p) => tarjeta(p, { titulo: 'nombre', extra: true })).join('');

        if (!elegidos.length) {
            const titulo = document.getElementById('recommendedTitle');
            if (titulo) titulo.style.display = 'none';
        }
    }

    // Pintar filas por categoría
    const contenedor = document.getElementById('productGrid');
    if (contenedor && contenedor.classList.contains('categories-list')) {
        // Categorías nuevas creadas en el panel (aunque todavía no tengan productos)
        const nuevasCat = (Array.isArray(window.CATALOGO_CATEGORIAS) ? window.CATALOGO_CATEGORIAS : []).map((c) => c.slug);
        const extrasCat = nuevasCat.concat(LISTA.map((p) => p.categoria)).filter((c) => ORDEN_CATEGORIAS.indexOf(c) < 0);
        const categorias = ORDEN_CATEGORIAS.concat(Array.from(new Set(extrasCat)));

        contenedor.innerHTML = categorias.map((cat) => {
            const productos = LISTA.filter((p) => p.categoria === cat);

            const ordenados = productos.filter(tieneDescuento).sort(porDescuento)
                .concat(productos.filter((p) => !tieneDescuento(p)).sort((a, b) => a.id - b.id));
            const tarjetas = ordenados.map((p) => tarjeta(p, { atributoCategoria: 'data-category' })).join('');
            const proximamente = '<div class="product-card" data-category="' + esc(cat) + '" data-disponible="false">' +
                '<div class="product-img-box"><img alt="Próximamente más" src="imagen-no-disponible.jpg"/></div>' +
                '<h3 class="product-title">en produccion</h3><span class="product-price">-</span></div>';
            const nombre = mayus(cat);
            return '<section class="category-row-section" data-category-section="' + esc(cat) + '">' +
                '<h2 class="section-title category-row-title">' + esc(nombre) + '</h2>' +
                '<div class="category-row-viewport">' +
                '<button aria-label="Ver productos anteriores de ' + esc(nombre) + '" class="category-row-arrow category-row-arrow-prev" type="button">‹</button>' +
                '<div class="category-row-track">' + tarjetas + proximamente + '</div>' +
                '<button aria-label="Ver más productos de ' + esc(nombre) + '" class="category-row-arrow category-row-arrow-next" type="button">›</button>' +
                '</div></section>';
        }).join('');
    }
})();
