<?php
// Cargar lógica y estructura del admin
require_once __DIR__ . '/logic/usuarios_logic.php';
require_once __DIR__ . '/logic/admin_layout.php';
adminInicio('Gestión de Usuarios', 'usuarios');
?>
        <?php // Tabla de usuarios ?>
        <div class="table-container">
            <?php // Buscador de usuarios ?>
            <div class="table-header-action">
                <input type="text" class="search-input" placeholder="Buscar por nombre, usuario o correo..." data-filtra="#usuariosTableBody" autocomplete="off">
            </div>
            <div class="table-scroll">
                <table>
                    <thead>
                        <tr><th>ID</th><th>Nombre / Usuario</th><th>Correo</th><th>Rol</th><th>Estado</th><th>Registro</th><th>Último inicio de sesión</th><th>Acciones</th></tr>
                    </thead>
                    <tbody id="usuariosTableBody">
                        <?php // Filas de usuarios ?>
                        <?php if (empty($usuarios)): ?>
                            <tr><td colspan="8" class="empty">No hay usuarios registrados.</td></tr>
                        <?php else: foreach ($usuarios as $u):
                            $bloqueado = ($u['estado'] ?? 'activo') === 'bloqueado';
                            $esYo = (int) $u['id_usuario'] === $miId;
                            // Qué puede hacer el rol actual con este usuario
                            $permisos = permisosSobreUsuario($miRol, $miId, $u);
                        ?>
                            <tr data-search="<?= e(strtolower($u['id_usuario'] . ' ' . $u['nombre'] . ' ' . $u['usuario'] . ' ' . $u['correo'])) ?>">
                                <td>#<?= (int) $u['id_usuario'] ?></td>
                                <td><?= e($u['nombre']) ?> <span class="muted">(@<?= e($u['usuario']) ?>)</span></td>
                                <td><?= e($u['correo']) ?></td>
                                <td><span class="badge badge-<?= e($u['rol']) ?>"><?= e(nombreRol($u['rol'])) ?></span></td>
                                <td><span class="badge <?= $bloqueado ? 'badge-bloqueado' : 'badge-activo' ?>"><?= $bloqueado ? 'Bloqueado' : 'Activo' ?></span></td>
                                <td><?= e(fechaHora($u['fecha_registro'])) ?></td>
                                <td><?= $u['ultimo_login'] ? e(fechaHora($u['ultimo_login'])) : '<span class="muted">Nunca</span>' ?></td>
                                <td>
                                    <?php // Botones editar y bloquear ?>
                                    <div class="acciones">
                                        <?php if ($permisos['editar']): ?>
                                            <a href="editar_usuario.php?id=<?= (int) $u['id_usuario'] ?>" class="btn-mini btn-editar">Editar</a>
                                        <?php endif; ?>
                                        <?php if (!$permisos['bloquear']): ?>
                                            <?php // Sin permiso para bloquear: no se muestra el botón ?>
                                        <?php elseif ($bloqueado): ?>
                                            <form method="POST">
                                                <input type="hidden" name="id" value="<?= (int) $u['id_usuario'] ?>">
                                                <button type="submit" name="accion" value="desbloquear" class="btn-mini btn-ok">Desbloquear</button>
                                            </form>
                                        <?php elseif (!$esYo): ?>
                                            <form method="POST" onsubmit="return confirm('¿Bloquear a este usuario? No podrá iniciar sesión.');">
                                                <input type="hidden" name="id" value="<?= (int) $u['id_usuario'] ?>">
                                                <button type="submit" name="accion" value="bloquear" class="btn-mini btn-peligro">Bloquear</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php adminFin(); ?>
