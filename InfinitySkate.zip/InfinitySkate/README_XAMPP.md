# SkateInfinity - tienda + panel de administración funcional

## Instalación en XAMPP
1. Copia la carpeta `InfinitySkate` a `C:\xampp\htdocs\`.
2. Enciende **Apache** y **MySQL**.
3. Base de datos (elige UNA):
   - **Empezar de cero:** en phpMyAdmin > Importar > `SkateInfinity.sql` (recrea todo, borra usuarios/pedidos actuales).
   - **Conservar tus datos:** en phpMyAdmin > base `skateinfinity` > pestaña SQL, pega y ejecuta `migracion_panel.sql` (una sola vez).
4. Si tu MySQL no usa el puerto 3307/3306, ajusta `P.F/php/config/conexion.php`.
5. Abre `http://localhost/InfinitySkate/P.F/html/principal.html` (nunca con doble clic).

## Roles y categorías (actualización)
- Base de datos: si ya la tenías importada, ejecuta **una vez** `migracion_roles_categorias.sql` (agrega el rol `propietario` y las opciones de categoría). Si importas `SkateInfinity.sql` desde cero ya viene incluido.
- Asigna el primer propietario en phpMyAdmin (`usuarios.rol = 'propietario'`) o con la última línea de la migración.
- **Cliente**: igual que antes. **Admin**: entra al panel; puede editar nombre y usuario de los clientes y bloquearlos, pero no toca a otros admins ni a propietarios. **Propietario**: cambia todo (nombre, usuario, correo y rol) de admins y clientes y puede bloquearlos; no puede modificar a otros propietarios.
- Productos > **+ Nueva categoría**: nombre, si sus productos llevan talla y/o color, y si se muestra en la tienda. La categoría nueva aparece al crear productos, en `categorias.html`, en los menús y en el buscador.
- Modal de carga global (`css/shared/cargando.css`, `js/shared/cargando.js`, `img/cargando.webp`).

## Cómo entrar al panel
- Inicia sesión normal: siempre te lleva a la tienda.
- Si tu usuario tiene `rol = admin` (se cambia en phpMyAdmin > tabla `usuarios`, o desde el propio panel), aparece el botón **Panel de administrador** junto al carrito. Los clientes no lo ven y, aunque escriban la URL, el servidor los rechaza.
- El botón **Salir** del panel te devuelve a la tienda (no cierra sesión).

## Qué cambió
**Tienda (ahora lee de la base de datos)**
- Los productos ya no están escritos a mano en el HTML: `principal.html` y `categorias.html` se dibujan desde MySQL (`php/api/catalogo_js.php` + `js/tienda/tienda-render.js`). Crear, editar, ocultar o eliminar en el panel se ve al recargar la tienda.
- Un producto nuevo aparece en su categoría y en el buscador. Necesita al menos una variante con stock para poder comprarse.
- Descuentos: `precio_base` es el precio **original**; el descuento se aplica encima (precio final redondeado hacia abajo a la centena). Se ve en Promociones, primero en su categoría, en el buscador y en el carrito/pedido.
- "Recomendados para ti": 4 productos al azar, solo sin descuento (cambian en cada carga).
- Botón "Panel de administrador" en el header (solo rol admin) y logo del panel con la misma animación de la tienda.

**Panel**
- Diseño nuevo y más limpio; contenedores con zoom y brillo rojo al pasar el mouse; badge rojo "Administrador" y botón "Salir" rediseñado.
- Productos: el buscador consulta **todos** los productos (no solo la página visible). Eliminar borra de verdad; si el producto tiene pedidos en el historial no se puede borrar sin romper las ventas, así que se oculta y el panel te avisa.
- Usuarios: solo se edita nombre de usuario y rol. "Inactivar" ahora es **Bloquear**: el usuario no puede iniciar sesión y le sale un aviso con el teléfono y correo de contacto. Si estaba conectado, se le cierra la sesión al siguiente movimiento. No puedes bloquearte ni quitarte el rol a ti mismo.
- Pedidos: igual que antes, con el nuevo diseño.

## Notas
- La descripción de un producto admite máximo 255 caracteres (límite de la base de datos).
- Al cambiar la foto de un producto se guarda en `Imagenes/Productos/<nombre-del-producto>/`.

## Estructura del código (P.F)
- `html/`: una página por archivo, sin `<style>` ni `<script>` incrustados y sin comentarios.
- `css/shared/`: estilos compartidos (base, header, footer, formularios, productos, modales…). `css/pages/`: estilos de cada página (carrito, ajustes, pago, landing, términos). `css/admin_styles.css`: panel admin.
- `js/usuario/`: sesión, menús, recuperar contraseña, y un archivo por página (`auth`, `ajustes`, `carrito`). `js/tienda/`: catálogo, buscador y modal de producto. `js/pages/`: scripts de landing, pago y términos. `js/admin/`: panel admin.
- Cada HTML carga solo los archivos que necesita, en orden (los `defer` de usuario/ van siempre en el orden en que están escritos).
- `php/`: sin comentarios (`api/`, `auth/`, `config/`, `logic/` y las páginas del panel).
