<?php
// Cargar lógica y estructura del admin
require_once __DIR__ . '/logic/pedidos_logic.php';
require_once __DIR__ . '/logic/admin_layout.php';
adminInicio('Gestión de Pedidos', 'pedidos');
?>
        <?php // Tabla de pedidos ?>
        <div class="table-container">
            <?php // Buscador de pedidos ?>
            <div class="table-header-action">
                <input type="text" class="search-input" placeholder="Buscar por ID o cliente..." data-filtra="#pedidosTableBody" autocomplete="off">
            </div>
            <div class="table-scroll">
                <table>
                    <thead>
                        <tr><th>ID</th><th>Cliente</th><th>Fecha</th><th>Total</th><th>Estado</th><th>Cambiar estado</th></tr>
                    </thead>
                    <tbody id="pedidosTableBody">
                        <?php // Filas de pedidos ?>
                        <?php if (empty($pedidos)): ?>
                            <tr><td colspan="6" class="empty">No hay pedidos registrados en el sistema.</td></tr>
                        <?php else: foreach ($pedidos as $p):
                            $estado = strtolower($p['estado']);
                            $clase = $estado === 'entregado' ? 'completado' : str_replace(' ', '-', $estado);
                        ?>
                            <tr data-search="<?= e(strtolower($p['id_pedido'] . ' ' . ($p['cliente_nombre'] ?? 'Cliente General'))) ?>">
                                <td>#<?= (int) $p['id_pedido'] ?></td>
                                <td><?= e($p['cliente_nombre'] ?? 'Cliente General') ?></td>
                                <td><?= fechaHora($p['fecha_pedido']) ?></td>
                                <td><?= dinero($p['pago_total']) ?></td>
                                <td><span class="badge badge-<?= e($clase) ?>"><?= e(ucwords($estado)) ?></span></td>
                                <?php // Cambiar estado del pedido ?>
                                <td>
                                    <form method="POST">
                                        <input type="hidden" name="id_pedido" value="<?= (int) $p['id_pedido'] ?>">
                                        <select name="nuevo_estado" class="select-estado" onchange="this.form.submit()">
                                            <option value="Revisando Pago" <?= $estado === 'revisando pago' ? 'selected' : '' ?>>Revisando Pago</option>
                                            <option value="Pendiente" <?= $estado === 'pendiente' ? 'selected' : '' ?>>Pendiente</option>
                                            <option value="Completado" <?= ($estado === 'completado' || $estado === 'entregado') ? 'selected' : '' ?>>Completado</option>
                                            <option value="Cancelado" <?= $estado === 'cancelado' ? 'selected' : '' ?>>Cancelado</option>
                                        </select>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php adminFin(); ?>
