<?php
// Eliminar categoría
require_once __DIR__ . '/logic/categoria_eliminar_logic.php';
