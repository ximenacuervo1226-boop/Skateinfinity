<?php
declare(strict_types=1);

// Iniciar sesión y responder en JSON
session_start();
header('Content-Type: application/json; charset=utf-8');

// Enviar respuesta JSON
function respuesta(array $data, int $status = 200) {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Leer datos de entrada
function datosEntrada(): array {
    $raw = file_get_contents('php://input');
    if (!$raw) return $_POST;
    $data = json_decode($raw, true);
    return is_array($data) ? $data : $_POST;
}

// Exigir usuario con sesión
function exigirSesion(): int {
    if (empty($_SESSION['id_usuario'])) {
        respuesta(['ok' => false, 'mensaje' => 'Debes iniciar sesión para realizar esta acción.'], 401);
    }
    return (int) $_SESSION['id_usuario'];
}
