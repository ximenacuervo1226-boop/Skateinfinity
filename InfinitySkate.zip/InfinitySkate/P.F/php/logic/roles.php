<?php

// Roles que pueden entrar al panel de administración
const ROLES_PANEL = ['admin', 'propietario'];

// Nombre bonito de cada rol
function nombreRol(string $rol): string {
    $nombres = ['cliente' => 'Cliente', 'admin' => 'Admin', 'propietario' => 'Propietario'];
    return $nombres[$rol] ?? ucfirst($rol);
}

// Saber qué puede hacer el usuario conectado sobre otro usuario
// Devuelve: editar (puede abrir la edición), campos (cuáles puede cambiar) y bloquear
function permisosSobreUsuario(string $miRol, int $miId, array $objetivo): array {
    $nada = ['editar' => false, 'campos' => [], 'bloquear' => false];

    // Sobre su propia cuenta: nunca puede cambiar su rol ni bloquearse
    if ((int) $objetivo['id_usuario'] === $miId) {
        $campos = $miRol === 'propietario' ? ['nombre', 'usuario', 'correo'] : ['nombre', 'usuario'];
        return ['editar' => true, 'campos' => $campos, 'bloquear' => false];
    }

    // Ningún rol puede tocar a otro propietario
    if ($objetivo['rol'] === 'propietario') return $nada;

    // Propietario: puede cambiar todo a admins y clientes, y bloquearlos
    if ($miRol === 'propietario') {
        return ['editar' => true, 'campos' => ['nombre', 'usuario', 'correo', 'rol'], 'bloquear' => true];
    }

    // Admin: solo nombre y usuario de los clientes, y puede bloquearlos
    if ($miRol === 'admin' && $objetivo['rol'] === 'cliente') {
        return ['editar' => true, 'campos' => ['nombre', 'usuario'], 'bloquear' => true];
    }

    // Admin sobre otros admins o propietarios: sin permisos
    return $nada;
}
