-- =========================================================
--  Migración: rol "propietario" + categorías con opciones.
--  Para bases YA importadas (no borra usuarios, productos ni pedidos).
--  Ejecutar UNA sola vez en phpMyAdmin > base skateinfinity > pestaña SQL.
--  Si prefieres empezar de cero, importa SkateInfinity.sql (ya incluye todo).
-- =========================================================
USE skateinfinity;

-- 1) Nuevo rol: propietario (los clientes y admins actuales no cambian)
ALTER TABLE usuarios MODIFY rol ENUM('cliente','admin','propietario') NOT NULL DEFAULT 'cliente';

-- 2) Opciones de cada categoría:
--    requiere_talla / requiere_color = si sus productos llevan talla y color
--    visible = si la categoría (y sus productos) se muestra en la tienda
ALTER TABLE categorias ADD COLUMN requiere_talla TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE categorias ADD COLUMN requiere_color TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE categorias ADD COLUMN visible TINYINT(1) NOT NULL DEFAULT 1;

-- 3) Asignar el primer propietario (cambia TU_USUARIO por tu nombre de usuario
--    y quita los dos guiones del inicio para ejecutarlo):
-- UPDATE usuarios SET rol = 'propietario' WHERE usuario = 'TU_USUARIO';
