    // Crear partículas de fondo
    function createParticles() {
        const container = document.getElementById('particle-container');
        if (!container) return;
        const particleCount = 100;
        for (let i = 0; i < particleCount; i++) {
            const particle = document.createElement('div');
            particle.classList.add('particle');
            const size = Math.random() * 12 + 8;
            particle.style.width = `${size}px`;
            particle.style.height = `${size}px`;
            particle.style.left = `${Math.random() * 100}%`;
            particle.style.animationDuration = `${Math.random() * 10 + 10}s`;
            particle.style.animationDelay = `${Math.random() * 15}s`;
            container.appendChild(particle);
        }
    }
    document.addEventListener('DOMContentLoaded', createParticles);
